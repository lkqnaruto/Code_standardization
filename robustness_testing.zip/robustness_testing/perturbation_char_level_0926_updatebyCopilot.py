import random
import copy
import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional, Callable
from dataclasses import dataclass
from collections import defaultdict
import json
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics.pairwise import cosine_similarity
from scipy.stats import pearsonr, spearmanr
import logging
import math

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

import string
import re

# --- helpers
_WORD = r"[A-Za-z]+(?:[-'][A-Za-z]+)*"
_PLACEHOLDER = r"__PHRASE_\d+__"
_PUNCT = r"[^\w\s]"
_NUMBER = r"\d+(?:[.,]\d+)*%?|\$\d+(?:[.,]\d+)*"
TOKEN_RX = re.compile(fr"{_PLACEHOLDER}|{_WORD}|{_PUNCT}|{_NUMBER}")


def tokenize(text: str):
    return TOKEN_RX.finditer(text)


def _is_mostly_numeric(tok: str, level: float = 0.6) -> bool:
    digits = sum(c.isdigit() for c in tok)
    return digits >= level * max(1, len(tok))


def is_punctuation(token: str) -> bool:
    return all(ch in string.punctuation for ch in token)


def solve_a_b(n1, n2, d1, d2):
    b = (d1 * n1 - d2 * n2) / (np.log(n1) - np.log(n2))
    a = d1 * n1 - b * np.log(n1)
    return a, b


def cer_estimation(n, i, n0, level="Conservative"):
    mu, sigma = 0.0117, 0.0143
    scenarios = {
        "Conservative": {"Delta1": 0.050, "Delta2": 0.010},
        "Balanced":     {"Delta1": 0.010, "Delta2": 0.012},
        "Aggressive":   {"Delta1": 0.015, "Delta2": 0.015},
    }
    d1, d2 = scenarios[level]["Delta1"], scenarios[level]["Delta2"]
    a, b = solve_a_b(20, 40, d1, d2)
    return mu + i * sigma + i * (a + b * np.log(n + n0)) / n


def _expected_edits(n: int, intensity: str) -> float:
    if n <= 1:
        return 0.0
    n0: int = 5
    mult = {"low": 1.0, "moderate": 2.0, "high": 3.0}.get(intensity, 1.0)
    lam = cer_estimation(n, mult, n0) * n
    return lam


def _integerize_edits(lam: float, mode: str = "stochastic") -> int:
    if mode == "poisson":
        if lam <= 0:
            k = 0
        else:
            L = math.exp(-lam)
            k, p = 0, 1.0
            while p > L:
                k += 1
                p *= random.random()
            k = max(0, k - 1)
    else:
        base = math.floor(lam)
        frac = lam - base
        k = base + (1 if random.random() < frac else 0)
    return k


# ──────────────────────────────────────────────────────────────────
# FIX 1: _choose_positions — allow double-letter positions (removed
#         the `s[i] == s[i+1]` skip).  Also parameterise
#         boundary_skip_p per call so callers can set realistic values.
# ──────────────────────────────────────────────────────────────────
def _choose_positions(
    s: str,
    n_edits: int,
    max_per_word: int = 2,
    boundary_skip_p: float = 0.5,   # FIX: lowered from 0.8 → humans DO mistype first letters
    perturbation_type: str = "deletion",
) -> List[int]:
    """Select up to n_edits character positions to perturb."""
    if n_edits <= 0 or max_per_word <= 0:
        return []

    spans = []
    for m in TOKEN_RX.finditer(s):
        start, end = m.span()
        tok = s[start:end]
        spans.append((start, end, tok))

    per_word_positions = []
    for start, end, tok in spans:
        if end <= start:
            per_word_positions.append([])
            continue
        if _is_mostly_numeric(tok, level=0.6):
            per_word_positions.append([])
            continue
        if is_punctuation(tok):
            per_word_positions.append([])
            continue

        def _would_zero_token(idx: int) -> bool:
            if start <= idx < end:
                return (end - start) - 1 <= 0
            return False

        positions = []
        for i in range(start, end):
            ch = s[i]
            if ch.isspace():
                continue
            if perturbation_type == "deletion" and _would_zero_token(i):
                continue

            # FIX 1: removed the `s[i] == s[i+1]` skip — double letters
            # (e.g. "ll", "tt") are common human typo targets.

            at_boundary = (i == start) or (i == end - 1)

            # Short token guard: still avoid over-perturbing 1-letter tokens
            if len(tok) <= 1:
                continue
            # 2-letter tokens: perturb occasionally
            if len(tok) == 2 and random.random() < 0.5:
                continue

            # FIX 2: boundary guard is now probabilistic with a lower default
            # (0.5 instead of 0.8) so first/last letters ARE sometimes hit,
            # matching real human typing patterns.
            if at_boundary and random.random() < boundary_skip_p:
                continue

            positions.append(i)

        if positions:
            random.shuffle(positions)
            per_word_positions.append(positions[:max_per_word])
        else:
            per_word_positions.append([])

    random.shuffle(per_word_positions)
    total_available = sum(len(lst) for lst in per_word_positions)
    target = min(n_edits, total_available)

    selected = []
    round_idx = 0
    while len(selected) < target:
        progressed = False
        for lst in per_word_positions:
            if round_idx < len(lst):
                selected.append(lst[round_idx])
                if len(selected) >= target:
                    break
                progressed = True
        if not progressed:
            break
        round_idx += 1

    return selected


# ──────────────────────────────────────────────────────────────────
# FIX 3: _insert_char_for_gap — use keyboard-adjacent keys more often
#         instead of duplicating the left neighbour 80% of the time.
# ──────────────────────────────────────────────────────────────────
def _insert_char_for_gap(s: str, g: int, typo_map: dict) -> str:
    """Pick an inserted char using keyboard adjacency + context."""
    left  = s[g - 1] if g - 1 >= 0 else ""
    right = s[g] if g < len(s) else ""

    r = random.random()

    # 35%: use an adjacent key of the left neighbour (fat-finger realism)
    if r < 0.35 and left:
        lower = left.lower()
        if lower in typo_map and typo_map[lower]:
            c = random.choice(typo_map[lower])
            return c.upper() if left.isupper() else c

    # 25%: duplicate the left neighbour (e.g. "neural" → "neurral")
    if r < 0.60 and left and left.isalpha():
        return left

    # 20%: duplicate the right neighbour (e.g. "the" → "tthe")
    if r < 0.80 and right and right.isalpha():
        return right

    # 10%: accidental spacebar hit mid-word
    if r < 0.90:
        return " "

    # fallback: common filler
    return "e"


# ──────────────────────────────────────────────────────────────────
# FIX 4: _apply_shift_error — new helper for accidental Shift key
# ──────────────────────────────────────────────────────────────────
def _apply_shift_error(chars: list, positions: List[int]) -> list:
    """Toggle case at given positions to simulate accidental Shift presses."""
    for idx in positions:
        c = chars[idx]
        if c.isalpha():
            chars[idx] = c.lower() if c.isupper() else c.upper()
    return chars


import numpy as np
import random
import string
from typing import List, Dict, Tuple, Callable
from dataclasses import dataclass
from enum import Enum
import json
from collections import defaultdict


class PerturbationType(Enum):
    TYPO = "typo"
    DELETION = "deletion"
    INSERTION = "insertion"
    TRANSPOSITION = "transposition"


@dataclass
class TestCase:
    original_query: str
    perturbed_query: str
    perturbation_type: PerturbationType
    intensity: float
    expected_degradation: float


class CharacterPerturbator:
    """Handles character-level perturbations that mimic realistic human typing errors."""

    def __init__(self, seed: int = 42):
        random.seed(seed)
        np.random.seed(seed)

        self.typo_map = {
            'a': ['s', 'q', 'z'],
            'b': ['v', 'n', 'g'],
            'c': ['x', 'v', 'd'],
            'd': ['s', 'f', 'c', 'e'],   # FIX: added 'e' (common "d→e" slip)
            'e': ['w', 'r', '3', 'd'],
            'f': ['d', 'g', 'r', 'v'],
            'g': ['f', 'h', 't', 'b'],
            'h': ['g', 'j', 'y', 'n'],
            'i': ['u', 'o', '8', 'k'],
            'j': ['h', 'k', 'u', 'n'],
            'k': ['j', 'l', 'i', 'm'],
            'l': ['k', 'p', '1', 'o'],
            'm': ['n', 'k', 'j'],         # FIX: added k, j
            'n': ['b', 'm', 'h', 'j'],
            'o': ['i', 'p', '0', 'l'],
            'p': ['o', 'l', '0'],
            'q': ['w', 'a', '1'],
            'r': ['e', 't', '4', 'f'],
            's': ['a', 'd', 'z', 'w'],
            't': ['r', 'y', '5', 'g'],
            'u': ['y', 'i', '7', 'j'],
            'v': ['c', 'b', 'f', 'g'],
            'w': ['q', 'e', '2', 's'],
            'x': ['z', 'c', 's', 'd'],
            'y': ['t', 'u', '6', 'h'],
            'z': ['a', 'x', 's'],
        }

        self.unicode_map = {
            'a': ['а', 'ɑ', 'α'],
            'e': ['е', 'ε', 'ɛ'],
            'i': ['і', 'ι', 'ɪ'],
            'o': ['о', 'ο', 'σ'],
            'c': ['с', 'ϲ'],
            'p': ['р', 'ρ'],
            'x': ['х', 'χ'],
            'y': ['у', 'γ'],
        }

    def apply_perturbation(
        self,
        text: str,
        perturbation_type: PerturbationType,
        intensity: float,
    ) -> str:
        if perturbation_type == PerturbationType.TYPO:
            return self._apply_typo(text, intensity)
        elif perturbation_type == PerturbationType.DELETION:
            return self._apply_deletion(text, intensity)
        elif perturbation_type == PerturbationType.INSERTION:
            return self._apply_insertion(text, intensity)
        elif perturbation_type == PerturbationType.TRANSPOSITION:
            return self._apply_transposition(text, intensity)
        return text

    # ── TYPO ──────────────────────────────────────────────────────
    def _apply_typo(self, text: str, intensity: str, mode: str = "stochastic") -> str:
        """Simulate keyboard typos.

        Three sub-types chosen randomly per edit:
          - adjacent-key substitution  (most common)
          - accidental Shift toggle    (FIX 4: new)
          - double-letter omission     (e.g. "oportunity")
        """
        if not text:
            return text

        max_cer = 0.10          # slightly raised: humans make more typos than assumed
        min_edit_len = 4        # FIX: lowered from 5 → short words still get hit

        n_chars = len(text)
        lam = _expected_edits(n_chars, intensity)
        edits = _integerize_edits(lam, mode)
        edits = min(edits, max(1, int(n_chars * max_cer)))

        if n_chars < min_edit_len:
            edits = 1 if random.random() < 0.25 else 0   # FIX: raised prob from 0.1

        if edits <= 0:
            return text

        # FIX 2: lower boundary_skip_p so first letters are occasionally hit
        positions = _choose_positions(
            text, edits, boundary_skip_p=0.5, perturbation_type="typo"
        )
        if not positions:
            return text

        chars = list(text)

        for idx in positions:
            orig = chars[idx]
            roll = random.random()

            # 70%: adjacent-key substitution
            if roll < 0.70:
                lower = orig.lower()
                if lower in self.typo_map and self.typo_map[lower]:
                    repl = random.choice(self.typo_map[lower])
                    chars[idx] = repl.upper() if orig.isupper() else repl

            # 20%: accidental Shift (case toggle)  — FIX 4
            elif roll < 0.90:
                chars[idx] = orig.lower() if orig.isupper() else orig.upper()

            # 10%: swap with the *right* neighbour's key (reach typo)
            else:
                if idx + 1 < len(chars):
                    nb = chars[idx + 1].lower()
                    if nb in self.typo_map and self.typo_map[nb]:
                        repl = random.choice(self.typo_map[nb])
                        chars[idx] = repl.upper() if orig.isupper() else repl

        return "".join(chars)

    # ── DELETION ──────────────────────────────────────────────────
    def _apply_deletion(self, text: str, intensity: str, max_cer: float = 0.10) -> str:
        """Delete characters, mimicking missed keystrokes."""
        # FIX: consistent min_edit_len with typo (was 10, now 5)
        min_edit_len = 5
        n_chars = len(text)

        lam = _expected_edits(n_chars, intensity)
        edits = _integerize_edits(lam)
        edits = min(edits, max(1, int(n_chars * max_cer)))

        if n_chars < min_edit_len:
            edits = 1 if random.random() < 0.20 else 0   # FIX: raised from 0.1

        if edits <= 0:
            return text

        # FIX 2: boundary_skip_p=0.6 — humans do skip first/last letters sometimes
        positions = _choose_positions(
            text, edits, boundary_skip_p=0.6, perturbation_type="deletion"
        )
        chars = list(text)
        for idx in sorted(positions, reverse=True):
            if 0 <= idx < len(chars):
                del chars[idx]

        return "".join(chars)

    # ── INSERTION ─────────────────────────────────────────────────
    def _apply_insertion(self, text: str, intensity: str, mode: str = "stochastic") -> str:
        """Insert extra characters, mimicking fat-finger or repeated keystrokes.

        FIX 3: insert AFTER the position (index + 1) to reflect how a human
        physically presses a key while already on the current character.
        Also uses the improved _insert_char_for_gap with keyboard adjacency.
        """
        if not text:
            return text

        min_edit_len = 5      # FIX: consistent with other methods
        max_cer = 0.10

        n_chars = len(text)
        lam = _expected_edits(n_chars, intensity)
        edits = _integerize_edits(lam, mode)
        edits = min(edits, max(1, int(n_chars * max_cer)))

        if n_chars < min_edit_len:
            edits = 1 if random.random() < 0.20 else 0

        if edits <= 0:
            return text

        positions = _choose_positions(text, edits, boundary_skip_p=0.7)
        if not positions:
            return text

        chars = list(text)
        # FIX 3: insert AFTER position (reverse order still prevents index shift)
        for idx in sorted(positions, reverse=True):
            insert_after = min(idx + 1, len(chars))   # insert after the mis-hit key
            insert_char = _insert_char_for_gap(text, idx, self.typo_map)
            chars.insert(insert_after, insert_char)

        return "".join(chars)

    # ── TRANSPOSITION ─────────────────────────────────────────────
    def _apply_transposition(
        self,
        text: str,
        intensity: str,
        mode: str = "stochastic",
        boundary_skip_p: float = 0.7,   # FIX: lowered from 0.9
    ) -> str:
        """Swap adjacent characters.

        FIX 5: removed the `text[i] == text[i+1]` skip so that identical
        adjacent chars (e.g. "ll" in "calling") can be transposed — this
        is a real human error pattern (e.g. "calilng").
        """
        if not text:
            return text

        min_edit_len = 4
        max_cer = 0.10
        max_per_word = 2
        n_chars = len(text)

        lam = _expected_edits(n_chars, intensity)
        edits = _integerize_edits(lam, mode)
        edits = min(edits, max(1, int(n_chars * max_cer)))

        if n_chars < min_edit_len:
            edits = 1 if random.random() < 0.8 else 0

        if edits <= 0:
            return text

        spans = []
        for m in TOKEN_RX.finditer(text):
            start, end = m.span()
            tok = text[start:end]
            spans.append((start, end, tok))

        per_word_pairs = []
        for start, end, tok in spans:
            if end <= start:
                per_word_pairs.append([])
                continue

            if _is_mostly_numeric(tok, level=0.6):
                starts = []
                for i in range(start, end - 1):
                    if text[i].isspace() or text[i + 1].isspace():
                        continue
                    starts.append(i)
                random.shuffle(starts)
                chosen, blocked = [], set()
                for i in starts:
                    if i in blocked or (i - 1) in blocked or (i + 1) in blocked:
                        continue
                    chosen.append(i)
                    blocked.update({i - 1, i, i + 1})
                    if len(chosen) >= max_per_word:
                        break
                per_word_pairs.append(chosen)
                continue

            if end - start < 2 or is_punctuation(tok):
                per_word_pairs.append([])
                continue

            starts = []
            for i in range(start, end - 1):
                if text[i].isspace() or text[i + 1].isspace():
                    continue
                at_left  = (i == start)
                at_right = (i + 1 == end - 1)
                if (at_left or at_right) and random.random() < boundary_skip_p:
                    continue
                # FIX 5: removed `text[i] == text[i+1]` skip — identical pairs
                # ("ll", "tt") ARE valid human transposition targets.
                starts.append(i)

            random.shuffle(starts)
            chosen, blocked = [], set()
            for i in starts:
                if i in blocked or (i - 1) in blocked or (i + 1) in blocked:
                    continue
                chosen.append(i)
                blocked.update({i - 1, i, i + 1})
                if len(chosen) >= max_per_word:
                    break
            per_word_pairs.append(chosen)

        random.shuffle(per_word_pairs)
        total_avail = sum(len(lst) for lst in per_word_pairs)
        target = min(edits, total_avail)
        selected, rr = [], 0
        while len(selected) < target:
            progressed = False
            for lst in per_word_pairs:
                if rr < len(lst):
                    selected.append(lst[rr])
                    if len(selected) >= target:
                        break
                    progressed = True
            if not progressed:
                break
            rr += 1

        if not selected:
            return text

        chars = list(text)
        for i in sorted(selected):
            chars[i], chars[i + 1] = chars[i + 1], chars[i]

        return "".join(chars)


# ──────────────────────────────────────────────────────────────────
# adapt_model_interface  (unchanged from previous version)
# ──────────────────────────────────────────────────────────────────
def adapt_model_interface(
    api_fn: Callable,
    *,
    response_key: Optional[str] = None,
    id_field: str = "id",
    score_field: str = "score",
    sort: bool = True,
    top_k: int = 10,
    extra_kwargs: Optional[Dict] = None,
) -> Callable[[str], List[Tuple[int, float]]]:
    """Convert an arbitrary scoring function / API caller into the
    ``query -> List[Tuple[doc_id, score]]`` interface expected by
    :class:`HybridIRModelTester`.

    Supported return shapes (auto-detected):

    1. ``List[Tuple[int, float]]``       – pass-through
    2. ``List[Dict]``                    – use id_field / score_field
    3. ``Dict`` with results key         – set response_key, then rule 2
    4. ``Dict[id -> score]``             – auto-detected
    5. Flat ``ndarray`` / ``list``       – index = doc_id

    Parameters
    ----------
    api_fn : Callable
        Raw scoring function; must accept at least a query positional arg.
    response_key : str, optional
        If the function returns a dict, extract this key first.
    id_field / score_field : str
        Key names when results are a list of dicts.
    sort : bool
        Sort descending by score and keep top_k.
    top_k : int
        Maximum results to return.
    extra_kwargs : dict, optional
        Additional keyword arguments forwarded to api_fn on every call.
    """
    _extra = extra_kwargs or {}

    def _convert(raw) -> List[Tuple[int, float]]:
        if response_key is not None and isinstance(raw, dict):
            raw = raw[response_key]

        if isinstance(raw, list) and len(raw) == 0:
            return []

        if isinstance(raw, list) and isinstance(raw[0], (tuple, list)):
            pairs = [(int(r[0]), float(r[1])) for r in raw]
        elif isinstance(raw, list) and isinstance(raw[0], dict):
            pairs = [(int(r[id_field]), float(r[score_field])) for r in raw]
        elif isinstance(raw, dict):
            pairs = [(int(k), float(v)) for k, v in raw.items()]
        elif isinstance(raw, (np.ndarray, list)):
            arr = np.asarray(raw, dtype=float)
            pairs = [(int(i), float(s)) for i, s in enumerate(arr)]
        else:
            raise TypeError(
                f"adapt_model_interface: cannot convert return type "
                f"{type(raw).__name__}. Supported: list[tuple], "
                f"list[dict], dict, ndarray."
            )

        if sort:
            pairs.sort(key=lambda x: x[1], reverse=True)
        return pairs[:top_k]

    def _adapted(query: str) -> List[Tuple[int, float]]:
        result = api_fn(query, **_extra)
        return _convert(result)

    _adapted.__doc__ = (
        f"Adapted interface around {getattr(api_fn, '__name__', repr(api_fn))}.\n"
        f"Original doc: {getattr(api_fn, '__doc__', 'N/A')}"
    )
    _adapted.__wrapped__ = api_fn
    return _adapted


# ──────────────────────────────────────────────────────────────────
# HybridIRModelTester  (unchanged logic; run_test_cases kept intact)
# ──────────────────────────────────────────────────────────────────
class HybridIRModelTester:
    """Main testing framework for hybrid IR models."""

    def __init__(self, model_interface: Callable):
        self.model = model_interface
        self.perturbator = CharacterPerturbator()
        self.test_results = defaultdict(list)

    def generate_test_cases(
        self,
        queries: List[str],
        perturbation_types: List[PerturbationType] = None,
        intensity_levels: List[str] = None,
    ) -> List[TestCase]:
        if perturbation_types is None:
            perturbation_types = list(PerturbationType)
        if intensity_levels is None:
            intensity_levels = ["low", "moderate", "high"]

        test_cases = []
        for query in queries:
            for p_type in perturbation_types:
                for intensity in intensity_levels:
                    perturbed = self.perturbator.apply_perturbation(query, p_type, intensity)
                    expected_degradation = {
                        "low": 0.1, "moderate": 0.3, "high": 0.5
                    }.get(intensity, 0.1)
                    test_cases.append(TestCase(
                        original_query=query,
                        perturbed_query=perturbed,
                        perturbation_type=p_type,
                        intensity=intensity,
                        expected_degradation=expected_degradation,
                    ))
        return test_cases

    def score_query(self, query: str) -> List[Tuple[int, float]]:
        """Score a single query through the model interface."""
        return self.model(query)

    def run_test_cases(self, test_cases: List[TestCase]) -> pd.DataFrame:
        """Score original and perturbed queries, compute degradation metrics."""
        from scipy.stats import kendalltau

        rows = []
        for tc in test_cases:
            orig_results = self.score_query(tc.original_query)
            pert_results = self.score_query(tc.perturbed_query)

            n_docs = max(
                (idx for idx, _ in orig_results + pert_results), default=-1
            ) + 1

            if n_docs == 0:
                rows.append({
                    "original": tc.original_query,
                    "perturbed": tc.perturbed_query,
                    "type": tc.perturbation_type.value,
                    "intensity": tc.intensity,
                    "CER": 0.0,
                    "kendall_tau": 1.0,
                    "top1_score_orig": 0.0,
                    "top1_score_pert": 0.0,
                    "top1_delta": 0.0,
                    "top5_jaccard": 1.0,
                })
                continue

            vec_orig = np.zeros(n_docs)
            for idx, score in orig_results:
                if idx < n_docs:
                    vec_orig[idx] = score
            vec_pert = np.zeros(n_docs)
            for idx, score in pert_results:
                if idx < n_docs:
                    vec_pert[idx] = score

            tau, _ = kendalltau(vec_orig, vec_pert)
            if np.isnan(tau):
                tau = 1.0

            top1_orig = orig_results[0][1] if orig_results else 0.0
            top1_pert = pert_results[0][1] if pert_results else 0.0

            set_orig = {idx for idx, _ in orig_results[:5]}
            set_pert = {idx for idx, _ in pert_results[:5]}
            jaccard = len(set_orig & set_pert) / max(len(set_orig | set_pert), 1)

            edits = sum(
                1 for a, b in zip(tc.original_query, tc.perturbed_query) if a != b
            ) + abs(len(tc.original_query) - len(tc.perturbed_query))
            cer = edits / max(len(tc.original_query), 1)

            rows.append({
                "original": tc.original_query,
                "perturbed": tc.perturbed_query,
                "type": tc.perturbation_type.value,
                "intensity": tc.intensity,
                "CER": round(cer, 4),
                "kendall_tau": round(tau, 4),
                "top1_score_orig": round(top1_orig, 4),
                "top1_score_pert": round(top1_pert, 4),
                "top1_delta": round(top1_pert - top1_orig, 4),
                "top5_jaccard": round(jaccard, 4),
            })

        result_df = pd.DataFrame(rows)
        self.test_results["latest"] = result_df
        return result_df