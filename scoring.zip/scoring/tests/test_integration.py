"""
Integration test: exercises the entire scoring module end-to-end.

Flow:
  fake input data  ──►  runner.run()
                            │
                  ┌─────────┴──────────┐
                  │  auth (mocked)     │
                  │  search (mocked)   │
                  └─────────┬──────────┘
                            ▼
                   pipeline output  ──►  utils evaluation  ──►  metrics


All HTTP calls are mocked.  The mock search API returns *query-specific*
hits so that ground-truth matching produces realistic (non-trivial) metric
scores: some queries match, some partially match, some miss entirely.

Run:
    python -m scoring.tests.test_integration
"""

from __future__ import annotations

import sys
import unittest
from unittest.mock import patch, MagicMock
from typing import Any, Dict, List

import pandas as pd


# ── helpers ────────────────────────────────────────────────────────────────

def _mock_response(body: dict) -> MagicMock:
    resp = MagicMock()
    resp.json.return_value = body
    resp.raise_for_status = MagicMock()
    resp.text = str(body)
    return resp


# ── fake ground-truth dataset ─────────────────────────────────────────────

# 5 sample queries, each with a known correct document + section(s).
GROUND_TRUTH = pd.DataFrame([
    {
        "query": "What is model risk management?",
        "User Profile": "analyst;reviewer",
        "Final_answer_doc_id": "DOC-100",
        "Final_answer_sec_names": ["model risk overview"],
    },
    {
        "query": "Explain back-testing procedures for credit models",
        "User Profile": "analyst",
        "Final_answer_doc_id": "DOC-200",
        "Final_answer_sec_names": ["back testing methodology"],
    },
    {
        "query": "How to validate market risk VaR model?",
        "User Profile": "reviewer;validator",
        "Final_answer_doc_id": "DOC-300",
        "Final_answer_sec_names": ["var validation steps"],
    },
    {
        "query": "Describe stress testing framework requirements",
        "User Profile": "analyst;reviewer",
        "Final_answer_doc_id": "DOC-400",
        "Final_answer_sec_names": ["stress testing framework"],
    },
    {
        "query": "What are the model inventory standards?",
        "User Profile": "reviewer",
        "Final_answer_doc_id": "DOC-500",
        "Final_answer_sec_names": ["inventory governance"],
    },
])


# ── query-aware mock API ──────────────────────────────────────────────────

# Each query maps to a list of (document_id, section_name) that the "model"
# returns.  Some deliberately match ground-truth, some do not.

_QUERY_RESULTS: Dict[str, List[dict]] = {
    # --- query 0: FULL match (doc + section) ---
    "What is model risk management?": [
        {"document_id": "DOC-100", "section_name": "model risk overview"},
        {"document_id": "DOC-101", "section_name": "governance summary"},
        {"document_id": "DOC-102", "section_name": "risk taxonomy"},
        {"document_id": "DOC-103", "section_name": "model lifecycle"},
        {"document_id": "DOC-104", "section_name": "policy framework"},
    ],
    # --- query 1: doc-id match, but WRONG section ---
    "Explain back-testing procedures for credit models": [
        {"document_id": "DOC-200", "section_name": "credit scoring overview"},
        {"document_id": "DOC-201", "section_name": "pd calibration"},
        {"document_id": "DOC-202", "section_name": "lgd estimation"},
        {"document_id": "DOC-203", "section_name": "portfolio analysis"},
        {"document_id": "DOC-204", "section_name": "regulatory capital"},
    ],
    # --- query 2: FULL match (doc + section) ---
    "How to validate market risk VaR model?": [
        {"document_id": "DOC-300", "section_name": "var validation steps"},
        {"document_id": "DOC-301", "section_name": "historical simulation"},
        {"document_id": "DOC-302", "section_name": "monte carlo methods"},
        {"document_id": "DOC-303", "section_name": "risk factor mapping"},
        {"document_id": "DOC-304", "section_name": "limit monitoring"},
    ],
    # --- query 3: NO match at all (different prefix → no doc_id match) ---
    "Describe stress testing framework requirements": [
        {"document_id": "XDOC-999", "section_name": "unrelated section a"},
        {"document_id": "XDOC-998", "section_name": "unrelated section b"},
        {"document_id": "XDOC-997", "section_name": "unrelated section c"},
        {"document_id": "XDOC-996", "section_name": "unrelated section d"},
        {"document_id": "XDOC-995", "section_name": "unrelated section e"},
    ],
    # --- query 4: doc-id match + section match ---
    "What are the model inventory standards?": [
        {"document_id": "DOC-500", "section_name": "inventory governance"},
        {"document_id": "DOC-501", "section_name": "model registration"},
        {"document_id": "DOC-502", "section_name": "tiering methodology"},
        {"document_id": "DOC-503", "section_name": "attestation process"},
        {"document_id": "DOC-504", "section_name": "reporting cadence"},
    ],
}


def _build_hit(idx: int, doc_id: str, section_name: str) -> dict:
    """Construct a single hit matching the real API response schema."""
    return {
        "score": round(0.95 - idx * 0.02, 4),
        "reranker_score": round(0.92 - idx * 0.03, 4),
        "record": {
            "raw_context": f"Context for {doc_id}/{section_name}",
            "presentation_context": f"Presentation for {doc_id}/{section_name}",
            "book": "Test Book",
            "document_url": f"https://docs.example.com/{doc_id}",
            "section_url": f"https://docs.example.com/{doc_id}#{section_name}",
            "procedure_identifier": f"PROC-{doc_id}",
            "procedure_revision_number": "2.1",
            "summary": f"Summary for {section_name} in {doc_id}",
            "title": section_name.title(),
            "chunk_id": f"{doc_id}_chunk_{idx}",
            "document_id": doc_id,
            "section_name": section_name,
        },
    }


def _build_search_response(query: str) -> dict:
    """Return a full search-API response body for the given query."""
    records = _QUERY_RESULTS.get(query)
    if records is None:
        # Fallback for unknown queries
        records = [
            {"document_id": f"FALLBACK-{i}", "section_name": f"fallback {i}"}
            for i in range(5)
        ]
    hits = [
        _build_hit(i, r["document_id"], r["section_name"])
        for i, r in enumerate(records)
    ]
    return {"result": {"hits": hits}}


def _route_post(url: str, **kwargs) -> MagicMock:
    """
    Central mock for requests.post — routes auth vs. search by URL.
    """
    from scoring.config import APIGEE_NONPROD_LOGIN_URL

    if url == APIGEE_NONPROD_LOGIN_URL:
        return _mock_response({"access_token": "fake-integration-token"})

    # For search calls, extract the query from the JSON payload.
    import json
    data = kwargs.get("data", "{}")
    payload = json.loads(data) if isinstance(data, str) else data
    query = payload.get("query", "")
    return _mock_response(_build_search_response(query))


# ── integration test ──────────────────────────────────────────────────────

class TestScoringIntegration(unittest.TestCase):
    """
    Full integration: fake data → runner → pipeline → utils evaluation.
    """

    @patch("requests.post", side_effect=_route_post)
    def test_end_to_end_with_evaluation(self, mock_post: MagicMock):
        from scoring.runner import run
        from scoring.utils import process_dataframe, calculate_document_match_rate

        # ── 1. Build input ────────────────────────────────────────────
        queries = GROUND_TRUTH["query"].tolist()
        profiles = GROUND_TRUTH["User Profile"].tolist()

        # ── 2. Run the full scoring pipeline ──────────────────────────
        results = run(
            queries=queries,
            user_profile=profiles,
        )

        # ── 3. Basic output checks ───────────────────────────────────
        self.assertEqual(len(results), 5, "Expected one output row per query")

        expected_cols = [
            "query",
            "User Profile",
            "pred_results_tachyon",
            "pred_retrieval_score",
            "pred_reranker_score",
            "pred_retrieved_chunk_ids",
            "pred_retrieved_doc_ids",
            "pred_retrieved_sec_names",
        ]
        for col in expected_cols:
            self.assertIn(col, results.columns, f"Missing column: {col}")

        # Every row should have exactly TOP_K=5 results
        for idx, row in results.iterrows():
            self.assertEqual(
                len(row["pred_retrieved_chunk_ids"]), 5,
                f"Row {idx}: expected 5 chunk_ids",
            )
            self.assertEqual(
                len(row["pred_retrieved_doc_ids"]), 5,
                f"Row {idx}: expected 5 doc_ids",
            )
            self.assertEqual(
                len(row["pred_retrieved_sec_names"]), 5,
                f"Row {idx}: expected 5 section_names",
            )

        # Scores should be lists of floats
        for idx, row in results.iterrows():
            self.assertIsInstance(row["pred_retrieval_score"], list)
            self.assertTrue(
                all(isinstance(s, float) for s in row["pred_retrieval_score"]),
            )

        # ── 4. Attach ground-truth labels for evaluation ─────────────
        results = results.reset_index(drop=True)
        gt = GROUND_TRUTH[["Final_answer_doc_id", "Final_answer_sec_names"]].copy()
        results = pd.concat([results, gt], axis=1)

        # ── 5. Normalize section names (utils.process_dataframe) ──────
        results = process_dataframe(results)

        # ── 6. Calculate match metrics ────────────────────────────────
        metrics = calculate_document_match_rate(results, match_mode="both")

        # -- Verify metric keys exist --
        self.assertIn("doc_id_match_rate", metrics)
        self.assertIn("section_match_rate", metrics)
        self.assertIn("doc_sec_id_match_rate", metrics)

        # -- Verify each metric is a float in [0, 1] --
        for name, value in metrics.items():
            self.assertGreaterEqual(value, 0.0, f"{name} < 0")
            self.assertLessEqual(value, 1.0, f"{name} > 1")

        # -- Check expected metric values based on our fake data --
        #   query 0: doc match ✓, section match ✓, combined ✓
        #   query 1: doc match ✓, section match ✗, combined ✗
        #   query 2: doc match ✓, section match ✓, combined ✓
        #   query 3: doc match ✗, section match ✗, combined ✗
        #   query 4: doc match ✓, section match ✓, combined ✓
        #
        #   doc_id_match_rate    = 4/5 = 0.80
        #   section_match_rate   = 3/5 = 0.60
        #   doc_sec_id_match_rate = 3/5 = 0.60

        self.assertAlmostEqual(
            metrics["doc_id_match_rate"], 0.80, places=2,
            msg="doc_id_match_rate should be 4/5 = 0.80",
        )
        self.assertAlmostEqual(
            metrics["section_match_rate"], 0.60, places=2,
            msg="section_match_rate should be 3/5 = 0.60",
        )
        self.assertAlmostEqual(
            metrics["doc_sec_id_match_rate"], 0.60, places=2,
            msg="doc_sec_id_match_rate should be 3/5 = 0.60",
        )

        # ── 7. Print summary (visible when run with -v) ──────────────
        print("\n" + "=" * 60)
        print("INTEGRATION TEST — SCORING MODULE RESULTS")
        print("=" * 60)

        print(f"\nQueries processed : {len(results)}")
        print(f"Auth calls        : 1 (mocked)")
        print(f"Search calls      : {len(results)} (mocked, query-aware)")

        print("\n-- Per-query retrieval details --")
        for i, row in results.iterrows():
            print(f"\n  Query {i}: {GROUND_TRUTH['query'].iloc[i][:50]}...")
            print(f"    Retrieved doc_ids  : {row['pred_retrieved_doc_ids']}")
            print(f"    Retrieved sections : {row['pred_retrieved_sec_names']}")
            print(f"    Retrieval scores   : {row['pred_retrieval_score']}")
            print(f"    Reranker scores    : {row['pred_reranker_score']}")
            print(f"    Ground-truth doc   : {row['Final_answer_doc_id']}")
            print(f"    Ground-truth secs  : {row['Final_answer_sec_names']}")

        print("\n-- Evaluation metrics --")
        for name, value in sorted(metrics.items()):
            print(f"    {name:30s} : {value:.4f}")

        print("\n" + "=" * 60)
        print("ALL CHECKS PASSED")
        print("=" * 60 + "\n")

    @patch("requests.post", side_effect=_route_post)
    def test_single_query_flow(self, mock_post: MagicMock):
        """Verify the pipeline works for a single query."""
        from scoring.runner import run

        results = run(
            queries=["What is model risk management?"],
            user_profile=["analyst;reviewer"],
        )

        self.assertEqual(len(results), 1)

        row = results.iloc[0]
        # First hit should be the highest score
        self.assertEqual(row["pred_retrieval_score"][0], 0.95)
        # First chunk_id should include the correct doc
        self.assertIn("DOC-100", row["pred_retrieved_chunk_ids"][0])
        # First document_id should be DOC-100
        self.assertEqual(row["pred_retrieved_doc_ids"][0], "DOC-100")

    @patch("requests.post", side_effect=_route_post)
    def test_pre_supplied_token_skips_auth(self, mock_post: MagicMock):
        """When access_token is passed, no auth call is made."""
        from scoring.runner import run

        results = run(
            queries=["What is model risk management?"],
            user_profile=["analyst"],
            access_token="already-have-one",
        )

        self.assertEqual(len(results), 1)

        # All calls should be search calls (none to the auth URL)
        from scoring.config import APIGEE_NONPROD_LOGIN_URL
        for call in mock_post.call_args_list:
            self.assertNotEqual(
                call.args[0], APIGEE_NONPROD_LOGIN_URL,
                "Auth endpoint should NOT have been called",
            )

    @patch("requests.post", side_effect=_route_post)
    def test_output_scores_are_sorted_descending(self, mock_post: MagicMock):
        """Retrieval scores within each row should be in descending order."""
        from scoring.runner import run

        results = run(
            queries=["How to validate market risk VaR model?"],
            user_profile=["reviewer"],
        )

        scores = results.iloc[0]["pred_retrieval_score"]
        self.assertEqual(scores, sorted(scores, reverse=True))

    @patch("requests.post", side_effect=_route_post)
    def test_match_rate_with_no_correct_answers(self, mock_post: MagicMock):
        """A query whose ground-truth doc is absent should yield 0 match."""
        from scoring.runner import run
        from scoring.utils import process_dataframe, calculate_document_match_rate

        results = run(
            queries=["Describe stress testing framework requirements"],
            user_profile=["analyst"],
        )

        results["Final_answer_doc_id"] = "DOC-400"
        results["Final_answer_sec_names"] = [["stress testing framework"]]
        results = process_dataframe(results)

        metrics = calculate_document_match_rate(results, match_mode="both")
        self.assertEqual(metrics["doc_id_match_rate"], 0.0)
        self.assertEqual(metrics["section_match_rate"], 0.0)
        self.assertEqual(metrics["doc_sec_id_match_rate"], 0.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
