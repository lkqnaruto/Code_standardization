"""
End-to-end tests for the scoring package.

All external HTTP calls (Apigee auth + search API) are mocked so the suite
runs with the fake credentials in config.py and never touches the network.
"""

import unittest
from unittest.mock import patch, MagicMock

import pandas as pd


# ---------------------------------------------------------------------------
# Fake API response builders
# ---------------------------------------------------------------------------

def _make_hit(
    chunk_id: str,
    document_id: str,
    section_name: str,
    score: float = 0.85,
    reranker_score: float = 0.75,
) -> dict:
    """Build one hit matching the real API schema."""
    return {
        "score": score,
        "reranker_score": reranker_score,
        "record": {
            "raw_context": f"raw context for {chunk_id}",
            "presentation_context": f"presentation context for {chunk_id}",
            "book": "Test Book",
            "document_url": f"https://example.com/docs/{document_id}",
            "section_url": f"https://example.com/docs/{document_id}#{section_name}",
            "procedure_identifier": f"PROC-{chunk_id}",
            "procedure_revision_number": "1.0",
            "summary": f"Summary for {chunk_id}",
            "title": f"Title for {chunk_id}",
            "chunk_id": chunk_id,
            # Fields consumed by pipeline._safe_field
            "document_id": document_id,
            "section_name": section_name,
        },
    }


def _make_search_response(n_hits: int = 5) -> dict:
    """Complete search-API JSON body with *n_hits* hits."""
    hits = [
        _make_hit(
            chunk_id=f"chunk_{i}",
            document_id=f"DOC-{i:03d}",
            section_name=f"section {i}",
            score=round(0.95 - i * 0.02, 2),
            reranker_score=round(0.90 - i * 0.03, 2),
        )
        for i in range(n_hits)
    ]
    return {"result": {"hits": hits}}


def _make_search_response_no_reranker(n_hits: int = 5) -> dict:
    """Search response WITHOUT reranker_score (tests graceful fallback)."""
    resp = _make_search_response(n_hits)
    for h in resp["result"]["hits"]:
        del h["reranker_score"]
    return resp


def _make_token_response() -> dict:
    return {"access_token": "fake-access-token-for-testing"}


def _mock_response(json_body: dict) -> MagicMock:
    """Wrap a JSON dict in a minimal requests.Response mock."""
    resp = MagicMock()
    resp.json.return_value = json_body
    resp.raise_for_status = MagicMock()
    resp.text = str(json_body)
    return resp


# ===================================================================
# 1. Auth tests
# ===================================================================

class TestAuth(unittest.TestCase):

    @patch("scoring.auth.requests.post")
    def test_get_apigee_access_token(self, mock_post):
        mock_post.return_value = _mock_response(_make_token_response())

        from scoring.auth import get_apigee_access_token
        token = get_apigee_access_token()

        self.assertEqual(token, "fake-access-token-for-testing")
        mock_post.assert_called_once()

    @patch("scoring.auth.requests.post")
    def test_auth_failure_raises(self, mock_post):
        import requests as _req
        mock_post.side_effect = _req.exceptions.ConnectionError("no network")

        from scoring.auth import get_apigee_access_token
        with self.assertRaises(RuntimeError):
            get_apigee_access_token()


# ===================================================================
# 2. Search tests
# ===================================================================

class TestSearch(unittest.TestCase):

    @patch("scoring.search.requests.post")
    def test_get_hybrid_CE(self, mock_post):
        mock_post.return_value = _mock_response(_make_search_response(3))

        from scoring.search import get_hybrid_CE
        result = get_hybrid_CE(
            query="What is model risk?",
            user_profiles=["analyst"],
            access_token="fake-token",
        )

        self.assertIn("result", result)
        self.assertEqual(len(result["result"]["hits"]), 3)
        mock_post.assert_called_once()


# ===================================================================
# 3. Pipeline tests
# ===================================================================

class TestPipeline(unittest.TestCase):

    def _make_input_df(self, n_rows: int = 2) -> pd.DataFrame:
        return pd.DataFrame({
            "query": [f"test query {i}" for i in range(n_rows)],
            "User Profile": ["analyst;reviewer"] * n_rows,
        })

    @patch("scoring.search.requests.post")
    def test_process_tachyon_search(self, mock_post):
        mock_post.return_value = _mock_response(_make_search_response(5))

        from scoring.pipeline import process_tachyon_search
        df = self._make_input_df(3)
        result = process_tachyon_search(df, "query", "fake-token")

        self.assertFalse(result.empty)
        self.assertEqual(len(result), 3)

        expected_cols = [
            "pred_results_tachyon",
            "pred_retrieval_score",
            "pred_reranker_score",
            "pred_retrieved_chunk_ids",
            "pred_retrieved_doc_ids",
            "pred_retrieved_sec_names",
        ]
        for col in expected_cols:
            self.assertIn(col, result.columns)

        # Verify extracted chunk_ids
        self.assertEqual(
            result["pred_retrieved_chunk_ids"].iloc[0],
            [f"chunk_{i}" for i in range(5)],
        )
        # Verify extracted document_ids
        self.assertEqual(
            result["pred_retrieved_doc_ids"].iloc[0],
            [f"DOC-{i:03d}" for i in range(5)],
        )

    @patch("scoring.search.requests.post")
    def test_pipeline_without_reranker_score(self, mock_post):
        """Pipeline should not crash when hits lack reranker_score."""
        mock_post.return_value = _mock_response(
            _make_search_response_no_reranker(5)
        )

        from scoring.pipeline import process_tachyon_search
        df = self._make_input_df(1)
        result = process_tachyon_search(df, "query", "fake-token")

        self.assertFalse(result.empty)
        # reranker scores should all be 0.0
        self.assertTrue(
            all(s == 0.0 for s in result["pred_reranker_score"].iloc[0])
        )

    @patch("scoring.search.requests.post")
    def test_retry_on_partial_results(self, mock_post):
        """Rows with < TOP_K results are retried."""
        partial = _make_search_response(2)    # only 2 hits, TOP_K=5
        full = _make_search_response(5)       # 5 hits

        mock_post.side_effect = [
            _mock_response(partial),  # row 0, attempt 1 → incomplete
            _mock_response(full),     # row 0, attempt 2 → complete
        ]

        from scoring.pipeline import process_tachyon_search
        df = self._make_input_df(1)
        result = process_tachyon_search(df, "query", "fake-token", max_attempts=3)

        self.assertFalse(result.empty)
        self.assertEqual(len(result), 1)

    @patch("scoring.search.requests.post")
    def test_run_tachyon_pipeline(self, mock_post):
        mock_post.return_value = _mock_response(_make_search_response(5))

        from scoring.pipeline import run_tachyon_pipeline
        df = self._make_input_df(2)
        result = run_tachyon_pipeline(df, "query", "fake-token")

        self.assertFalse(result.empty)
        self.assertEqual(len(result), 2)

    @patch("scoring.search.requests.post")
    def test_custom_record_fields(self, mock_post):
        """Custom record_fields mapping produces custom output columns."""
        mock_post.return_value = _mock_response(_make_search_response(5))

        from scoring.pipeline import process_tachyon_search
        df = self._make_input_df(1)
        result = process_tachyon_search(
            df, "query", "fake-token",
            record_fields={
                "document_id": "my_doc_ids",
                "section_name": "my_sections",
            },
            completeness_col="my_doc_ids",
        )

        self.assertFalse(result.empty)
        self.assertIn("my_doc_ids", result.columns)
        self.assertIn("my_sections", result.columns)
        self.assertNotIn("pred_retrieved_doc_ids", result.columns)
        self.assertNotIn("pred_retrieved_sec_names", result.columns)

    @patch("scoring.search.requests.post")
    def test_no_reranker_score(self, mock_post):
        """hit_score_fields without reranker_score omits that column."""
        mock_post.return_value = _mock_response(_make_search_response(5))

        from scoring.pipeline import process_tachyon_search
        df = self._make_input_df(1)
        result = process_tachyon_search(
            df, "query", "fake-token",
            hit_score_fields={"score": "pred_retrieval_score"},
        )

        self.assertFalse(result.empty)
        self.assertIn("pred_retrieval_score", result.columns)
        self.assertNotIn("pred_reranker_score", result.columns)

    def test_completeness_col_validation(self):
        """Invalid completeness_col raises ValueError."""
        from scoring.pipeline import process_tachyon_search
        df = self._make_input_df(1)
        with self.assertRaises(ValueError):
            process_tachyon_search(
                df, "query", "fake-token",
                completeness_col="nonexistent_col",
            )


# ===================================================================
# 4. Utils tests
# ===================================================================

class TestUtils(unittest.TestCase):

    def test_preprocess_text(self):
        from scoring.utils import preprocess_text

        self.assertEqual(preprocess_text("  Hello   World  "), "hello world")
        self.assertEqual(preprocess_text("xxxx noise"), "noise")
        self.assertEqual(
            preprocess_text("visit https://example.com now"),
            "visit url now",
        )

    def test_clean_gif_references(self):
        from scoring.utils import clean_gif_references

        result = clean_gif_references(["intro.gif", "Chapter 1", "logo.gif"])
        self.assertEqual(result, ["Chapter 1"])

    def test_process_dataframe(self):
        from scoring.utils import process_dataframe

        df = pd.DataFrame({
            "pred_retrieved_sec_names": [
                ["Intro.gif", "Chapter ONE"]
            ],
            "Final_answer_sec_names": [
                ["chapter one", "Appendix"]
            ],
        })
        result = process_dataframe(df)
        # gif reference removed, text lower-cased
        self.assertNotIn("Intro.gif", result["pred_retrieved_sec_names"].iloc[0])

    def test_calculate_document_match_rate_id(self):
        from scoring.utils import calculate_document_match_rate

        df = pd.DataFrame({
            "pred_retrieved_doc_ids": [["DOC-001", "DOC-002"]],
            "pred_retrieved_sec_names": [["section a", "section b"]],
            "Final_answer_doc_id": ["DOC-001"],
            "Final_answer_sec_names": [["section a"]],
        })
        metrics = calculate_document_match_rate(df, match_mode="id")
        self.assertEqual(metrics["doc_id_match_rate"], 1.0)

    def test_calculate_document_match_rate_sec_id(self):
        from scoring.utils import calculate_document_match_rate

        df = pd.DataFrame({
            "pred_retrieved_doc_ids": [["DOC-001", "DOC-002"]],
            "pred_retrieved_sec_names": [["section a", "section b"]],
            "Final_answer_doc_id": ["DOC-001"],
            "Final_answer_sec_names": [["section a"]],
        })
        metrics = calculate_document_match_rate(df, match_mode="sec_id")
        self.assertIn("doc_id_match_rate", metrics)
        self.assertIn("doc_sec_id_match_rate", metrics)
        self.assertEqual(metrics["doc_id_match_rate"], 1.0)
        self.assertEqual(metrics["doc_sec_id_match_rate"], 1.0)

    def test_no_match(self):
        from scoring.utils import calculate_document_match_rate

        df = pd.DataFrame({
            "pred_retrieved_doc_ids": [["NOMATCH-999"]],
            "pred_retrieved_sec_names": [["other section"]],
            "Final_answer_doc_id": ["DOC-001"],
            "Final_answer_sec_names": [["section a"]],
        })
        metrics = calculate_document_match_rate(df, match_mode="both")
        self.assertEqual(metrics["doc_id_match_rate"], 0.0)
        self.assertEqual(metrics["section_match_rate"], 0.0)
        self.assertEqual(metrics["doc_sec_id_match_rate"], 0.0)


# ===================================================================
# 5. Runner (full end-to-end) tests
# ===================================================================

class TestRunner(unittest.TestCase):

    @patch("requests.post")
    def test_run_end_to_end(self, mock_post):
        """Entire flow: auth → search → pipeline → results."""
        from scoring.config import APIGEE_NONPROD_LOGIN_URL

        def route_post(url, **kwargs):
            if url == APIGEE_NONPROD_LOGIN_URL:
                return _mock_response(_make_token_response())
            return _mock_response(_make_search_response(5))

        mock_post.side_effect = route_post

        from scoring.runner import run

        results = run(
            queries=[
                "What is model risk?",
                "How to validate a model?",
                "Explain back-testing procedures.",
            ],
            user_profile=["analyst;reviewer"] * 3,
        )

        # 1 auth call + 3 search calls
        self.assertEqual(mock_post.call_count, 4)

        # Shape
        self.assertEqual(len(results), 3)
        self.assertFalse(results.empty)

        # All expected output columns present
        for col in [
            "pred_results_tachyon",
            "pred_retrieval_score",
            "pred_reranker_score",
            "pred_retrieved_chunk_ids",
            "pred_retrieved_doc_ids",
            "pred_retrieved_sec_names",
        ]:
            self.assertIn(col, results.columns)

        # Scores are lists of floats
        scores = results["pred_retrieval_score"].iloc[0]
        self.assertIsInstance(scores, list)
        self.assertEqual(len(scores), 5)

    @patch("scoring.search.requests.post")
    @patch("scoring.auth.requests.post")
    def test_run_with_preexisting_token(self, mock_auth_post, mock_search_post):
        """If caller provides a token, auth is skipped."""
        mock_search_post.return_value = _mock_response(_make_search_response(5))

        from scoring.runner import run

        results = run(
            queries=["test query"],
            user_profile=["analyst"],
            access_token="pre-supplied-token",
        )

        mock_auth_post.assert_not_called()
        self.assertEqual(len(results), 1)

    @patch("scoring.search.requests.post")
    @patch("scoring.auth.requests.post")
    def test_run_empty_queries_raises(self, mock_auth_post, mock_search_post):
        from scoring.runner import run

        with self.assertRaises(ValueError):
            run(queries=[], user_profile=["analyst"])


if __name__ == "__main__":
    unittest.main()
