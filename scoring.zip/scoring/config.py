"""Configuration constants and environment variable loading."""

import os

# --- API / Use Case IDs ---
USECASE_ID = os.getenv("USECASE_ID", "MRM")
COLLECTION_ID = os.getenv("COLLECTION_ID", "_MRM")
API_KEY = os.getenv("API_KEY", "fake-api-key-abc123")
CLIENT_ID = os.getenv("CLIENT_ID", "fake-client-id-xyz789")

# --- Apigee Configuration ---
APIGEE_CONSUMER_KEY = os.getenv("APIGEE_CONSUMER_KEY", "fake-consumer-key-000")
APIGEE_CONSUMER_SECRET = os.getenv("APIGEE_CONSUMER_SECRET", "fake-consumer-secret-111")
APIGEE_NONPROD_LOGIN_URL = os.getenv(
    "APIGEE_NONPROD_LOGIN_URL",
    "https://api-nonprod.example.com/oauth2/v1/token",
)

# --- Search Configuration ---
SEARCH_URL = os.getenv("SEARCH_URL", "https://api-nonprod.example.com/search/v1/hybrid")
DEFAULT_SEARCH_TYPE = os.getenv("DEFAULT_SEARCH_TYPE", "hybrid")
DEFAULT_SEARCH_COUNT = int(os.getenv("DEFAULT_SEARCH_COUNT", "10"))
DEFAULT_RERANKER = os.getenv("DEFAULT_RERANKER", "cross-encoder")
DEFAULT_FIELD_FILTER_KEY = os.getenv("DEFAULT_FIELD_FILTER_KEY", "userProfiles")

# --- Pipeline Configuration ---
MAX_RETRY_ATTEMPTS = int(os.getenv("MAX_RETRY_ATTEMPTS", "3"))
TOP_K = int(os.getenv("TOP_K", "5"))
