"""
Standalone postprocessing, survey processing, and KPI module.

Three groups of entry points:

1. **Survey processing** — extract ground-truth from raw survey data:
   - ``process_survey_answers(df)`` — satisfaction rates + optional GT extraction

2. **Postprocessing** — normalize section-name columns:
   - ``postprocess(df)``

3. **KPI calculation** — retrieval match-rate metrics:
   - ``compute_kpi(df)``

All functions accept configurable column names.

Usage
-----
::

    from scoring.utils_original import (
        process_survey_answers, postprocess, compute_kpi, SurveyColumns,
    )

    # 1. Extract ground-truth from survey
    df = process_survey_answers(survey_df, extract_gt=True)

    # 2. Postprocess pipeline output (normalize section names)
    df = postprocess(pipeline_df)

    # 3. Compute KPIs
    metrics = compute_kpi(df)
"""

import re
import pandas as pd
from dataclasses import dataclass, field
from typing import List, Union, Dict, Any, Optional, Tuple


# ============================================================
# Text preprocessing (internal)
# ============================================================

def _preprocess_text(text: str) -> str:
    """Lowercase, strip URLs, repeated-x tokens, and digits."""
    text = str(text)
    text = " ".join(text.lower().split())
    text = re.sub(r"x{2,}", "", text)
    text = re.sub(
        r"(?:(?:http|https):\/\/)?(?:[a-zA-Z0-9]{2,256}\.[a-z]{2,6})"
        r"\b(?:[-a-zA-Z0-9@:%_\+.~#?&//=]*)",
        "xxurl",
        text,
    )
    text = " ".join(re.sub(r"\d+", "", tok) for tok in text.split())
    return " ".join(text.split()).strip()


def _clean_gif_references(names_list: Union[List[str], str]) -> Union[List[str], str]:
    """Remove tokens referencing .gif assets."""
    if not isinstance(names_list, list):
        return re.sub(r"\b\S+\.gif\b", "", str(names_list), flags=re.IGNORECASE).strip()

    cleaned = []
    for name in names_list:
        if not isinstance(name, str):
            continue
        cleaned.append(
            re.sub(r"\b\S+\.gif\b", "", name, flags=re.IGNORECASE).strip()
        )
    return [c for c in cleaned if c]


def _normalize_section_col(series: pd.Series) -> pd.Series:
    """Clean .gif refs and preprocess text in a section-name column."""
    return (
        series
        .apply(_clean_gif_references)
        .apply(lambda x: [_preprocess_text(i) for i in x] if isinstance(x, list) else [])
    )


# ============================================================
# Survey column configuration
# ============================================================

@dataclass
class SurveyColumns:
    """Column-name mapping for multi-attempt survey data.

    Each attempt is a tuple of ``(answer_col, doc_id_col, section_name_col)``.
    Pass as many attempts as your survey has.

    Examples
    --------
    Default (3 attempts)::

        SurveyColumns()

    Custom 2-attempt survey::

        SurveyColumns(attempts=[
            ("Satisfied?",       "DocID",   "SecName"),
            ("Satisfied? (2nd)", "DocID_2", "SecName_2"),
        ])
    """

    attempts: List[Tuple[str, str, str]] = field(default_factory=lambda: [
        ("Did that answer your question? - 1", "Document ID",   "Section Name"),
        ("Did that answer your question? - 2", "Document ID-2", "Section Name-2"),
        ("Did that answer your question? - 3", "Document ID-3", "Section Name-3"),
    ])

    def __post_init__(self) -> None:
        if not self.attempts:
            raise ValueError("attempts must contain at least one entry")

    @property
    def answer_cols(self) -> List[str]:
        return [a[0] for a in self.attempts]

    @property
    def doc_id_cols(self) -> List[str]:
        return [a[1] for a in self.attempts]

    @property
    def sec_name_cols(self) -> List[str]:
        return [a[2] for a in self.attempts]

    @property
    def first_answer_col(self) -> str:
        return self.attempts[0][0]

    @property
    def first_doc_id_col(self) -> str:
        return self.attempts[0][1]


DEFAULT_SURVEY_COLUMNS = SurveyColumns()


# ============================================================
# Survey helpers (internal)
# ============================================================

def _has_yes(responses: Union[List, str]) -> bool:
    """Check if any response is 'yes'."""
    if not isinstance(responses, (list, tuple)):
        return str(responses).strip().lower() == "yes"
    return any(
        isinstance(x, str) and x.strip().lower() == "yes"
        for x in responses
    )


def _calculate_satisfaction_rate(series: pd.Series, total: int) -> float:
    if total == 0:
        return 0.0
    return (series == "yes").sum() / total


# ============================================================
# Survey processing
# ============================================================

def process_survey_answers(
    df: pd.DataFrame,
    total_responses: int = 685,
    extract_gt: bool = False,
    *,
    columns: Optional[SurveyColumns] = None,
) -> pd.DataFrame:
    """
    Process survey answers to determine satisfaction rates.

    When ``extract_gt=True``, also extracts the document ID and section
    name from the first 'yes' response to produce ground-truth columns
    for downstream KPI evaluation.

    Parameters
    ----------
    df : pd.DataFrame
        Survey responses.
    total_responses : int
        Denominator for satisfaction rates.
    extract_gt : bool
        If True, extract ``final_answer_doc_id`` and
        ``Final_answer_sec_names`` from the first 'yes' response.
    columns : SurveyColumns, optional
        Column mapping. Defaults to ``DEFAULT_SURVEY_COLUMNS``.

    Returns
    -------
    pd.DataFrame
        Copy of *df* with added columns:

        Always added:
        - ``Final answer`` — list of all attempt answers
        - ``Final_answer_Final`` — "yes" if any attempt is yes, else "no"
        - ``final_answer_1st`` — "yes"/"no" for first attempt only

        When ``extract_gt=True``, also:
        - ``final_answer_doc_id`` — doc ID from first 'yes' attempt
        - ``Final_answer_sec_names`` — section name(s) from first 'yes' attempt
        - ``final_answer_1st_doc_id`` — doc ID from first attempt
    """
    cols = columns or DEFAULT_SURVEY_COLUMNS
    df = df.copy()

    df["Final answer"] = df.apply(
        lambda x: [x[c] for c in cols.answer_cols], axis=1,
    )

    if extract_gt:
        def _extract(row: pd.Series) -> tuple:
            for ans_c, doc_c, sec_c in cols.attempts:
                ans = row.get(ans_c)
                if isinstance(ans, str) and ans.strip().lower() == "yes":
                    return ("yes", row.get(doc_c), row.get(sec_c))
            return ("no", None, None)

        pairs = df.apply(_extract, axis=1)
        df["Final_answer_Final"] = [x[0] for x in pairs]
        df["final_answer_doc_id"] = [x[1] for x in pairs]
        df["Final_answer_sec_names"] = [
            [x[2]] if x[2] is not None else [] for x in pairs
        ]
    else:
        df["Final_answer_Final"] = [
            "yes" if _has_yes(x) else "no" for x in df["Final answer"]
        ]

    df["final_answer_1st"] = [
        "yes" if str(x).strip().lower() == "yes" else "no"
        for x in df[cols.first_answer_col].fillna("")
    ]

    if extract_gt:
        df["final_answer_1st_doc_id"] = df[cols.first_doc_id_col]

    rates = {
        "combined_satisfaction": _calculate_satisfaction_rate(
            df["Final_answer_Final"], total_responses,
        ),
        "first_answer_satisfaction": _calculate_satisfaction_rate(
            df["final_answer_1st"], total_responses,
        ),
    }

    print("\nSatisfaction Rates:")
    print(f"Combined (all answers): {rates['combined_satisfaction']:.4f}")
    print(f"First answer only: {rates['first_answer_satisfaction']:.4f}")

    if extract_gt:
        print("\nDocument ID Statistics:")
        print("Number of 'yes' responses with document IDs:")
        yes_mask = df["Final_answer_Final"] == "yes"
        print(f"Combined: {df.loc[yes_mask, 'final_answer_doc_id'].notna().sum()}")
        yes_1st = df["final_answer_1st"] == "yes"
        print(f"First answer: {df.loc[yes_1st, 'final_answer_1st_doc_id'].notna().sum()}")

    return df


# ============================================================
# Postprocessing
# ============================================================

def postprocess(
    df: pd.DataFrame,
    *,
    pred_sec_col: str = "pred_retrieved_sec_names",
    gt_sec_col: str = "Final_answer_sec_names",
) -> pd.DataFrame:
    """
    Normalize section-name columns in pipeline output.

    Applies to both predicted and ground-truth section columns:
    - Remove ``.gif`` references
    - Lowercase, strip URLs, repeated-x tokens, and digits

    Parameters
    ----------
    df : pd.DataFrame
        Output from ``pipeline.py`` with ground-truth columns attached.
    pred_sec_col : str
        Column with predicted section names (``list[str]`` per row).
    gt_sec_col : str
        Column with ground-truth section names (``list[str]`` per row).

    Returns
    -------
    pd.DataFrame
        Copy of *df* with normalized section-name columns.
    """
    required = [pred_sec_col, gt_sec_col]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")

    df = df.copy()
    df[pred_sec_col] = _normalize_section_col(df[pred_sec_col])
    df[gt_sec_col] = _normalize_section_col(df[gt_sec_col])
    return df


# ============================================================
# KPI calculation
# ============================================================

def compute_kpi(
    df: pd.DataFrame,
    match_mode: str = "both",
    return_df: bool = False,
    *,
    pred_doc_col: str = "pred_retrieved_doc_ids",
    pred_sec_col: str = "pred_retrieved_sec_names",
    gt_doc_col: str = "Final_answer_doc_id",
    gt_sec_col: str = "Final_answer_sec_names",
    normalize: bool = True,
) -> Union[Dict[str, float], Dict[str, Any]]:
    """
    Compute retrieval match-rate KPIs on pipeline output.

    Parameters
    ----------
    df : pd.DataFrame
        Output from ``pipeline.py`` with ground-truth columns attached.
        One row per query.
    match_mode : str
        Which metrics to compute:

        - ``"id"``     — document-ID match rate only
        - ``"sec"``    — section-name match rate only
        - ``"sec_id"`` — document+section pair match rate (+ doc-ID match)
        - ``"both"``   — all three metrics
    return_df : bool
        If True, include the annotated DataFrame under key ``"df"``.
    pred_doc_col : str
        Column with predicted document IDs (``list[str]`` per row).
    pred_sec_col : str
        Column with predicted section names (``list[str]`` per row).
    gt_doc_col : str
        Column with ground-truth document ID (``str`` per row).
    gt_sec_col : str
        Column with ground-truth section names (``list[str]`` per row).
    normalize : bool
        If True (default), run ``postprocess()`` on section columns
        before matching.

    Returns
    -------
    dict
        Metric keys depending on *match_mode*:

        - ``"doc_id_match_rate"``
        - ``"section_match_rate"``
        - ``"doc_sec_id_match_rate"``

        If *return_df* is True, also contains ``"df"``.
    """
    valid_modes = {"id", "sec", "sec_id", "both"}
    if match_mode not in valid_modes:
        raise ValueError(f"match_mode must be one of {valid_modes}")

    # Mode-dependent column validation
    needs_doc = match_mode in {"id", "sec_id", "both"}
    needs_sec = match_mode in {"sec", "sec_id", "both"}

    needed: List[str] = []
    if needs_doc:
        needed += [pred_doc_col, gt_doc_col]
    if needs_sec:
        needed += [pred_sec_col, gt_sec_col]
    missing = [c for c in needed if c not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")

    df = df.copy()

    # Normalize section names if requested
    if normalize and needs_sec:
        df[pred_sec_col] = _normalize_section_col(df[pred_sec_col])
        df[gt_sec_col] = _normalize_section_col(df[gt_sec_col])

    # Compute doc-ID prefixes
    if needs_doc:
        pred_prefixes = df[pred_doc_col].map(
            lambda lst: [str(x).split("-")[0] for x in lst] if isinstance(lst, list) else []
        )
        gt_prefix = df[gt_doc_col].map(lambda x: str(x).split("-")[0])

    metrics: Dict[str, float] = {}

    # 1. Document ID match
    if match_mode in {"id", "sec_id", "both"}:
        df["doc_id_match"] = [
            gt in set(preds) for gt, preds in zip(gt_prefix, pred_prefixes)
        ]
        metrics["doc_id_match_rate"] = df["doc_id_match"].mean()

    # 2. Section match
    if match_mode in {"sec", "both"}:
        df["sec_match"] = df.apply(
            lambda row: bool(set(row[gt_sec_col]) & set(row[pred_sec_col])),
            axis=1,
        )
        metrics["section_match_rate"] = df["sec_match"].mean()

    # 3. Combined doc + section match
    if match_mode in {"sec_id", "both"}:
        df["pred_doc_sec_pairs"] = df.apply(
            lambda row: {
                f"{str(doc).split('-')[0]}_{sec}"
                for doc, sec in zip(row[pred_doc_col], row[pred_sec_col])
            },
            axis=1,
        )
        df["doc_sec_match"] = [
            any(f"{gt}_{sec}" in pairs for sec in gt_secs)
            for gt, pairs, gt_secs in zip(
                gt_prefix, df["pred_doc_sec_pairs"], df[gt_sec_col]
            )
        ]
        metrics["doc_sec_id_match_rate"] = df["doc_sec_match"].mean()

    if return_df:
        return metrics | {"df": df}

    return metrics
