from __future__ import annotations

from typing import Any, Dict, List, Optional


MOCK_HITS = [
    {
        "score": 0.95,
        "record": {
            "raw_context": "Ensure all bolted connections are torqued to specification per Table 4-2 before proceeding to the next assembly step.",
            "presentation_context": "<b>Ensure</b> all bolted connections are torqued to specification per Table 4-2 before proceeding to the next assembly step.",
            "book": "Structural Assembly Manual",
            "document_id": "DOC-SA-2024-003",
            "document_url": "https://docs.example.com/manuals/structural-assembly-v3.pdf",
            "section_name": "Bolted Connections",
            "section_url": "https://docs.example.com/manuals/structural-assembly-v3.pdf#section-4.3",
            "procedure_identifier": "SA-4.3.1",
            "procedure_revision_number": "Rev C",
            "summary": "Bolt torque requirements for structural assembly connections.",
            "title": "Bolted Connection Torque Specifications",
            "chunk_id": "sa-v3-chunk-0042",
        },
    },
    {
        "score": 0.88,
        "record": {
            "raw_context": "Inspect weld joints visually and with dye penetrant testing per NDE requirements outlined in Section 5.1.",
            "presentation_context": "<b>Inspect</b> weld joints visually and with dye penetrant testing per NDE requirements outlined in Section 5.1.",
            "book": "Quality Inspection Procedures",
            "document_id": "DOC-QI-2024-007",
            "document_url": "https://docs.example.com/manuals/quality-inspection-v2.pdf",
            "section_name": "Non-Destructive Examination",
            "section_url": "https://docs.example.com/manuals/quality-inspection-v2.pdf#section-5.1",
            "procedure_identifier": "QI-5.1.2",
            "procedure_revision_number": "Rev B",
            "summary": "Non-destructive examination procedures for weld joint inspection.",
            "title": "Weld Joint Inspection Requirements",
            "chunk_id": "qi-v2-chunk-0118",
        },
    },
    {
        "score": 0.82,
        "record": {
            "raw_context": "Apply corrosion-preventive compound to all exposed metallic surfaces within 4 hours of cleaning.",
            "presentation_context": "<b>Apply</b> corrosion-preventive compound to all exposed metallic surfaces within 4 hours of cleaning.",
            "book": "Surface Treatment Handbook",
            "document_id": "DOC-ST-2024-012",
            "document_url": "https://docs.example.com/manuals/surface-treatment-v4.pdf",
            "section_name": "Corrosion Prevention",
            "section_url": "https://docs.example.com/manuals/surface-treatment-v4.pdf#section-3.7",
            "procedure_identifier": "ST-3.7.4",
            "procedure_revision_number": "Rev A",
            "summary": "Corrosion prevention procedures for cleaned metallic surfaces.",
            "title": "Corrosion Prevention After Surface Cleaning",
            "chunk_id": "st-v4-chunk-0076",
        },
    },
]


def mock_tachyon_search(
    query: str,
    user_profiles: List[str],
    access_token: str,
    *,
    url: str = "",
    usecase_id: str = "",
    collection_id: str = "",
    api_key: str = "",
    search_type: str = "",
    search_count: int = 10,
    reranker: str = "",
    client_id: str = "",
    field_filter_key: str = "",
    headers: Optional[Dict[str, str]] = None,
    payload: Optional[Dict[str, Any]] = None,
    extra_headers: Optional[Dict[str, str]] = None,
    extra_payload: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Mock replacement for ``tachyon_search`` that returns canned results
    without making any network calls.

    The function signature mirrors the real ``tachyon_search`` so it can
    be used as a drop-in substitute (e.g. via monkeypatch or dependency
    injection).

    ``search_count`` controls how many hits are returned (up to the
    number of items in ``MOCK_HITS``).
    """
    hits = MOCK_HITS[:search_count]
    return {"result": {"hits": hits}}
