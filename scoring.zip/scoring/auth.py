"""
Apigee authentication — obtain and cache an access token.
"""

import base64
import requests
import logging

from .config import (
    APIGEE_CONSUMER_KEY,
    APIGEE_CONSUMER_SECRET,
    APIGEE_NONPROD_LOGIN_URL,
)

logger = logging.getLogger(__name__)


def get_apigee_access_token(
    consumer_key: str = APIGEE_CONSUMER_KEY,
    consumer_secret: str = APIGEE_CONSUMER_SECRET,
    login_url: str = APIGEE_NONPROD_LOGIN_URL,
) -> str:
    """
    Obtain a fresh Apigee access token via client_credentials grant.

    Parameters
    ----------
    consumer_key : str
        Apigee consumer key.
    consumer_secret : str
        Apigee consumer secret.
    login_url : str
        Apigee token endpoint URL.

    Returns
    -------
    str
        The access token string.

    Raises
    ------
    RuntimeError
        If the token request fails.
    """

    creds = f"{consumer_key}:{consumer_secret}"
    creds_b64 = base64.b64encode(creds.encode("utf-8")).decode("utf-8")

    try:
        response = requests.post(
            login_url,
            headers={"Authorization": f"Basic {creds_b64}"},
            data={"grant_type": "client_credentials"},
            verify=False,
        )
        response.raise_for_status()

        access_token = response.json()["access_token"]
        logger.info("Successfully obtained Apigee access token.")
        return access_token

    except requests.RequestException as e:
        raise RuntimeError(f"Failed to obtain Apigee access token: {e}") from e

    except KeyError:
        raise RuntimeError(
            f"Unexpected token response format: {response.text}"
        )
