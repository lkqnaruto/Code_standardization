"""
High-level callable entry point — handles auth, data loading, and pipeline
in a single function call.
"""

from __future__ import annotations

import warnings
from typing import Any, Dict, List, Optional, Union

import pandas as pd

from .auth import get_apigee_access_token
from .pipeline import run_tachyon_pipeline

warnings.filterwarnings("ignore")

# Default column names — callers can override via run() parameters.
QUERY_COL_NAME = "query"
PROFILE_COL_NAME = "User Profile"


def _build_dataframe(
    queries: List[str],
    query_col_name: str = QUERY_COL_NAME,
    **kwargs: Any,
) -> pd.DataFrame:
    """
    Build a DataFrame from a list of query strings plus any extra columns
    supplied as keyword arguments.

    Parameters
    ----------
    queries : list[str]
        Raw query strings, stored in *query_col*.
    query_col : str
        Name of the query column. Defaults to ``QUERY_COL``.
    **kwargs
        Each keyword becomes a column name. Values may be:

        - A **scalar** → broadcast to every row.
        - A **list** → used as-is; must have the same length as *queries*.

    Examples
    --------
    >>> _build_dataframe(
    ...     ["query A", "query B"],
    ...     query_col="question",
    ...     **{"User Profile": "analyst,engineer"},  # scalar → broadcast
    ...     source=["web", "doc"],                   # list → one per row
    ... )
    """

    n = len(queries)
    data: Dict[str, Any] = {query_col_name: queries}

    for col, val in kwargs.items():
        if isinstance(val, list):
            if len(val) != n:
                raise ValueError(
                    f"Column '{col}' has {len(val)} values but queries has "
                    f"{n}. They must be the same length."
                )
            data[col] = val
        else:
            # Scalar value → broadcast to all rows.
            data[col] = [val] * n

    return pd.DataFrame(data)


def run(
    queries: List[str],
    user_profile: Union[List[str], List[List[str]], None] = None,
    access_token: Optional[str] = None,
    query_col_name: str = QUERY_COL_NAME,
    profile_col_name: str = PROFILE_COL_NAME,
    hit_score_fields: Optional[Dict[str, str]] = None,
    record_fields: Optional[Dict[str, str]] = None,
    completeness_col: Optional[str] = None,
    **kwargs: Any,
) -> pd.DataFrame:
    """
    End-to-end Tachyon testing from a list of query strings.

    Parameters
    ----------
    queries : list[str]
        Query strings to evaluate. Must be non-empty.

    user_profile : list[str] | list[list[str]] | None, optional
        User profile(s) forwarded to the search API as a field filter. Column name is specified by *profile_col_name*.

        - A flat ``list[str]`` (e.g. ``["role1", "role2"]``) is broadcast to
          every query.
        - A ``list[list[str]]`` supplies a distinct profile per query and must
          have the same length as *queries*.
        - ``None`` / empty list → no role filter.

    access_token : str, optional
        Pre-obtained Apigee token. If ``None``, authenticates automatically.

    query_col_name : str
        DataFrame column name for the query strings. Defaults to ``QUERY_COL_NAME``.

    profile_col_name : str
        DataFrame column name for the user profile. Defaults to ``PROFILE_COL_NAME``.

    **kwargs
        Any additional keyword arguments are forwarded to ``_build_dataframe``
        as extra columns (scalar → broadcast, list → one value per row).

    Returns
    -------
    pd.DataFrame
        Processed results DataFrame.
    """

    if not queries:
        raise ValueError("queries must be a non-empty list of strings.")

    # --- Auth ---
    if access_token is None:
        access_token = get_apigee_access_token()

    # --- Build DataFrame ---
    df_kwargs = kwargs.copy()

    if user_profile is not None:
        df_kwargs[profile_col_name] = user_profile

    input_df = _build_dataframe(
        queries,
        query_col_name=query_col_name,
        **df_kwargs,
    )

    # --- Run pipeline ---
    processed_data = run_tachyon_pipeline(
        input_df,
        query_col_name=query_col_name,
        access_token=access_token,
        hit_score_fields=hit_score_fields,
        record_fields=record_fields,
        completeness_col=completeness_col,
    )

    return processed_data
