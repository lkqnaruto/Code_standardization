import re
import pandas as pd
from typing import List, Union, Dict, Any, Optional


# ============================================================
# Text preprocessing
# ============================================================

def preprocess_text(text):
    """Clean noisy tokens."""
    text = str(text)
    text = " ".join([i.lower() for i in text.split()])
    text = re.sub(r"[x]{2,}", "", text)
    text = re.sub(r"(https?://\S+)", "url", text)
    text = " ".join([re.sub(r"[^a-zA-Z]+", "", i) for i in text.split()])
    text = " ".join(text.split())
    return text.strip()


def clean_gif_references(names_list: List[str]) -> List[str]:
    """Remove .gif tokens."""
    if not isinstance(names_list, list):
        return re.sub(r"\b\S+\.gif\b", "", names_list, flags=re.IGNORECASE).strip()

    cleaned = []
    for name in names_list:
        if not isinstance(name, str):
            continue
        cleaned.append(
            re.sub(r"\b\S+\.gif\b", "", name, flags=re.IGNORECASE).strip()
        )
    return [c for c in cleaned if c]


# ============================================================
# Data processing
# ============================================================

def process_dataframe(
    df: pd.DataFrame,
    pred_sec_col: str = "pred_retrieved_sec_names",
    gt_sec_col: str = "Final_answer_sec_names",
) -> pd.DataFrame:
    """Normalize section-name columns (lowercase, strip noise, remove .gif).

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    pred_sec_col : str
        Column containing predicted section names (list of str per row).
    gt_sec_col : str
        Column containing ground-truth section names (list of str per row).
    """
    required = [pred_sec_col, gt_sec_col]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")

    df = df.copy()

    for col in [pred_sec_col, gt_sec_col]:
        df[col] = (
            df[col]
            .apply(clean_gif_references)
            .apply(lambda x: [preprocess_text(i) for i in x])
        )

    return df


# ============================================================
# KPI / Matching metrics
# ============================================================

def calculate_document_match_rate(
    df: pd.DataFrame,
    match_mode: str = "sec_id",
    return_df: bool = False,
    *,
    pred_doc_col: str = "pred_retrieved_doc_ids",
    pred_sec_col: str = "pred_retrieved_sec_names",
    gt_doc_col: str = "Final_answer_doc_id",
    gt_sec_col: str = "Final_answer_sec_names",
) -> Union[Dict[str, float], Dict[str, Any]]:
    """Compute retrieval match-rate KPIs.

    Works on any DataFrame as long as the four column names are provided.

    Parameters
    ----------
    df : pd.DataFrame
        Model output DataFrame, one row per query.
    match_mode : str
        Which metrics to compute:
        - ``"id"``     — document-ID match only.
        - ``"sec"``    — section-name match only.
        - ``"sec_id"`` — document+section pair match (+ doc-ID match).
        - ``"both"``   — all three metrics.
    return_df : bool
        If True, include the annotated DataFrame under key ``"df"``.
    pred_doc_col : str
        Column with predicted document IDs (list[str] per row).
    pred_sec_col : str
        Column with predicted section names (list[str] per row).
    gt_doc_col : str
        Column with the ground-truth document ID (str per row).
    gt_sec_col : str
        Column with ground-truth section names (list[str] per row).

    Returns
    -------
    dict
        ``{"doc_id_match_rate": float, ...}``; if *return_df* is True the
        dict also contains ``"df"`` with per-row match flags.
    """
    valid_modes = {"id", "sec", "sec_id", "both"}
    if match_mode not in valid_modes:
        raise ValueError(f"match_mode must be one of {valid_modes}")

    needed = [pred_doc_col, pred_sec_col, gt_doc_col, gt_sec_col]
    missing = [c for c in needed if c not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")

    df = df.copy()

    df["_pred_doc_prefix"] = df[pred_doc_col].map(
        lambda lst: [str(x).split("-")[0] for x in lst] if isinstance(lst, list) else []
    )

    metrics: Dict[str, float] = {}

    if match_mode in {"id", "sec_id", "both"}:
        df["doc_id_match"] = df.apply(
            lambda row: str(row[gt_doc_col]).split("-")[0]
            in set(row["_pred_doc_prefix"]),
            axis=1,
        )
        metrics["doc_id_match_rate"] = df["doc_id_match"].mean()

    if match_mode in {"sec", "both"}:
        df["sec_match"] = df.apply(
            lambda row: bool(
                set(row[gt_sec_col])
                & set(row[pred_sec_col])
            ),
            axis=1,
        )
        metrics["section_match_rate"] = df["sec_match"].mean()

    if match_mode in {"sec_id", "both"}:
        df["pred_pairs"] = df.apply(
            lambda row: {
                f"{doc.split('-')[0]}_{sec}"
                for doc, sec in zip(
                    row[pred_doc_col],
                    row[pred_sec_col],
                )
            },
            axis=1,
        )

        df["doc_sec_match"] = df.apply(
            lambda row: any(
                f"{str(row[gt_doc_col]).split('-')[0]}_{sec}"
                in row["pred_pairs"]
                for sec in row[gt_sec_col]
            ),
            axis=1,
        )

        metrics["doc_sec_id_match_rate"] = df["doc_sec_match"].mean()

    # Clean up internal columns before returning
    df = df.drop(columns=["_pred_doc_prefix"], errors="ignore")

    if return_df:
        return metrics | {"df": df}

    return metrics
