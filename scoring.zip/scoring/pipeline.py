"""
Orchestration: process rows through tachyon search, retry failures,
and compute evaluation metrics.
"""

from __future__ import annotations

import datetime
import getpass
import logging
import warnings
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from tqdm import tqdm

from .config import MAX_RETRY_ATTEMPTS, TOP_K
from .search import tachyon_search

warnings.filterwarnings("ignore")

# ============================================================
# Default field mappings
# ============================================================

DEFAULT_HIT_SCORE_FIELDS: Dict[str, str] = {
    "score": "pred_retrieval_score",
    "reranker_score": "pred_reranker_score",
}

DEFAULT_RECORD_FIELDS: Dict[str, str] = {
    "chunk_id": "pred_retrieved_chunk_ids",
    "document_id": "pred_retrieved_doc_ids",
    "section_name": "pred_retrieved_sec_names",
}

DEFAULT_COMPLETENESS_COL: str = "pred_retrieved_doc_ids"


# ============================================================
# Helpers
# ============================================================

def setup_logging() -> None:
    """Configure file + console logging."""
    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(f"tachyon_search_processing_{ts}.log"),
            logging.StreamHandler(),
        ],
    )


def get_current_info() -> Tuple[str, str]:
    """Return (current_utc_string, username)."""
    current_utc = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    try:
        username = getpass.getuser()
    except Exception:
        username = "Unknown"
    return current_utc, username


# ============================================================
# Core processing
# ============================================================

def _extract_hit_fields(
    hits: List[Dict[str, Any]],
    hit_score_fields: Dict[str, str],
) -> Tuple[List[dict], Dict[str, List[float]]]:
    """Pull records and score fields from raw hits.

    Returns (records, scores_dict) where scores_dict maps output column
    names to lists of numeric values extracted from hits.
    """
    records = [h["record"] for h in hits]
    scores_dict = {
        output_col: [h.get(hit_field, 0.0) for h in hits]
        for hit_field, output_col in hit_score_fields.items()
    }
    return records, scores_dict


def _safe_field(
    records: Any,
    field: str,
    top_k: int = TOP_K,
) -> List[str]:
    """Extract *field* from the first *top_k* records, or return []."""
    if isinstance(records, list):
        return [r.get(field, "") for r in records][:top_k]
    return []


def process_tachyon_search(
    data: pd.DataFrame,
    query_col: str,
    access_token: str,
    user_profile_col: str = "User Profile",
    max_attempts: int = MAX_RETRY_ATTEMPTS,
    top_k: int = TOP_K,
    hit_score_fields: Optional[Dict[str, str]] = None,
    record_fields: Optional[Dict[str, str]] = None,
    completeness_col: Optional[str] = None,
) -> pd.DataFrame:
    """
    Send every row through tachyon search.

    Rows that fail or return fewer than *top_k* results are retried up to
    *max_attempts* times. Returns a DataFrame of all successfully-processed rows.

    Parameters
    ----------
    hit_score_fields : dict, optional
        Mapping of hit-level field names to output column names.
        Default: ``DEFAULT_HIT_SCORE_FIELDS`` (score, reranker_score).
    record_fields : dict, optional
        Mapping of record-level field names to output column names.
        Default: ``DEFAULT_RECORD_FIELDS`` (chunk_id, document_id, section_name).
    completeness_col : str, optional
        Output column name used to check row completeness for retries.
        Must be one of the values in *record_fields*.
        Default: ``DEFAULT_COMPLETENESS_COL`` (pred_retrieved_doc_ids).
    """

    if hit_score_fields is None:
        hit_score_fields = DEFAULT_HIT_SCORE_FIELDS
    if record_fields is None:
        record_fields = DEFAULT_RECORD_FIELDS
    if completeness_col is None:
        completeness_col = DEFAULT_COMPLETENESS_COL

    if completeness_col not in record_fields.values():
        raise ValueError(
            f"completeness_col {completeness_col!r} must be one of the "
            f"record_fields output columns: {list(record_fields.values())}"
        )

    attempt = 0
    current_data = data.copy()
    complete_results: List[pd.DataFrame] = []

    while True:
        attempt += 1
        logging.info("Processing attempt %d", attempt)

        results_tachyon: List[Any] = []
        hit_scores: Dict[str, List[Any]] = {
            col: [] for col in hit_score_fields.values()
        }

        for i in tqdm(range(len(current_data)), desc=f"Attempt {attempt}"):
            try:
                user_profile_raw = current_data[user_profile_col].iloc[i]
                user_profile_list = [
                    item.strip() for item in user_profile_raw.split(";")
                ]

                result = tachyon_search(
                    current_data[query_col].iloc[i],
                    user_profile_list,
                    access_token,
                )

                if (
                    result
                    and "result" in result
                    and "hits" in result["result"]
                ):
                    records, scores_dict = _extract_hit_fields(
                        result["result"]["hits"], hit_score_fields
                    )
                else:
                    raise ValueError("Invalid result structure")

                results_tachyon.append(records)
                for col, values in scores_dict.items():
                    hit_scores[col].append(values)

            except Exception as exc:
                logging.warning("Error processing row %d: %s", i, exc)
                results_tachyon.append({})
                for col in hit_scores:
                    hit_scores[col].append(0)

        # Attach results
        attempt_data = current_data.copy()
        attempt_data["attempt"] = attempt
        attempt_data["pred_results_tachyon"] = results_tachyon
        for col, values in hit_scores.items():
            attempt_data[col] = values

        try:
            for record_field, output_col in record_fields.items():
                attempt_data[output_col] = attempt_data[
                    "pred_results_tachyon"
                ].apply(lambda x, f=record_field: _safe_field(x, f, top_k))

        except Exception as exc:
            logging.error("Error extracting fields: %s", exc)
            break

        # Split complete / incomplete
        completeness_len_col = f"len_{completeness_col}"
        attempt_data[completeness_len_col] = attempt_data[
            completeness_col
        ].apply(len)

        complete = attempt_data[
            attempt_data[completeness_len_col] == top_k
        ]
        incomplete = attempt_data[
            attempt_data[completeness_len_col] != top_k
        ]

        if len(complete) > 0:
            complete_results.append(complete)
            logging.info(
                "Attempt %d: Found %d complete results",
                attempt,
                len(complete),
            )

        logging.info(
            "Attempt %d: %d rows still incomplete",
            attempt,
            len(incomplete),
        )

        if len(incomplete) == 0:
            logging.info("All rows processed successfully")
            break

        if attempt >= max_attempts:
            logging.warning(
                "Max attempts (%d) reached. %d rows still incomplete",
                max_attempts,
                len(incomplete),
            )
            break

        current_data = incomplete

    if complete_results:
        final_df = pd.concat(complete_results, ignore_index=True)
        logging.info(
            "Total complete results across all attempts: %d",
            len(final_df),
        )
        return final_df

    logging.warning("No complete results found in any attempt")
    return pd.DataFrame()


# ============================================================
# High-level pipeline
# ============================================================

def run_tachyon_pipeline(
    input_data: pd.DataFrame,
    query_col_name: str,
    access_token: str,
    hit_score_fields: Optional[Dict[str, str]] = None,
    record_fields: Optional[Dict[str, str]] = None,
    completeness_col: Optional[str] = None,
) -> pd.DataFrame:
    """
    End-to-end Tachyon pipeline:
    1. Log metadata
    2. Run process_tachyon_search with the specified query column
    3. Print summary
    """

    current_time, user = get_current_info()

    print(
        f"Current Date and Time (UTC): {current_time}\n"
        f"Current User's Login: {user}"
    )

    setup_logging()
    logging.info("Processing started at %s by %s", current_time, user)

    try:
        processed_data = process_tachyon_search(
            input_data, query_col_name, access_token,
            hit_score_fields=hit_score_fields,
            record_fields=record_fields,
            completeness_col=completeness_col,
        )

        if not processed_data.empty:
            print("\nProcessing Summary:")
            for att in processed_data["attempt"].unique():
                n = len(processed_data[processed_data["attempt"] == att])
                print(f"  Attempt {att}: {n} complete results")

            logging.info("Processing completed successfully")
        else:
            logging.warning("No complete results to save")

    except Exception as exc:
        logging.error("Processing failed: %s", exc)
        raise

    return processed_data
