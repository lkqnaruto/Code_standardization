from __future__ import annotations

import datetime
import json
import uuid
from typing import Any, Dict, List, Optional

import requests

from .config import (
    API_KEY,
    CLIENT_ID,
    COLLECTION_ID,
    DEFAULT_FIELD_FILTER_KEY,
    DEFAULT_RERANKER,
    DEFAULT_SEARCH_COUNT,
    DEFAULT_SEARCH_TYPE,
    SEARCH_URL,
    USECASE_ID,
)


# ============================================================
# Default header / payload templates
# ============================================================

def _default_headers(
    access_token: str,
    *,
    api_key: str = API_KEY,
    client_id: str = CLIENT_ID,
    usecase_id: str = USECASE_ID,
) -> Dict[str, str]:
    """Build the default Tachyon header dict."""
    request_id = str(uuid.uuid4())
    request_date = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000")
    return {
        "x-request-id": request_id,
        "x-wf-request-date": request_date,
        "x-correlation-id": request_id,
        "x-wf-client-id": client_id,
        "Authorization": f"Bearer {access_token}",
        "x-wf-api-key": api_key,
        "x-wf-usecase-id": usecase_id,
        "Content-Type": "application/json",
    }


def _default_payload(
    query: str,
    user_profiles: List[str],
    *,
    collection_id: str = COLLECTION_ID,
    search_type: str = DEFAULT_SEARCH_TYPE,
    search_count: int = DEFAULT_SEARCH_COUNT,
    reranker: str = DEFAULT_RERANKER,
    field_filter_key: str = DEFAULT_FIELD_FILTER_KEY,
) -> Dict[str, Any]:
    """Build the default Tachyon payload dict."""
    return {
        "query": query,
        "collectionId": collection_id,
        "searchType": search_type,
        "searchCount": search_count,
        "reranker": reranker,
        field_filter_key: user_profiles,
    }


# ============================================================
# Search function
# ============================================================

def tachyon_search(
    query: str,
    user_profiles: List[str],
    access_token: str,
    *,
    url: str = SEARCH_URL,
    usecase_id: str = USECASE_ID,
    collection_id: str = COLLECTION_ID,
    api_key: str = API_KEY,
    search_type: str = DEFAULT_SEARCH_TYPE,
    search_count: int = DEFAULT_SEARCH_COUNT,
    reranker: str = DEFAULT_RERANKER,
    client_id: str = CLIENT_ID,
    field_filter_key: str = DEFAULT_FIELD_FILTER_KEY,
    headers: Optional[Dict[str, str]] = None,
    payload: Optional[Dict[str, Any]] = None,
    extra_headers: Optional[Dict[str, str]] = None,
    extra_payload: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Call a search API (Tachyon hybrid + reranker by default).

    Flexibility
    -----------
    There are three levels of customisation, from least to most:

    1. **Parameter overrides** — change individual values (``api_key``,
       ``search_type``, ``reranker``, …) while keeping the default
       header / payload structure.

    2. **Extra dicts** — ``extra_headers`` / ``extra_payload`` are merged
       *on top of* the defaults, so you can add or override specific keys
       without rebuilding the whole dict.

    3. **Full replacement** — pass ``headers`` / ``payload`` to supply
       your own dicts entirely.  When provided, parameter-level values
       and ``extra_*`` dicts are ignored for that component.

    Parameters
    ----------
    query : str
        The search query string.
    user_profiles : list[str]
        User role / profile tags for field filtering.
    access_token : str
        Bearer token for authorisation.
    url : str
        Search endpoint URL.
    usecase_id, collection_id, api_key, search_type, search_count,
    reranker, client_id, field_filter_key : str | int
        Individual config values — used only when ``headers`` / ``payload``
        are not supplied.
    headers : dict, optional
        Fully custom headers dict.  Replaces the default headers entirely.
    payload : dict, optional
        Fully custom payload dict.  Replaces the default payload entirely.
    extra_headers : dict, optional
        Merged on top of the default headers (ignored if ``headers`` is set).
    extra_payload : dict, optional
        Merged on top of the default payload (ignored if ``payload`` is set).

    Returns
    -------
    dict
        Parsed JSON response from the API.
    """

    # --- Build headers ---
    if headers is not None:
        final_headers = headers
    else:
        final_headers = _default_headers(
            access_token,
            api_key=api_key,
            client_id=client_id,
            usecase_id=usecase_id,
        )
        if extra_headers:
            final_headers.update(extra_headers)

    # --- Build payload ---
    if payload is not None:
        final_payload = payload
    else:
        final_payload = _default_payload(
            query,
            user_profiles,
            collection_id=collection_id,
            search_type=search_type,
            search_count=search_count,
            reranker=reranker,
            field_filter_key=field_filter_key,
        )
        if extra_payload:
            final_payload.update(extra_payload)

    response = requests.post(
        url,
        headers=final_headers,
        data=json.dumps(final_payload),
    )

    response.raise_for_status()
    return response.json()
