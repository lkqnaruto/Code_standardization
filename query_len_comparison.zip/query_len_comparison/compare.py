"""
Query Length Distribution Comparison Module.

Compare the distribution of query lengths between two datasets using
statistical tests and visualisations.

Usage
-----
    from query_len_comparison import compare_query_length_distributions

    result = compare_query_length_distributions(
        queries_a=["what is AI", "how to cook"],
        queries_b=["short", "a very long query with many words in it"],
        length_unit="word",
    )
    print(result.summary())
    result.plot()

CLI
---
    python -m query_len_comparison.compare \\
        --file_a queries_a.txt --file_b queries_b.txt --unit word
"""

from __future__ import annotations

import argparse
import logging
from dataclasses import dataclass, field
from typing import Literal, Sequence

import numpy as np
import pandas as pd
from scipy import stats

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
logger = logging.getLogger(__name__)

LengthUnit = Literal["char", "word"]


# ──────────────────────────────────────────────
# Length computation
# ──────────────────────────────────────────────

def query_lengths(
    queries: Sequence[str],
    unit: LengthUnit = "word",
) -> np.ndarray:
    """Compute the length of each query.

    Parameters
    ----------
    queries : sequence of str
        List of query strings.
    unit : {"char", "word"}
        Measure length in characters or white-space–separated words.

    Returns
    -------
    np.ndarray
        1-D array of integer lengths.
    """
    if unit == "char":
        return np.array([len(q.strip()) for q in queries], dtype=int)
    elif unit == "word":
        return np.array([len(q.strip().split()) for q in queries], dtype=int)
    else:
        raise ValueError(f"Unknown unit={unit!r}. Choose 'char' or 'word'.")


# ──────────────────────────────────────────────
# Statistical helpers
# ──────────────────────────────────────────────

def _compute_psi(
    expected: np.ndarray,
    actual: np.ndarray,
    bins: int = 20,
    eps: float = 1e-6,
) -> float:
    """Population Stability Index over length histograms."""
    # Build shared bin edges from combined data
    combined = np.concatenate([expected, actual])
    _, edges = np.histogram(combined, bins=bins)
    hist_e, _ = np.histogram(expected, bins=edges, density=True)
    hist_a, _ = np.histogram(actual, bins=edges, density=True)
    # Normalise to probability distributions
    hist_e = hist_e / (hist_e.sum() + eps)
    hist_a = hist_a / (hist_a.sum() + eps)
    hist_e = np.clip(hist_e, eps, None)
    hist_a = np.clip(hist_a, eps, None)
    return float(np.sum((hist_a - hist_e) * np.log(hist_a / hist_e)))


def _descriptive_stats(lengths: np.ndarray) -> dict[str, float]:
    """Compute descriptive statistics for a length array."""
    return {
        "count": int(len(lengths)),
        "mean": float(np.mean(lengths)),
        "std": float(np.std(lengths, ddof=1)) if len(lengths) > 1 else 0.0,
        "min": int(np.min(lengths)),
        "p25": float(np.percentile(lengths, 25)),
        "median": float(np.median(lengths)),
        "p75": float(np.percentile(lengths, 75)),
        "max": int(np.max(lengths)),
    }


def _cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    """Compute Cohen's d effect size (pooled std)."""
    n_a, n_b = len(a), len(b)
    if n_a < 2 or n_b < 2:
        return 0.0
    var_a = np.var(a, ddof=1)
    var_b = np.var(b, ddof=1)
    pooled_std = np.sqrt(((n_a - 1) * var_a + (n_b - 1) * var_b) / (n_a + n_b - 2))
    if pooled_std == 0:
        return 0.0
    return float((np.mean(a) - np.mean(b)) / pooled_std)


def _chi_squared_test(
    a: np.ndarray,
    b: np.ndarray,
    bins: int = 20,
) -> tuple[float, float]:
    """Chi-squared test of homogeneity on binned length frequencies.

    Returns (chi2_statistic, p_value).
    """
    combined = np.concatenate([a, b])
    _, edges = np.histogram(combined, bins=bins)
    counts_a, _ = np.histogram(a, bins=edges)
    counts_b, _ = np.histogram(b, bins=edges)
    # Drop bins where both counts are 0
    mask = (counts_a + counts_b) > 0
    counts_a = counts_a[mask]
    counts_b = counts_b[mask]
    if len(counts_a) < 2:
        return 0.0, 1.0
    contingency = np.array([counts_a, counts_b])
    chi2, p, _, _ = stats.chi2_contingency(contingency)
    return float(chi2), float(p)


def _permutation_test(
    a: np.ndarray,
    b: np.ndarray,
    n_permutations: int = 10_000,
    random_state: int = 42,
) -> tuple[float, float]:
    """Two-sample permutation test for difference in means.

    Returns (observed_diff, p_value).
    """
    rng = np.random.default_rng(random_state)
    observed = float(np.mean(a) - np.mean(b))
    combined = np.concatenate([a, b]).copy()
    n_a = len(a)
    count = 0
    for _ in range(n_permutations):
        rng.shuffle(combined)
        perm_diff = np.mean(combined[:n_a]) - np.mean(combined[n_a:])
        if abs(perm_diff) >= abs(observed):
            count += 1
    return observed, count / n_permutations


def _bootstrap_mean_diff_ci(
    a: np.ndarray,
    b: np.ndarray,
    n_bootstrap: int = 10_000,
    confidence: float = 0.95,
    random_state: int = 42,
) -> tuple[float, float, float]:
    """Bootstrap confidence interval for (mean_a − mean_b).

    Returns (observed_diff, ci_lower, ci_upper).
    """
    rng = np.random.default_rng(random_state)
    observed = float(np.mean(a) - np.mean(b))
    diffs = np.empty(n_bootstrap)
    for i in range(n_bootstrap):
        sample_a = rng.choice(a, size=len(a), replace=True)
        sample_b = rng.choice(b, size=len(b), replace=True)
        diffs[i] = np.mean(sample_a) - np.mean(sample_b)
    alpha = 1 - confidence
    ci_lo = float(np.percentile(diffs, 100 * alpha / 2))
    ci_hi = float(np.percentile(diffs, 100 * (1 - alpha / 2)))
    return observed, ci_lo, ci_hi


# ──────────────────────────────────────────────
# Result container
# ──────────────────────────────────────────────

@dataclass
class QueryLenComparisonResult:
    """Container for query-length comparison results."""

    unit: str
    stats_a: dict[str, float] = field(default_factory=dict)
    stats_b: dict[str, float] = field(default_factory=dict)
    lengths_a: np.ndarray = field(default_factory=lambda: np.array([]))
    lengths_b: np.ndarray = field(default_factory=lambda: np.array([]))

    # Statistical tests
    welch_t_statistic: float = 0.0
    welch_t_pvalue: float = 1.0
    ks_statistic: float = 0.0
    ks_pvalue: float = 1.0
    mannwhitney_statistic: float = 0.0
    mannwhitney_pvalue: float = 1.0
    chi2_statistic: float = 0.0
    chi2_pvalue: float = 1.0
    permutation_pvalue: float = 1.0
    psi: float = 0.0

    # Effect size & confidence interval
    cohens_d: float = 0.0
    bootstrap_ci_lower: float = 0.0
    bootstrap_ci_upper: float = 0.0

    # Mean difference
    mean_diff: float = 0.0
    mean_diff_pct: float = 0.0

    # Significance threshold
    alpha: float = 0.05

    def summary(self) -> str:
        """Return a human-readable summary."""
        lines = [
            "=" * 62,
            f"  Query Length Distribution Comparison  (unit: {self.unit})",
            "=" * 62,
            "",
            f"  {'Metric':<20s}  {'Dataset A':>12s}  {'Dataset B':>12s}",
            f"  {'-'*20}  {'-'*12}  {'-'*12}",
        ]
        for key in ["count", "mean", "std", "min", "p25", "median", "p75", "max"]:
            a_val = self.stats_a.get(key, 0)
            b_val = self.stats_b.get(key, 0)
            fmt = "d" if key in ("count", "min", "max") else ".2f"
            lines.append(f"  {key:<20s}  {a_val:>12{fmt}}  {b_val:>12{fmt}}")

        lines += [
            "",
            "  Hypothesis Tests",
            f"  {'-'*56}",
            f"  {'Test':<24s}  {'Statistic':>12s}  {'p-value':>12s}  {'Sig?':>5s}",
            f"  {'-'*24}  {'-'*12}  {'-'*12}  {'-'*5}",
        ]

        tests = [
            ("Welch's t-test",       self.welch_t_statistic,       self.welch_t_pvalue),
            ("KS two-sample",        self.ks_statistic,            self.ks_pvalue),
            ("Mann-Whitney U",       self.mannwhitney_statistic,   self.mannwhitney_pvalue),
            ("Chi-squared",          self.chi2_statistic,          self.chi2_pvalue),
            ("Permutation (mean)",   self.mean_diff,               self.permutation_pvalue),
        ]
        for name, stat, pval in tests:
            sig = "***" if pval < 0.001 else ("**" if pval < 0.01 else ("*" if pval < self.alpha else ""))
            lines.append(f"  {name:<24s}  {stat:>12.4f}  {pval:>12.4e}  {sig:>5s}")

        lines += [
            "",
            "  Effect Size & CI",
            f"  {'-'*56}",
            f"  Cohen's d           : {self.cohens_d:+.4f}",
            f"  Mean difference     : {self.mean_diff:+.2f} ({self.mean_diff_pct:+.1f}%)",
            f"  Bootstrap 95% CI    : [{self.bootstrap_ci_lower:+.2f}, {self.bootstrap_ci_upper:+.2f}]",
            f"  PSI                 : {self.psi:.4f}",
            "",
        ]

        # Cohen's d interpretation
        d = abs(self.cohens_d)
        if d >= 0.8:
            d_label = "large"
        elif d >= 0.5:
            d_label = "medium"
        elif d >= 0.2:
            d_label = "small"
        else:
            d_label = "negligible"

        # Overall verdict — count how many tests reject H0
        p_values = [self.welch_t_pvalue, self.ks_pvalue,
                     self.mannwhitney_pvalue, self.chi2_pvalue,
                     self.permutation_pvalue]
        n_sig = sum(1 for p in p_values if p < self.alpha)

        lines.append(f"  Interpretation (α = {self.alpha})")
        lines.append(f"  {'-'*56}")
        lines.append(f"  • {n_sig}/5 hypothesis tests reject H₀ (equal distributions)")
        lines.append(f"  • Effect size: Cohen's d = {self.cohens_d:+.2f} ({d_label})")

        if n_sig >= 4:
            lines.append("  ⇒ Strong evidence that query-length distributions differ")
        elif n_sig >= 2:
            lines.append("  ⇒ Moderate evidence that query-length distributions differ")
        else:
            lines.append("  ⇒ No convincing evidence of a difference")

        if self.bootstrap_ci_lower > 0 or self.bootstrap_ci_upper < 0:
            lines.append("  • Bootstrap CI excludes 0 → mean difference is significant")
        else:
            lines.append("  • Bootstrap CI contains 0 → mean difference not significant")

        if self.psi > 0.25:
            lines.append("  • PSI > 0.25 → major distributional shift")
        elif self.psi > 0.10:
            lines.append("  • PSI 0.10–0.25 → moderate distributional shift")
        else:
            lines.append("  • PSI < 0.10 → no significant distributional shift")

        lines.append("=" * 62)
        return "\n".join(lines)

    def to_dataframe(self) -> pd.DataFrame:
        """Return per-query lengths as a tidy DataFrame."""
        df_a = pd.DataFrame({"length": self.lengths_a, "dataset": "A"})
        df_b = pd.DataFrame({"length": self.lengths_b, "dataset": "B"})
        return pd.concat([df_a, df_b], ignore_index=True)

    def plot(
        self,
        bins: int = 30,
        figsize: tuple[int, int] = (14, 5),
        title: str | None = None,
    ):
        """Plot side-by-side histogram, overlaid density, and box plot.

        Returns the matplotlib Figure.
        """
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(1, 3, figsize=figsize)
        label_unit = "characters" if self.unit == "char" else "words"

        # 1. Overlaid histograms
        ax = axes[0]
        combined = np.concatenate([self.lengths_a, self.lengths_b])
        bin_edges = np.histogram_bin_edges(combined, bins=bins)
        ax.hist(self.lengths_a, bins=bin_edges, alpha=0.55, label="Dataset A",
                color="#1f77b4", edgecolor="white", linewidth=0.5)
        ax.hist(self.lengths_b, bins=bin_edges, alpha=0.55, label="Dataset B",
                color="#ff7f0e", edgecolor="white", linewidth=0.5)
        ax.set_xlabel(f"Query length ({label_unit})")
        ax.set_ylabel("Count")
        ax.set_title("Histogram")
        ax.legend()

        # 2. KDE density
        ax = axes[1]
        from scipy.stats import gaussian_kde
        if len(self.lengths_a) > 1 and np.std(self.lengths_a) > 0:
            kde_a = gaussian_kde(self.lengths_a.astype(float))
            x_grid = np.linspace(combined.min(), combined.max(), 300)
            ax.plot(x_grid, kde_a(x_grid), color="#1f77b4", lw=2, label="Dataset A")
        if len(self.lengths_b) > 1 and np.std(self.lengths_b) > 0:
            kde_b = gaussian_kde(self.lengths_b.astype(float))
            x_grid = np.linspace(combined.min(), combined.max(), 300)
            ax.plot(x_grid, kde_b(x_grid), color="#ff7f0e", lw=2, label="Dataset B")
        ax.set_xlabel(f"Query length ({label_unit})")
        ax.set_ylabel("Density")
        ax.set_title("Density (KDE)")
        ax.legend()

        # 3. Boxplot
        ax = axes[2]
        bp = ax.boxplot(
            [self.lengths_a, self.lengths_b],
            labels=["Dataset A", "Dataset B"],
            patch_artist=True,
            widths=0.5,
        )
        bp["boxes"][0].set_facecolor("#1f77b4")
        bp["boxes"][0].set_alpha(0.6)
        bp["boxes"][1].set_facecolor("#ff7f0e")
        bp["boxes"][1].set_alpha(0.6)
        ax.set_ylabel(f"Query length ({label_unit})")
        ax.set_title("Box Plot")

        fig.suptitle(
            title or f"Query Length Distribution Comparison ({label_unit})",
            fontsize=13,
            fontweight="bold",
            y=1.02,
        )
        plt.tight_layout()
        return fig


# ──────────────────────────────────────────────
# Main comparison function
# ──────────────────────────────────────────────

def compare_query_length_distributions(
    queries_a: Sequence[str],
    queries_b: Sequence[str],
    *,
    length_unit: LengthUnit = "word",
    psi_bins: int = 20,
    verbose: bool = True,
) -> QueryLenComparisonResult:
    """Compare query length distributions between two datasets.

    Parameters
    ----------
    queries_a : sequence of str
        First (reference) set of queries.
    queries_b : sequence of str
        Second (comparison) set of queries.
    length_unit : {"char", "word"}
        Measure query length in characters or words (default: ``"word"``).
    psi_bins : int
        Number of bins for PSI histogram (default 20).
    verbose : bool
        Log progress messages.

    Returns
    -------
    QueryLenComparisonResult
        Dataclass with statistics, test results, and plotting methods.
    """
    lens_a = query_lengths(queries_a, unit=length_unit)
    lens_b = query_lengths(queries_b, unit=length_unit)

    if verbose:
        logger.info("Dataset A: %d queries  |  Dataset B: %d queries", len(lens_a), len(lens_b))

    stats_a = _descriptive_stats(lens_a)
    stats_b = _descriptive_stats(lens_b)

    # ── Hypothesis tests ──

    # 1. Welch's t-test (does not assume equal variances)
    if len(lens_a) > 1 and len(lens_b) > 1:
        t_stat, t_p = stats.ttest_ind(lens_a, lens_b, equal_var=False)
    else:
        t_stat, t_p = 0.0, 1.0

    # 2. KS two-sample test (non-parametric, shape-sensitive)
    ks_stat, ks_p = stats.ks_2samp(lens_a, lens_b)

    # 3. Mann-Whitney U test (non-parametric, rank-based)
    if len(lens_a) > 0 and len(lens_b) > 0:
        mw_stat, mw_p = stats.mannwhitneyu(lens_a, lens_b, alternative="two-sided")
    else:
        mw_stat, mw_p = 0.0, 1.0

    # 4. Chi-squared test on binned distributions
    chi2_stat, chi2_p = _chi_squared_test(lens_a, lens_b, bins=psi_bins)

    # 5. Permutation test (exact, non-parametric)
    if verbose:
        logger.info("Running permutation test (10 000 iterations) …")
    _, perm_p = _permutation_test(lens_a, lens_b)

    # ── Effect size & CI ──
    cd = _cohens_d(lens_a, lens_b)

    if verbose:
        logger.info("Computing bootstrap 95%% CI for mean difference …")
    _, ci_lo, ci_hi = _bootstrap_mean_diff_ci(lens_a, lens_b)

    # PSI
    psi = _compute_psi(lens_a, lens_b, bins=psi_bins)

    # Mean difference
    mean_diff = stats_b["mean"] - stats_a["mean"]
    mean_diff_pct = (mean_diff / stats_a["mean"] * 100) if stats_a["mean"] != 0 else 0.0

    result = QueryLenComparisonResult(
        unit=length_unit,
        stats_a=stats_a,
        stats_b=stats_b,
        lengths_a=lens_a,
        lengths_b=lens_b,
        welch_t_statistic=t_stat,
        welch_t_pvalue=t_p,
        ks_statistic=ks_stat,
        ks_pvalue=ks_p,
        mannwhitney_statistic=mw_stat,
        mannwhitney_pvalue=mw_p,
        chi2_statistic=chi2_stat,
        chi2_pvalue=chi2_p,
        permutation_pvalue=perm_p,
        psi=psi,
        cohens_d=cd,
        bootstrap_ci_lower=ci_lo,
        bootstrap_ci_upper=ci_hi,
        mean_diff=mean_diff,
        mean_diff_pct=mean_diff_pct,
    )

    if verbose:
        logger.info(
            "Welch t=%.4f (p=%.2e) | KS=%.4f (p=%.2e) | MWU=%.1f (p=%.2e)",
            t_stat, t_p, ks_stat, ks_p, mw_stat, mw_p,
        )
        logger.info(
            "Chi²=%.2f (p=%.2e) | Perm p=%.4f | Cohen's d=%+.3f | PSI=%.4f",
            chi2_stat, chi2_p, perm_p, cd, psi,
        )

    return result


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def _load_queries(path: str) -> list[str]:
    """Load queries from a text file (one query per line)."""
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]


def _demo():
    """Run a small synthetic demo."""
    rng = np.random.default_rng(42)

    # Dataset A: short queries (2-5 words)
    short_templates = [
        "what is {}", "how to {}", "best {}", "define {}",
        "{} meaning", "{} vs {}", "why {}", "{} tutorial",
    ]
    topics = ["machine learning", "deep learning", "python", "NLP",
              "data science", "clustering", "regression", "transformers"]
    queries_a = []
    for _ in range(200):
        tmpl = rng.choice(short_templates)
        fills = rng.choice(topics, size=tmpl.count("{}"), replace=True).tolist()
        queries_a.append(tmpl.format(*fills))

    # Dataset B: longer queries (5-15 words)
    long_templates = [
        "what is the difference between {} and {} in practice",
        "how do I implement {} using {} in python step by step",
        "explain the concept of {} with examples and code",
        "what are the advantages of {} over {} for large datasets",
        "can you provide a tutorial on {} for beginners using {}",
        "compare {} and {} in terms of performance and accuracy",
    ]
    queries_b = []
    for _ in range(200):
        tmpl = rng.choice(long_templates)
        fills = rng.choice(topics, size=tmpl.count("{}"), replace=True).tolist()
        queries_b.append(tmpl.format(*fills))

    print("Sample queries A:", queries_a[:3])
    print("Sample queries B:", queries_b[:3])
    print()

    result = compare_query_length_distributions(queries_a, queries_b, length_unit="word")
    print(result.summary())

    return result


def main():
    parser = argparse.ArgumentParser(
        description="Compare query length distributions between two datasets.",
    )
    parser.add_argument("--file_a", type=str, default=None,
                        help="Path to text file for Dataset A (one query per line).")
    parser.add_argument("--file_b", type=str, default=None,
                        help="Path to text file for Dataset B (one query per line).")
    parser.add_argument("--unit", type=str, default="word", choices=["char", "word"],
                        help="Length unit: 'char' or 'word' (default: word).")
    parser.add_argument("--psi_bins", type=int, default=20,
                        help="Number of bins for PSI (default: 20).")
    parser.add_argument("--plot", action="store_true",
                        help="Show comparison plots.")
    parser.add_argument("--demo", action="store_true",
                        help="Run built-in demo with synthetic data.")
    args = parser.parse_args()

    if args.demo or (args.file_a is None and args.file_b is None):
        result = _demo()
        if args.plot:
            result.plot()
            import matplotlib.pyplot as plt
            plt.show()
        return

    if args.file_a is None or args.file_b is None:
        parser.error("Both --file_a and --file_b are required unless --demo is set.")

    queries_a = _load_queries(args.file_a)
    queries_b = _load_queries(args.file_b)

    result = compare_query_length_distributions(
        queries_a, queries_b,
        length_unit=args.unit,
        psi_bins=args.psi_bins,
    )
    print(result.summary())

    if args.plot:
        result.plot()
        import matplotlib.pyplot as plt
        plt.show()


if __name__ == "__main__":
    main()
