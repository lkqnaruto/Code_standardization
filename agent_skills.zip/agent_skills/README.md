# Query Length Validation Toolkit

A two-step toolkit for comparing the **length distribution** of two query
sets and writing a measured validation report:

1. `query_length_comparison.py` — runs a panel of hypothesis tests, computes
   effect sizes and PSI, and emits JSON + summary text + plots.
2. `query-length-validation/build_report.py` — turns the JSON + plots into a
   `.docx` report. Either builds from scratch, or inserts the analysis into
   an existing branded template under matching headings.

The narrative is intentionally cautious — "consistent with" rather than
"proves", effect sizes alongside p-values, explicit limitations.

The Python scripts work as standalone CLIs. The "Use with GitHub Copilot"
section below describes how to drive them from Copilot Chat in VS Code so
you can run the whole workflow from a natural-language prompt.

## Prerequisites

```
python >= 3.10
numpy, pandas, scipy, matplotlib, python-docx
```

## Project layout

```
agent_skills/
├── README.md                              ← you are here
├── query_length_comparison.py             ← Step 1: stats + plots CLI
├── query-length-validation/
│   ├── build_report.py                    ← Step 2: .docx renderer CLI
│   └── SKILL.md                           ← workflow spec (tone rules, etc.)
└── examples/
    ├── queries_production.json            ← Set A (short user queries)
    ├── queries_rewritten.json             ← Set B (longer rewrites)
    ├── make_template.py                   ← optional starter-template generator
    ├── corporate_template.docx            ← simple template with default headings
    ├── complex_template.docx              ← realistic H1/H2/H3 nested template
    └── output/                            ← results.json, summary.txt, plots, .docx
```

`SKILL.md` contains the full workflow spec — input gathering, tone rules,
failure modes. It's just a Markdown reference; nothing in the toolkit
requires it to live in any particular location.

## Quick start

Try the built-in demo (no input files needed):

```bash
python query_length_comparison.py --demo --output_dir /tmp/qlc_demo
```

This produces `results.json`, `summary.txt`, `distributions.png`, `ecdf.png`
in `/tmp/qlc_demo/`. Synthetic data is generated with two clearly different
length distributions so all the tests have something to talk about.

## Step 1 — Run the stats CLI

```bash
python query_length_comparison.py \
    --file_a   examples/queries_production.json \
    --file_b   examples/queries_rewritten.json \
    --label_a  "Production" \
    --label_b  "Rewritten" \
    --unit     word \
    --output_dir examples/output
```

Inputs may be `.json` (list of strings) or `.txt` (one query per line).
Other useful flags: `--unit char`, `--alpha 0.01`, `--psi_bins 30`,
`--n_permutations 50000`. See `--help` for the rest.

## Step 2 — Render the .docx report

### Mode A — Build from scratch

```bash
python query-length-validation/build_report.py \
    --results_json  examples/output/results.json \
    --distributions examples/output/distributions.png \
    --ecdf          examples/output/ecdf.png \
    --output_docx   examples/output/report.docx \
    --analyst       "Your Name" \
    --context       "Pre-deployment comparison of production vs. rewritten queries."
```

The script creates an 8-section report (Purpose, Data summary, Methods,
Hypothesis test results, Effect size, Visualisations, Findings, Assessment).

### Mode B — Insert into an existing template

When you already have a branded `.docx` with your fonts, headers, page setup,
etc., pass it via `--template`. The script opens the template and inserts
each section's content immediately after the matching heading — your
template's styling and content are otherwise untouched.

```bash
# Insert ALL sections under default heading names
python query-length-validation/build_report.py \
    --template      my_template.docx \
    --results_json  examples/output/results.json \
    --distributions examples/output/distributions.png \
    --ecdf          examples/output/ecdf.png \
    --output_docx   report.docx

# Insert only specific sections
python query-length-validation/build_report.py \
    --template     my_template.docx \
    --results_json examples/output/results.json \
    --sections     findings,assessment \
    --output_docx  report.docx

# Target a specific nested subsection (e.g. H3 "3.1.4 Data and Input")
python query-length-validation/build_report.py \
    --template      my_template.docx \
    --results_json  examples/output/results.json \
    --sections      data_summary \
    --section-map  'data_summary="3.1.4 Data and Input"' \
    --output_docx   report.docx
```

#### Section keys

```
data_summary  methods  hypothesis_tests  effect_size  visualizations  findings  assessment
```

#### How heading matching works

The matcher tries **exact** case-insensitive match first, then falls back to
a **normalised** match that strips numbering. So all of these target the
same heading:

| Template heading | Spec that matches |
|---|---|
| `Findings` | `findings="Findings"` |
| `7. Findings` | `findings="Findings"` *or* `findings="7. Findings"` |
| `3.1.4 Data and Input` | `data_summary="3.1.4 Data and Input"` *or* `data_summary="Data and Input"` |
| `Data and Input` (multiple — H2 and H3) | `data_summary="Data and Input@3"` (level qualifier) |

If the same title appears multiple times at the same level, include the
numbered form to disambiguate. If a requested heading isn't found the script
warns and skips that section; pass `--strict` to fail instead.

---

## Use with GitHub Copilot Chat in VS Code

Open this folder (`agent_skills/`) as your VS Code workspace, then pick one
of the two integration styles below. Both produce the same result; they
differ only in *how* you trigger the workflow.

**Important:** Copilot Chat must be in **agent mode** (toggle at the bottom
of the Chat panel) for it to actually run the Python scripts. In ask mode
Copilot will only print the commands you'd need to run yourself.

### Option 1 — Workspace instructions (always on)

Create `.github/copilot-instructions.md` in this workspace. Copilot reads it
automatically before every chat, so you can just say things like *"compare
queries_production.json and queries_rewritten.json on length, write the
docx"* and Copilot already knows the workflow.

Contents to put in the file:

````markdown
# Workspace instructions

This workspace contains a query-length comparison toolkit. When the user
asks to compare two query sets on length, validate query sets, or produce a
.docx write-up comparing them, follow this workflow.

## Gather these inputs first

1. Paths to the two query files (.json list of strings, or .txt one-per-line).
2. Short labels for each set (default "Set A" / "Set B").
3. Length unit — `word` (default) or `char`.
4. Output directory (default `./qlc_output`).
5. (Optional) Template `.docx` path if the user wants the analysis inserted
   into a branded template, plus any heading-name overrides.

Ask once if anything is ambiguous; do not invent paths.

## Step 1 — Run the stats CLI

```bash
python query_length_comparison.py \
    --file_a <path_a> --file_b <path_b> \
    --label_a "<label_a>" --label_b "<label_b>" \
    --unit <unit> --output_dir <output_dir>
```

This writes `results.json`, `summary.txt`, `distributions.png`, `ecdf.png`
into `<output_dir>`. If it fails, stop and report — do not proceed with
partial data.

## Step 2 — Render the .docx

Without a template:

```bash
python query-length-validation/build_report.py \
    --results_json  <output_dir>/results.json \
    --distributions <output_dir>/distributions.png \
    --ecdf          <output_dir>/ecdf.png \
    --output_docx   <output_dir>/report.docx \
    [--analyst "<name>"] [--context "<one-line context>"]
```

With a template:

```bash
python query-length-validation/build_report.py \
    --template      <template.docx> \
    --results_json  <output_dir>/results.json \
    --distributions <output_dir>/distributions.png \
    --ecdf          <output_dir>/ecdf.png \
    --output_docx   <output_dir>/report.docx \
    [--sections     <comma-separated keys>] \
    [--section-map  '<key>="Heading Text",<key>="Heading@N"']
```

Section keys: `data_summary`, `methods`, `hypothesis_tests`, `effect_size`,
`visualizations`, `findings`, `assessment`. Heading matching is
case-insensitive, ignores leading numbering, and accepts `@N` to pin a
heading level.

## Tone — the draft must not be overstated

- Prefer "consistent with" / "suggests" over "proves" / "demonstrates".
- Always cite effect size (Cohen's d, Cliff's delta) and PSI alongside
  p-values. Distinguish statistical from practical significance.
- Report bootstrap confidence intervals; state whether they contain zero.
- State limitations: comparison is length-only, not topic, intent, or
  quality; results depend on collection and tokenisation.
- Do not infer causation. Do not generalise beyond the two sets provided.
- Frame any recommendation as a suggested next step, not a required action.

## After running

Reply with the .docx path plus a one- or two-sentence summary in the same
measured tone. The artefact is the report — keep the reply short.
````

### Option 2 — Prompt file (slash command)

Create `.github/prompts/query-length-validation.prompt.md` in this
workspace. You invoke it explicitly by typing `/query-length-validation` in
Copilot Chat. Requires the VS Code setting `chat.promptFiles: true`.

Contents to put in the file:

````markdown
---
mode: agent
description: Compare two query sets on length and produce a measured validation .docx report.
---

You are running the **query length validation** workflow.

Gather these inputs from my message (ask if missing):
- `file_a` — path to Set A (.json list or .txt one-per-line)
- `file_b` — path to Set B
- `label_a`, `label_b` — short display names (default "Set A" / "Set B")
- `unit` — `word` (default) or `char`
- `output_dir` — where to write outputs (default `./qlc_output`)
- (Optional) `template` — path to a branded .docx template
- (Optional) `sections` — comma-separated section keys to insert
- (Optional) `section_map` — heading-text overrides per section

Steps:

1. Run:
   ```bash
   python query_length_comparison.py \
       --file_a {file_a} --file_b {file_b} \
       --label_a "{label_a}" --label_b "{label_b}" \
       --unit {unit} --output_dir {output_dir}
   ```

2. Render the report. Without template:
   ```bash
   python query-length-validation/build_report.py \
       --results_json  {output_dir}/results.json \
       --distributions {output_dir}/distributions.png \
       --ecdf          {output_dir}/ecdf.png \
       --output_docx   {output_dir}/report.docx
   ```
   With template, add `--template {template}` and optionally `--sections` /
   `--section-map`.

3. Reply with the .docx path plus a one- or two-sentence summary in measured
   tone.

Tone rules:
- Prefer "consistent with" / "suggests" over "proves".
- Always cite effect size and PSI alongside p-values.
- Distinguish statistical from practical significance.
- State the comparison is length-only.
- Do not infer causation.
- Frame any recommendation as a suggested next step.

Section keys: `data_summary`, `methods`, `hypothesis_tests`, `effect_size`,
`visualizations`, `findings`, `assessment`. Heading matching is
case-insensitive, ignores leading numbering. Use `@N` to pin a heading
level (e.g. `"Data and Input@3"`).
````

### Which option to choose

- **Option 1** when this is your main workflow in the repo — chat
  normally, Copilot just knows. Pays a small token cost on every turn.
- **Option 2** when this is one of several occasional tasks — clean
  namespace, only fires when you call `/query-length-validation`.

You can run both — a thin Option 1 plus several Option 2 prompt files is a
common pattern.

### Try it out

In Copilot Chat (agent mode), once one of the files above is in place:

> Compare `examples/queries_production.json` and
> `examples/queries_rewritten.json` on length, labels "Production" and
> "Rewritten". Write the docx report.

Or with Option 2:

> /query-length-validation file_a=examples/queries_production.json
> file_b=examples/queries_rewritten.json label_a="Production"
> label_b="Rewritten"

## A note on tone

The report deliberately avoids overstating findings. The tone contract lives
in `query-length-validation/SKILL.md` and in the Option 1 / Option 2 content
above: cite effect size and PSI alongside p-values, distinguish statistical
from practical significance, state limitations, do not infer causation.
Anything you add or adapt should keep that contract.
