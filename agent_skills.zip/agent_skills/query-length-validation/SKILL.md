---
name: query-length-validation
description: Compare two sets of queries on length, run a panel of hypothesis tests, and produce a measured validation report as a .docx file. Use when a user asks to validate, compare, or check whether two query sets differ in length / wording-volume, or when a user supplies "Set A" and "Set B" of queries and wants a written assessment for review.
---

# Query Length Validation

This skill compares two sets of queries on their **length distribution**
(characters or words), runs a battery of complementary hypothesis tests, and
writes a cautious validation report to a `.docx` file. The report is intended
to support an analyst's judgement — not to replace it — so the language must
stay measured.

## When to use

Invoke this skill when the user wants any of:
- a statistical comparison of two query sets on length;
- a "validation" / "QA" write-up of whether two query sets are interchangeable;
- a `.docx` deliverable summarising the comparison.

If the user only wants the numbers, run the CLI and show its output — do
**not** generate the .docx unless the user asked for a report / write-up /
document.

## Inputs to confirm with the user before running

Before invoking the script, confirm:

1. **Where the two query sets live.** Accept either plain-text files
   (one query per line) or `.json` files (a list of strings). If the user has
   only pasted them inline, write each set to a temporary `.txt` file.
2. **Length unit.** `word` (default) or `char`.
3. **Labels.** Short names for each set (e.g. "Production", "Synthetic").
   Default to "Set A" / "Set B" if not provided.
4. **Output directory.** Default to a fresh subdirectory under the working
   directory, e.g. `./qlc_<timestamp>/`.
5. **Template (optional).** If the user wants the analysis dropped into an
   existing branded `.docx` rather than built from scratch, ask for:
   - the path to the template file;
   - which sections (`data_summary`, `methods`, `hypothesis_tests`,
     `effect_size`, `visualizations`, `findings`, `assessment`) to insert —
     default is all;
   - the heading text(s) under which each section should land, if the
     template's headings differ from the section keys above.
   Skip this entirely if the user just wants a fresh report.

Do not invent file paths. If anything is ambiguous, ask once with the
AskUserQuestion tool rather than guessing.

## Step 1 — Run the CLI to compute statistics

The comparison script lives at
`/home/ubuntu/agent_skills/query_length_comparison.py`. Invoke it with Bash:

```bash
python /home/ubuntu/agent_skills/query_length_comparison.py \
    --file_a   <path_to_set_a> \
    --file_b   <path_to_set_b> \
    --label_a  "<label_a>" \
    --label_b  "<label_b>" \
    --unit     <word|char> \
    --output_dir <output_dir>
```

This writes four files into `<output_dir>`:
- `results.json` — machine-readable statistics
- `summary.txt` — human-readable summary
- `distributions.png` — histogram + KDE + boxplot
- `ecdf.png` — empirical CDFs

If the command fails, read the error and report it to the user; do not proceed
to step 2 with partial data.

## Step 2 — Render the .docx report

The helper has two modes. Pick based on whether the user supplied a template.

### Step 2a — Build from scratch (no template)

```bash
python /home/ubuntu/agent_skills/query-length-validation/build_report.py \
    --results_json  <output_dir>/results.json \
    --distributions <output_dir>/distributions.png \
    --ecdf          <output_dir>/ecdf.png \
    --output_docx   <output_dir>/query_length_validation_report.docx \
    [--analyst "<user's name if provided>"] \
    [--context "<one-sentence context from the user, if provided>"]
```

### Step 2b — Insert into an existing template (Pattern 3)

When the user supplied a template, add `--template`. The helper opens the
template (inheriting fonts, theme, headers/footers, page setup) and inserts
section content immediately after matching headings. Pick which sections via
`--sections`; remap heading text via `--section-map`.

```bash
python /home/ubuntu/agent_skills/query-length-validation/build_report.py \
    --template      <path_to_template.docx> \
    --results_json  <output_dir>/results.json \
    --distributions <output_dir>/distributions.png \
    --ecdf          <output_dir>/ecdf.png \
    --output_docx   <output_dir>/query_length_validation_report.docx \
    [--sections     <comma-separated keys>] \
    [--section-map  '<key>="Heading Text",<key>="Heading Text@N"'] \
    [--strict]
```

Section keys: `data_summary`, `methods`, `hypothesis_tests`, `effect_size`,
`visualizations`, `findings`, `assessment`.

Heading-matching rules to convey to the user when asking:
- Match is case-insensitive and ignores leading numbering, so `Findings`,
  `7. Findings`, and `VII. Findings` all match the same heading.
- Multi-level decimal numbering (`3.1.4 Data and Input`) is also handled.
- An optional `@N` qualifier (e.g. `"Data and Input@3"`) restricts the match
  to a specific heading level — use this when the same title appears at
  multiple levels.
- When the same title appears in multiple subsections at the same level, the
  unambiguous form is the full numbered text, e.g. `"3.1.4 Data and Input"`.

If the template is missing one of the requested headings, the script prints a
warning and skips that section. Add `--strict` if the user wants the run to
fail instead.

`--analyst` and `--context` are ignored in template mode (the template
controls cover material). Do not pass them.

The helper builds the document deterministically from the JSON. It already
embeds tables for descriptive statistics, hypothesis-test results, and effect
sizes; it inserts the two plots as figures; and its narrative paragraphs are
written to be measured (see "Tone" below).

## Step 3 — Report back to the user

In your text reply, tell the user:
- the path to the `.docx` file;
- one or two sentences summarising what the report says (mirror its tone —
  do **not** overstate);
- the path to the `results.json` if they want the raw numbers.

Keep this reply short. The artefact is the report.

## Tone — the draft must not be overstated

This is the most important rule of this skill. The helper already follows it;
if you write any narrative yourself, follow the same rules:

- Prefer "consistent with", "suggests", "indicates" over "proves",
  "demonstrates", "shows that".
- Distinguish **statistical significance** from **practical significance**.
  With large samples even tiny differences become significant; always cite the
  effect size (Cohen's d, Cliff's delta) and the PSI alongside p-values.
- Report confidence intervals when describing the mean difference, and state
  explicitly whether the interval contains zero.
- If only a subset of tests reject the null, say so — do not summarise as a
  single "significant" / "not significant" verdict.
- State the limitations: this compares **length only**, not topic or intent;
  results depend on how the queries were collected and tokenised.
- Do not infer causation from a length difference. Do not generalise beyond
  the two specific sets provided.
- If you add a recommendation, frame it as a suggested next step, not a
  required action.

If the user requests a more confident or marketing-style tone, decline once
and explain that this skill is for validation. If they still want it, hand
back the raw numbers but do not produce the .docx under this skill.

## Failure modes

- **Tiny samples (n < 30 per set).** The script will still run, but the
  helper's narrative warns that conclusions are tentative. Mention this in
  your reply.
- **All queries identical length.** Several tests will be uninformative; the
  PSI may be 0. State this rather than reading too much into the numbers.
- **Different pre-processing.** If the user can't confirm the two sets were
  tokenised the same way, surface that as a caveat in your reply — a length
  difference may simply reflect a pipeline difference.
