"""
Render a validation report (.docx) from the JSON results produced by
``query_length_comparison.py``.

The text of the analysis is intentionally measured: the report describes what
the tests indicate, not what they prove. Interpretive language ("consistent
with", "suggests", "no convincing evidence of") is preferred over absolute
claims. Limitations are stated explicitly.

Usage
-----
    python build_report.py \\
        --results_json   /path/to/qlc_output/results.json \\
        --distributions  /path/to/qlc_output/distributions.png \\
        --ecdf           /path/to/qlc_output/ecdf.png \\
        --output_docx    /path/to/report.docx \\
        [--analyst "Jane Doe"] [--context "Pre-deployment validation, ..." ]
"""

from __future__ import annotations

import argparse
import json
import os
import re
from datetime import date

from docx import Document
from docx.oxml import OxmlElement
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.text.paragraph import Paragraph


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def fmt_p(p: float) -> str:
    if p < 1e-4:
        return f"{p:.2e}"
    return f"{p:.4f}"


def sig_marker(p: float, alpha: float) -> str:
    if p < 0.001:
        return "***"
    if p < 0.01:
        return "**"
    if p < alpha:
        return "*"
    return "ns"


def effect_size_label(d: float) -> str:
    """Qualitative Cohen's d label (Cohen, 1988)."""
    abs_d = abs(d)
    if abs_d < 0.2:
        return "negligible"
    if abs_d < 0.5:
        return "small"
    if abs_d < 0.8:
        return "medium"
    return "large"


def cliffs_label(c: float) -> str:
    """Romano et al. (2006) thresholds."""
    abs_c = abs(c)
    if abs_c < 0.147:
        return "negligible"
    if abs_c < 0.33:
        return "small"
    if abs_c < 0.474:
        return "medium"
    return "large"


def psi_label(psi: float) -> str:
    if psi < 0.10:
        return "no material distributional shift (PSI < 0.10)"
    if psi < 0.25:
        return "moderate distributional shift (0.10 <= PSI < 0.25)"
    return "substantial distributional shift (PSI >= 0.25)"


# ---------------------------------------------------------------------------
# Document building
# ---------------------------------------------------------------------------

def add_heading(doc: Document, text: str, level: int = 1) -> None:
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = RGBColor(0x1F, 0x3A, 0x68)


def add_para(doc: Document, text: str, bold: bool = False, italic: bool = False) -> None:
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(11)


def add_descriptive_table(doc: Document, results: dict) -> None:
    sa = results["stats_a"]
    sb = results["stats_b"]
    rows = [("count", "{:d}"), ("mean", "{:.2f}"), ("std", "{:.2f}"),
            ("min", "{:d}"), ("p25", "{:.2f}"), ("median", "{:.2f}"),
            ("p75", "{:.2f}"), ("max", "{:d}")]

    table = doc.add_table(rows=len(rows) + 1, cols=3)
    table.style = "Light Grid Accent 1"
    hdr = table.rows[0].cells
    hdr[0].text = "Statistic"
    hdr[1].text = results["label_a"]
    hdr[2].text = results["label_b"]
    for i, (key, fmt) in enumerate(rows, start=1):
        r = table.rows[i].cells
        r[0].text = key
        r[1].text = fmt.format(sa[key])
        r[2].text = fmt.format(sb[key])


def add_hypothesis_table(doc: Document, results: dict) -> None:
    alpha = results["alpha"]
    tests = [
        ("Welch's t-test",              "means (assumes unequal variances)",
         results["welch_t_statistic"], results["welch_t_pvalue"]),
        ("Mann-Whitney U",              "location / stochastic ordering",
         results["mannwhitney_statistic"], results["mannwhitney_pvalue"]),
        ("Kolmogorov-Smirnov 2-sample", "full distribution shape",
         results["ks_statistic"], results["ks_pvalue"]),
        ("Chi-squared (binned)",        "binned distribution homogeneity",
         results["chi2_statistic"], results["chi2_pvalue"]),
        ("Levene's test",               "equality of variances",
         results["levene_statistic"], results["levene_pvalue"]),
        ("Permutation test (mean)",     "mean difference, distribution-free",
         results["mean_diff"], results["permutation_pvalue"]),
    ]
    table = doc.add_table(rows=len(tests) + 1, cols=5)
    table.style = "Light Grid Accent 1"
    hdr = table.rows[0].cells
    hdr[0].text = "Test"
    hdr[1].text = "Null hypothesis (H0)"
    hdr[2].text = "Statistic"
    hdr[3].text = "p-value"
    hdr[4].text = f"alpha={alpha}"
    for i, (name, h0, stat, p) in enumerate(tests, start=1):
        r = table.rows[i].cells
        r[0].text = name
        r[1].text = f"equal {h0}"
        r[2].text = f"{stat:.4f}"
        r[3].text = fmt_p(p)
        r[4].text = sig_marker(p, alpha)


def add_effect_table(doc: Document, results: dict) -> None:
    rows = [
        ("Mean difference (A - B)",
         f"{results['mean_diff']:+.3f} ({results['mean_diff_pct']:+.1f}%)"),
        ("Bootstrap 95% CI for mean diff",
         f"[{results['bootstrap_ci_lower']:+.3f}, {results['bootstrap_ci_upper']:+.3f}]"),
        ("Cohen's d (standardised mean diff)",
         f"{results['cohens_d']:+.3f} ({effect_size_label(results['cohens_d'])})"),
        ("Cliff's delta (non-parametric)",
         f"{results['cliffs_delta']:+.3f} ({cliffs_label(results['cliffs_delta'])})"),
        ("Population Stability Index (PSI)",
         f"{results['psi']:.4f} ({psi_label(results['psi'])})"),
    ]
    table = doc.add_table(rows=len(rows) + 1, cols=2)
    table.style = "Light Grid Accent 1"
    hdr = table.rows[0].cells
    hdr[0].text = "Measure"
    hdr[1].text = "Value"
    for i, (k, v) in enumerate(rows, start=1):
        r = table.rows[i].cells
        r[0].text = k
        r[1].text = v


# ---------------------------------------------------------------------------
# Narrative — written to be measured, not overstated.
# ---------------------------------------------------------------------------

def narrative_findings(results: dict) -> list[str]:
    """Produce a measured narrative; avoids absolute / causal language."""
    alpha = results["alpha"]
    n_sig = results["n_sig_tests"]
    unit = results["unit"]
    la, lb = results["label_a"], results["label_b"]
    sa, sb = results["stats_a"], results["stats_b"]
    mean_diff = results["mean_diff"]
    pct = results["mean_diff_pct"]
    ci_lo = results["bootstrap_ci_lower"]
    ci_hi = results["bootstrap_ci_upper"]
    ci_excludes_zero = (ci_lo > 0) or (ci_hi < 0)
    d = results["cohens_d"]
    cdelta = results["cliffs_delta"]
    psi_val = results["psi"]
    lev_p = results["levene_pvalue"]

    paras: list[str] = []

    # Descriptive overview
    paras.append(
        f"{la} contains {sa['count']} queries with a mean length of "
        f"{sa['mean']:.2f} {unit}s (median {sa['median']:.1f}, std {sa['std']:.2f}). "
        f"{lb} contains {sb['count']} queries with a mean length of "
        f"{sb['mean']:.2f} {unit}s (median {sb['median']:.1f}, std {sb['std']:.2f}). "
        f"The observed mean difference ({la} minus {lb}) is "
        f"{mean_diff:+.2f} {unit}s ({pct:+.1f}% relative to {lb}'s mean)."
    )

    # Hypothesis tests — measured framing
    if n_sig >= 4:
        framing = (
            f"At alpha = {alpha}, {n_sig} of 5 distribution-comparison tests "
            f"(Welch's t, Mann-Whitney U, Kolmogorov-Smirnov, chi-squared, and the "
            f"permutation test on the mean) reject the null hypothesis of equality. "
            f"This pattern of agreement across tests with different assumptions is "
            f"consistent with a real difference in the length distribution of the two "
            f"query sets."
        )
    elif n_sig >= 2:
        framing = (
            f"At alpha = {alpha}, {n_sig} of 5 distribution-comparison tests reject "
            f"the null hypothesis. The signal is mixed: some tests indicate a "
            f"difference while others do not. This may reflect a genuine but modest "
            f"difference, sensitivity to distribution shape, or sample-size effects, "
            f"and warrants cautious interpretation."
        )
    else:
        framing = (
            f"At alpha = {alpha}, only {n_sig} of 5 distribution-comparison tests "
            f"reject the null hypothesis. The available evidence does not support a "
            f"conclusion that the query-length distributions differ; the observed "
            f"deviations are within what could plausibly arise from sampling "
            f"variability alone."
        )
    paras.append(framing)

    # Effect-size + CI commentary
    ci_text = (
        f"The bootstrap 95% confidence interval for the mean difference is "
        f"[{ci_lo:+.3f}, {ci_hi:+.3f}]. "
        + ("This interval excludes zero, so the estimated mean difference is "
           "unlikely to be attributable to sampling alone."
           if ci_excludes_zero else
           "This interval contains zero, so the estimated mean difference is "
           "compatible with no underlying difference between the two sets.")
    )
    eff_text = (
        f"The standardised mean difference (Cohen's d) is {d:+.3f}, a "
        f"{effect_size_label(d)} effect size by Cohen's conventions. The "
        f"non-parametric Cliff's delta is {cdelta:+.3f} ({cliffs_label(cdelta)} "
        f"effect)."
    )
    paras.append(ci_text + " " + eff_text)

    # Distributional shift
    paras.append(
        f"The Population Stability Index across {results['unit']}-length bins is "
        f"{psi_val:.4f}, indicating {psi_label(psi_val)}."
    )

    # Variance comparison
    if lev_p < alpha:
        paras.append(
            f"Levene's test (p = {fmt_p(lev_p)}) is consistent with the two sets "
            f"having different dispersion, not only different central tendency."
        )
    else:
        paras.append(
            f"Levene's test (p = {fmt_p(lev_p)}) does not provide evidence of "
            f"unequal variances between the two sets."
        )

    return paras


def _verdict_class(results: dict) -> str:
    """Return 'strong', 'weak', or 'mixed' based on agreement of indicators."""
    n_sig = results["n_sig_tests"]
    psi_val = results["psi"]
    d = results["cohens_d"]
    ci_lo = results["bootstrap_ci_lower"]
    ci_hi = results["bootstrap_ci_upper"]
    ci_excludes_zero = (ci_lo > 0) or (ci_hi < 0)
    if (n_sig >= 4) and ci_excludes_zero and (abs(d) >= 0.5 or psi_val >= 0.25):
        return "strong"
    if (n_sig <= 1) and (not ci_excludes_zero) and abs(d) < 0.2 and psi_val < 0.10:
        return "weak"
    return "mixed"


def narrative_assessment(results: dict) -> list[str]:
    """MRM-style assessment grounded in model risk.

    The assessment treats {label_a} as the population on which a model is
    developed / validated, and {label_b} as the population on which it is
    deployed or applied. The 'concerns' paragraph documents implications for
    model behaviour rather than methodological caveats.
    """
    verdict = _verdict_class(results)
    la, lb = results["label_a"], results["label_b"]

    if verdict == "strong":
        mrm = (
            f"Assessment by MRM. The comparison evaluates whether the {la} "
            f"and {lb} query distributions agree on length, a property that "
            f"directly affects the expectation that model behaviour validated "
            f"on {la} will transfer to {lb}. Multiple lines of evidence "
            f"(hypothesis tests, bootstrap confidence interval, effect sizes, "
            f"and PSI) converge on a difference between the two sets that is "
            f"unlikely to be a sampling artefact. For workflows that treat "
            f"the {la} population as a stand-in for {lb}, the two are not "
            f"interchangeable on length."
        )
        concerns = (
            f"Concerns. A model developed, tuned, or validated on the {la} "
            f"query distribution should not be assumed to behave the same "
            f"way on {lb}. Even when the model performs well on {la}, the "
            f"length gap observed here is consistent with a broader "
            f"distributional difference between the two populations that "
            f"may also span vocabulary, intent, or query structure. "
            f"Performance evidence accumulated on {la} therefore does not, "
            f"on its own, qualify performance on {lb}; a sample-based "
            f"re-evaluation on {lb} is needed before granting deployment "
            f"confidence. Components whose behaviour is length-sensitive "
            f"(e.g. truncation, retrieval recall, ranking calibration) are "
            f"the most likely to be affected."
        )
    elif verdict == "weak":
        mrm = (
            f"Assessment by MRM. The comparison evaluates whether the {la} "
            f"and {lb} query distributions agree on length, a property that "
            f"directly affects the expectation that model behaviour validated "
            f"on {la} will transfer to {lb}. Effect sizes are small, the "
            f"bootstrap confidence interval for the mean difference contains "
            f"zero, and PSI is below the conventional 0.10 alert threshold. "
            f"On the length dimension, the {la} and {lb} sets appear "
            f"interchangeable in the current sample."
        )
        concerns = (
            f"Concerns. The absence of a length gap is supportive — but not "
            f"on its own conclusive — that model behaviour validated on "
            f"{la} will transfer to {lb}. Length is one dimension of "
            f"similarity; vocabulary, intent, topic, and query structure "
            f"may still differ between the two populations and should be "
            f"assessed separately before {la}-validation evidence is used "
            f"as a stand-in for {lb}-deployment evidence. For model "
            f"components driven primarily by length, the present finding "
            f"reduces concern; for components driven by other features, it "
            f"does not."
        )
    else:
        mrm = (
            f"Assessment by MRM. The comparison evaluates whether the {la} "
            f"and {lb} query distributions agree on length, a property that "
            f"directly affects the expectation that model behaviour validated "
            f"on {la} will transfer to {lb}. The evidence is mixed: some "
            f"indicators reject equivalence and others do not, or the "
            f"magnitude of any difference is small relative to the noise "
            f"level. The current data are insufficient to either confirm or "
            f"rule out a length gap."
        )
        concerns = (
            f"Concerns. Because we cannot at this point distinguish between "
            f"a genuine length gap and sampling noise, any reliance on "
            f"{la}-validated model performance to project behaviour on {lb} "
            f"carries an unquantified risk on length-sensitive components. "
            f"The present result should be treated as preliminary; before "
            f"using {la}-validation evidence to qualify {lb} deployment, "
            f"enlarge the sample, re-run with the alternative length unit, "
            f"or accompany the comparison with a complementary distributional "
            f"check."
        )

    return [mrm, concerns]


def narrative_executive_summary(results: dict) -> list[str]:
    """One- or two-sentence high-level summary for a decision-maker.

    Lands at the end of the report ('finally, an executive high-level
    summary'), so it can reference the body above.
    """
    verdict = _verdict_class(results)
    la, lb = results["label_a"], results["label_b"]
    mean_a = results["stats_a"]["mean"]
    mean_b = results["stats_b"]["mean"]
    mean_diff = results["mean_diff"]
    pct = results["mean_diff_pct"]
    unit = results["unit"]

    if verdict == "strong":
        text = (
            f"The {la} and {lb} query populations differ in length: {la} "
            f"averages {mean_a:.1f} {unit}s versus {mean_b:.1f} for {lb} "
            f"(difference {mean_diff:+.1f} {unit}s, {pct:+.1f}%), and the "
            f"distributions are unlikely to be the same. For model "
            f"validation purposes, {la} cannot be treated as a "
            f"length-faithful proxy for {lb}; model performance validated "
            f"on {la} should be re-evaluated on a {lb} sample before "
            f"deployment confidence is granted."
        )
    elif verdict == "weak":
        text = (
            f"The {la} and {lb} query populations show no convincing length "
            f"difference (means {mean_a:.1f} vs {mean_b:.1f} {unit}s, "
            f"bootstrap CI contains zero, PSI below 0.10). On length, model "
            f"behaviour validated on {la} can be expected to transfer to "
            f"{lb}; non-length dimensions should be assessed separately."
        )
    else:
        text = (
            f"The {la} and {lb} query populations show a mixed length "
            f"signal (means {mean_a:.1f} vs {mean_b:.1f} {unit}s; some "
            f"tests reject equivalence, others do not). The present data "
            f"neither confirm nor rule out a meaningful gap; any reliance "
            f"on {la}-validated model performance for {lb} should be "
            f"qualified pending additional evaluation."
        )
    return [text]


# ---------------------------------------------------------------------------
# Template-insertion machinery (Pattern 3: insert after a heading)
# ---------------------------------------------------------------------------

# Section keys -> default heading text the script looks for in the template.
# Match is case-insensitive and ignores leading numbering like "1." or "VII.".
DEFAULT_SECTION_HEADINGS = {
    "data_summary":       "Data summary",
    "methods":            "Methods",
    "hypothesis_tests":   "Hypothesis test results",
    "effect_size":        "Effect size and uncertainty",
    "visualizations":     "Visualisations",   # also matches "Visualizations"
    "findings":           "Observations",
    "assessment":         "Assessment",
    "executive_summary":  "Executive summary",
}

ALL_SECTIONS = list(DEFAULT_SECTION_HEADINGS.keys())


def _normalize_heading(text: str) -> str:
    """Lowercase, strip leading numbering/bullets and trailing punctuation.

    Handles multi-level decimal numbering ('3.1.4'), roman-numeral and letter
    numbering ('VII.', 'a)'). Treats 'Visualisations' / 'Visualizations' as
    equivalent.
    """
    t = text.strip().lower()
    # Strip leading dotted-decimal numbering: "1.", "3.1", "3.1.4", "3.1.4."
    t = re.sub(r"^\d+(?:\.\d+)*\.?\s*", "", t)
    # Strip leading roman-numeral or single-letter numbering: "vii.", "a)"
    t = re.sub(r"^(?:[ivxlcdm]+|[a-z])[\.\)]\s*", "", t)
    t = t.strip(" :.—-").strip()
    t = t.replace("visualisation", "visualization")
    return t


def _parse_level_qualifier(text: str) -> tuple[str, int | None]:
    """Split off an optional ``@N`` level qualifier from a heading spec.

    ``"Data and Input@3"`` -> (``"Data and Input"``, 3).
    """
    m = re.match(r"^(.*?)\s*@(\d+)\s*$", text)
    if m:
        return m.group(1).strip(), int(m.group(2))
    return text.strip(), None


def find_heading(
    doc: Document, text: str, level: int | None = None,
) -> Paragraph | None:
    """Find the first heading-styled paragraph matching ``text``.

    Match strategy (in order):
      1. Exact case-insensitive match against the raw heading text. This wins
         when the user provides the full heading verbatim, including any
         numbering — useful to disambiguate when the same title appears in
         multiple subsections.
      2. Normalised match (leading numbering stripped from both sides). Lets
         the user pass either "3.1.4 Data and Input" or just "Data and Input".

    ``level`` restricts the search to ``Heading <level>`` paragraphs.
    """
    style_prefix = f"Heading {level}" if level is not None else "Heading"
    raw_target = text.strip().lower()

    candidates = [p for p in doc.paragraphs
                  if p.style.name.startswith(style_prefix)]

    for p in candidates:
        if p.text.strip().lower() == raw_target:
            return p

    norm_target = _normalize_heading(text)
    for p in candidates:
        if _normalize_heading(p.text) == norm_target:
            return p
    return None


class Cursor:
    """A moving XML insertion point inside a docx body.

    Every ``insert_*`` call places the new element immediately after the
    cursor and then advances the cursor onto that new element, so successive
    calls produce sequential content.
    """

    def __init__(self, doc: Document, anchor: Paragraph):
        self.doc = doc
        self.cursor = anchor._p          # underlying lxml element
        self.parent = anchor._parent     # used to wrap new paragraphs

    def _wrap(self, p_elem) -> Paragraph:
        return Paragraph(p_elem, self.parent)

    def insert_paragraph(
        self,
        text: str = "",
        style: str = "Normal",
        italic: bool = False,
        align_center: bool = False,
        font_size: int | None = None,
    ) -> Paragraph:
        new_p = OxmlElement("w:p")
        self.cursor.addnext(new_p)
        self.cursor = new_p
        para = self._wrap(new_p)
        if style in self.doc.styles:
            try:
                para.style = self.doc.styles[style]
            except KeyError:
                pass
        if align_center:
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if text:
            run = para.add_run(text)
            if italic:
                run.italic = True
            if font_size is not None:
                run.font.size = Pt(font_size)
        return para

    def insert_table(self, rows: int, cols: int, style: str | None = None):
        """Create a table at the end of the doc, then move it after the cursor."""
        table = self.doc.add_table(rows=rows, cols=cols)
        if style and style in [s.name for s in self.doc.styles]:
            try:
                table.style = style
            except KeyError:
                pass
        tbl = table._tbl
        tbl.getparent().remove(tbl)
        self.cursor.addnext(tbl)
        self.cursor = tbl
        return table

    def insert_picture(self, path: str, width):
        para = self.insert_paragraph("")
        run = para.add_run()
        run.add_picture(path, width=width)
        return para


# ---------------------------------------------------------------------------
# Cursor-mode section builders
# (Mirror the doc-append helpers above, but write at the cursor position.)
# ---------------------------------------------------------------------------

def _fill_descriptive_table(table, results: dict) -> None:
    sa, sb = results["stats_a"], results["stats_b"]
    rows = [("count", "{:d}"), ("mean", "{:.2f}"), ("std", "{:.2f}"),
            ("min", "{:d}"), ("p25", "{:.2f}"), ("median", "{:.2f}"),
            ("p75", "{:.2f}"), ("max", "{:d}")]
    hdr = table.rows[0].cells
    hdr[0].text = "Statistic"
    hdr[1].text = results["label_a"]
    hdr[2].text = results["label_b"]
    for i, (key, fmt) in enumerate(rows, start=1):
        r = table.rows[i].cells
        r[0].text = key
        r[1].text = fmt.format(sa[key])
        r[2].text = fmt.format(sb[key])


def _fill_hypothesis_table(table, results: dict) -> None:
    alpha = results["alpha"]
    rows = [
        ("Welch's t-test",              "means (assumes unequal variances)",
         results["welch_t_statistic"], results["welch_t_pvalue"]),
        ("Mann-Whitney U",              "location / stochastic ordering",
         results["mannwhitney_statistic"], results["mannwhitney_pvalue"]),
        ("Kolmogorov-Smirnov 2-sample", "full distribution shape",
         results["ks_statistic"], results["ks_pvalue"]),
        ("Chi-squared (binned)",        "binned distribution homogeneity",
         results["chi2_statistic"], results["chi2_pvalue"]),
        ("Levene's test",               "equality of variances",
         results["levene_statistic"], results["levene_pvalue"]),
        ("Permutation test (mean)",     "mean difference, distribution-free",
         results["mean_diff"], results["permutation_pvalue"]),
    ]
    hdr = table.rows[0].cells
    hdr[0].text = "Test"
    hdr[1].text = "Null hypothesis (H0)"
    hdr[2].text = "Statistic"
    hdr[3].text = "p-value"
    hdr[4].text = f"alpha={alpha}"
    for i, (name, h0, stat, p) in enumerate(rows, start=1):
        r = table.rows[i].cells
        r[0].text = name
        r[1].text = f"equal {h0}"
        r[2].text = f"{stat:.4f}"
        r[3].text = fmt_p(p)
        r[4].text = sig_marker(p, alpha)


def _fill_effect_table(table, results: dict) -> None:
    rows = [
        ("Mean difference (A - B)",
         f"{results['mean_diff']:+.3f} ({results['mean_diff_pct']:+.1f}%)"),
        ("Bootstrap 95% CI for mean diff",
         f"[{results['bootstrap_ci_lower']:+.3f}, {results['bootstrap_ci_upper']:+.3f}]"),
        ("Cohen's d (standardised mean diff)",
         f"{results['cohens_d']:+.3f} ({effect_size_label(results['cohens_d'])})"),
        ("Cliff's delta (non-parametric)",
         f"{results['cliffs_delta']:+.3f} ({cliffs_label(results['cliffs_delta'])})"),
        ("Population Stability Index (PSI)",
         f"{results['psi']:.4f} ({psi_label(results['psi'])})"),
    ]
    hdr = table.rows[0].cells
    hdr[0].text = "Measure"
    hdr[1].text = "Value"
    for i, (k, v) in enumerate(rows, start=1):
        r = table.rows[i].cells
        r[0].text = k
        r[1].text = v


def _section_data_summary(cur: Cursor, results: dict) -> None:
    cur.insert_paragraph(
        f"Length unit used: {results['unit']}. "
        f"Sample sizes: {results['stats_a']['count']} ({results['label_a']}) "
        f"and {results['stats_b']['count']} ({results['label_b']}).",
    )
    table = cur.insert_table(rows=9, cols=3, style="Light Grid Accent 1")
    _fill_descriptive_table(table, results)


def _section_methods(cur: Cursor, results: dict) -> None:
    cur.insert_paragraph(
        "We compared the two length distributions using a panel of complementary "
        "tests. Welch's t-test compares means under unequal variances. Mann-Whitney "
        "U is a non-parametric test of stochastic ordering. The Kolmogorov-Smirnov "
        "two-sample test is sensitive to differences in overall distribution shape. "
        "A chi-squared test of homogeneity is applied to binned counts. Levene's "
        "test assesses equality of variances. A permutation test (10,000 "
        "iterations) provides a distribution-free p-value for the observed mean "
        "difference. We also report Cohen's d, Cliff's delta, the Population "
        "Stability Index (PSI), and a 10,000-sample bootstrap 95% confidence "
        "interval for the mean difference. We use these in combination because no "
        "single test captures every way two distributions can differ.",
    )


def _section_hypothesis_tests(cur: Cursor, results: dict) -> None:
    table = cur.insert_table(rows=7, cols=5, style="Light Grid Accent 1")
    _fill_hypothesis_table(table, results)
    cur.insert_paragraph(
        "Significance markers: *** p<0.001, ** p<0.01, * p<alpha, "
        "ns = not significant at alpha.",
        italic=True,
    )


def _section_effect_size(cur: Cursor, results: dict) -> None:
    table = cur.insert_table(rows=6, cols=2, style="Light Grid Accent 1")
    _fill_effect_table(table, results)


def _section_visualizations(
    cur: Cursor,
    results: dict,
    distributions_png: str | None,
    ecdf_png: str | None,
) -> None:
    if distributions_png and os.path.exists(distributions_png):
        cur.insert_picture(distributions_png, width=Inches(6.3))
        cur.insert_paragraph(
            "Figure 1. Histogram, kernel density estimate, and boxplot of query lengths.",
            italic=True, align_center=True, font_size=10,
        )
    if ecdf_png and os.path.exists(ecdf_png):
        cur.insert_picture(ecdf_png, width=Inches(5.5))
        cur.insert_paragraph(
            "Figure 2. Empirical cumulative distribution functions.",
            italic=True, align_center=True, font_size=10,
        )


def _section_findings(
    cur: Cursor, results: dict, *, narrative_override: dict | None = None,
) -> None:
    paras = (narrative_override or {}).get("findings") or narrative_findings(results)
    for para in paras:
        cur.insert_paragraph(para)


def _section_assessment(
    cur: Cursor, results: dict, *, narrative_override: dict | None = None,
) -> None:
    paras = (narrative_override or {}).get("assessment") or narrative_assessment(results)
    for para in paras:
        cur.insert_paragraph(para)


def _section_executive_summary(
    cur: Cursor, results: dict, *, narrative_override: dict | None = None,
) -> None:
    paras = (narrative_override or {}).get("executive_summary") \
        or narrative_executive_summary(results)
    for para in paras:
        cur.insert_paragraph(para)


# Dispatch table for cursor-mode section builders.
def _section_builder(key: str):
    return {
        "data_summary":       _section_data_summary,
        "methods":            _section_methods,
        "hypothesis_tests":   _section_hypothesis_tests,
        "effect_size":        _section_effect_size,
        "visualizations":     _section_visualizations,
        "findings":           _section_findings,
        "assessment":         _section_assessment,
        "executive_summary":  _section_executive_summary,
    }[key]


def parse_section_map(spec: str | None) -> dict[str, str]:
    """Parse a 'key=heading,key=heading' override into a dict.

    Heading values may be quoted to include spaces or commas, e.g.
        findings="Key Findings",assessment="Conclusion"
    """
    if not spec:
        return {}
    out: dict[str, str] = {}
    # Tolerant tokeniser: split on commas not inside quotes.
    parts = re.findall(r'([^,]+?=(?:"[^"]*"|[^,]+))(?:,|$)', spec)
    if not parts:
        # Fallback: simple split
        parts = [p for p in spec.split(",") if p.strip()]
    for part in parts:
        if "=" not in part:
            raise ValueError(f"Section map entry must be key=heading: {part!r}")
        key, val = part.split("=", 1)
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if key not in DEFAULT_SECTION_HEADINGS:
            raise ValueError(
                f"Unknown section key {key!r}. Valid keys: "
                + ", ".join(DEFAULT_SECTION_HEADINGS)
            )
        out[key] = val
    return out


SUB_HEADING_TITLES = {
    "data_summary":       "Descriptive Statistics",
    "methods":            "Introduction of Tests",
    "hypothesis_tests":   "Hypothesis Test Results",
    "effect_size":        "Effect Size and Uncertainty",
    "visualizations":     "Figures",
    "findings":           "Observations",
    "assessment":         "Assessment",
    "executive_summary":  "Executive Summary",
}


def _anchor_level(anchor: Paragraph) -> int:
    name = anchor.style.name
    if name.startswith("Heading "):
        try:
            return int(name.split()[-1])
        except ValueError:
            return 3
    return 3


def _load_narrative_override(path: str | None) -> dict[str, list[str]]:
    """Load a narrative-override JSON.

    Schema: ``{ "<section_key>": ["paragraph 1", "paragraph 2", ...], ... }``.
    Section keys whose value is a single string are coerced to one-paragraph
    lists. Keys: ``findings``, ``assessment``, ``executive_summary``.
    Unknown keys are ignored. Returns ``{}`` if ``path`` is ``None``.
    """
    if not path:
        return {}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(
            "Narrative JSON must be an object mapping section key -> "
            "string or list of strings."
        )
    allowed = {"findings", "assessment", "executive_summary"}
    out: dict[str, list[str]] = {}
    for k, v in data.items():
        if k not in allowed:
            continue
        if isinstance(v, str):
            out[k] = [v]
        elif isinstance(v, list) and all(isinstance(x, str) for x in v):
            out[k] = v
        else:
            raise ValueError(
                f"narrative[{k!r}] must be a string or list of strings."
            )
    return out


def build_into_template(
    template_docx: str,
    results_json: str,
    output_docx: str,
    distributions_png: str | None = None,
    ecdf_png: str | None = None,
    sections: list[str] | None = None,
    section_map: dict[str, str] | None = None,
    strict: bool = False,
    anchor: str | None = None,
    add_subheadings: bool = True,
    narrative_override: dict | None = None,
) -> str:
    """Insert section content into an existing template under matching headings.

    Parameters
    ----------
    template_docx
        Path to the template .docx. Must contain heading-styled paragraphs
        matching the section names (see ``DEFAULT_SECTION_HEADINGS``).
    sections
        Which section keys to insert. ``None`` = all of them. Order is
        determined by the order of headings in the template, not this list.
    section_map
        Override the heading text to look for, per section key.
        E.g. ``{"findings": "Key Findings"}``.
    strict
        If True, raise when a requested section's heading is not found.
        If False (default), skip missing headings and print a warning.
    """
    with open(results_json, "r", encoding="utf-8") as f:
        results = json.load(f)

    doc = Document(template_docx)

    requested = list(sections) if sections else list(ALL_SECTIONS)

    inserted: list[str] = []
    missing: list[tuple[str, str]] = []

    if anchor:
        # Consolidate mode: every requested section goes under one heading,
        # in the order listed in ``requested``. Sub-headings are auto-added
        # one level below the anchor (e.g. anchor=H3 -> sub=H4).
        if section_map:
            print("Note: --section-map is ignored in --anchor mode.")
        heading_text, level = _parse_level_qualifier(anchor)
        anchor_para = find_heading(doc, heading_text, level=level)
        if anchor_para is None:
            message = f"Anchor heading not found in template: {anchor!r}"
            if strict:
                raise LookupError(message)
            print(message)
            return output_docx
        cur = Cursor(doc, anchor_para)
        sub_level = min(_anchor_level(anchor_para) + 1, 9)

        for key in requested:
            if add_subheadings:
                cur.insert_paragraph(
                    SUB_HEADING_TITLES.get(key, key.replace("_", " ").title()),
                    style=f"Heading {sub_level}",
                )
            builder = _section_builder(key)
            if key == "visualizations":
                builder(cur, results, distributions_png, ecdf_png)
            elif key in {"findings", "assessment", "executive_summary"}:
                builder(cur, results, narrative_override=narrative_override)
            else:
                builder(cur, results)
            inserted.append(f"{key} -> under {anchor_para.text.strip()!r}")

    else:
        overrides = section_map or {}
        headings = {k: overrides.get(k, DEFAULT_SECTION_HEADINGS[k]) for k in requested}

        for key in requested:
            heading_spec = headings[key]
            heading_text, level = _parse_level_qualifier(heading_spec)
            anchor_para = find_heading(doc, heading_text, level=level)
            if anchor_para is None:
                missing.append((key, heading_spec))
                continue
            cur = Cursor(doc, anchor_para)
            builder = _section_builder(key)
            if key == "visualizations":
                builder(cur, results, distributions_png, ecdf_png)
            elif key in {"findings", "assessment", "executive_summary"}:
                builder(cur, results, narrative_override=narrative_override)
            else:
                builder(cur, results)
            inserted.append(f"{key} -> {anchor_para.text.strip()!r}")

    if missing:
        msg_lines = [
            f"  - section '{k}': expected heading {h!r} not found"
            for k, h in missing
        ]
        message = "Template is missing required headings:\n" + "\n".join(msg_lines)
        if strict:
            raise LookupError(message)
        print(message)
        print("(Pass --strict to fail instead of skipping. Use --section-map "
              "key=\"heading text\" to point at a different heading.)")

    os.makedirs(os.path.dirname(os.path.abspath(output_docx)) or ".", exist_ok=True)
    doc.save(output_docx)

    print(f"Inserted sections: {', '.join(inserted) or '(none)'}")
    if missing:
        print(f"Skipped sections : {', '.join(k for k, _ in missing)}")
    return output_docx


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def build(
    results_json: str,
    distributions_png: str | None,
    ecdf_png: str | None,
    output_docx: str,
    analyst: str | None = None,
    context: str | None = None,
    narrative_override: dict | None = None,
) -> str:
    with open(results_json, "r", encoding="utf-8") as f:
        results = json.load(f)

    doc = Document()

    # Title
    title = doc.add_heading("Query Length Comparison — Validation Report", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta_run = meta.add_run(
        f"Date: {date.today().isoformat()}    "
        f"Sets compared: {results['label_a']} vs {results['label_b']}    "
        f"Length unit: {results['unit']}"
    )
    meta_run.italic = True
    meta_run.font.size = Pt(10)

    # 1. Purpose & scope
    add_heading(doc, "1. Purpose and scope", level=1)
    add_para(
        doc,
        "This report documents a statistical comparison of query length between "
        f"two query sets ({results['label_a']} and {results['label_b']}) for "
        "validation purposes. It is intended to inform — not replace — qualitative "
        "review by an analyst familiar with the source pipelines.",
    )
    if context:
        add_para(doc, f"Context provided: {context}", italic=True)

    # 2. Data summary
    add_heading(doc, "2. Data summary", level=1)
    add_para(doc,
             f"Length unit used: {results['unit']}. "
             f"Sample sizes: {results['stats_a']['count']} ({results['label_a']}) "
             f"and {results['stats_b']['count']} ({results['label_b']}).")
    add_descriptive_table(doc, results)

    # 3. Methods
    add_heading(doc, "3. Methods", level=1)
    add_para(
        doc,
        "We compared the two length distributions using a panel of complementary "
        "tests. Welch's t-test compares means under unequal variances. Mann-Whitney "
        "U is a non-parametric test of stochastic ordering. The Kolmogorov-Smirnov "
        "two-sample test is sensitive to differences in overall distribution shape. "
        "A chi-squared test of homogeneity is applied to binned counts. Levene's "
        "test assesses equality of variances. A permutation test (10,000 "
        "iterations) provides a distribution-free p-value for the observed mean "
        "difference. We also report Cohen's d, Cliff's delta, the Population "
        "Stability Index (PSI), and a 10,000-sample bootstrap 95% confidence "
        "interval for the mean difference. We use these in combination because no "
        "single test captures every way two distributions can differ.",
    )

    # 4. Hypothesis test results
    add_heading(doc, "4. Hypothesis test results", level=1)
    add_hypothesis_table(doc, results)
    add_para(
        doc,
        "Significance markers: *** p<0.001, ** p<0.01, * p<alpha, ns = not "
        "significant at alpha.",
        italic=True,
    )

    # 5. Effect size & uncertainty
    add_heading(doc, "5. Effect size and uncertainty", level=1)
    add_effect_table(doc, results)

    # 6. Visualisations
    add_heading(doc, "6. Visualisations", level=1)
    if distributions_png and os.path.exists(distributions_png):
        doc.add_picture(distributions_png, width=Inches(6.3))
        cap = doc.add_paragraph("Figure 1. Histogram, kernel density estimate, "
                                "and boxplot of query lengths.")
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in cap.runs:
            r.italic = True
            r.font.size = Pt(10)
    if ecdf_png and os.path.exists(ecdf_png):
        doc.add_picture(ecdf_png, width=Inches(5.5))
        cap = doc.add_paragraph("Figure 2. Empirical cumulative distribution functions.")
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in cap.runs:
            r.italic = True
            r.font.size = Pt(10)

    nv = narrative_override or {}

    # 7. Observations
    add_heading(doc, "7. Observations", level=1)
    for para in (nv.get("findings") or narrative_findings(results)):
        add_para(doc, para)

    # 8. Assessment (MRM-style)
    add_heading(doc, "8. Assessment", level=1)
    for para in (nv.get("assessment") or narrative_assessment(results)):
        add_para(doc, para)

    # 9. Executive summary (last, per report contract)
    add_heading(doc, "9. Executive Summary", level=1)
    for para in (nv.get("executive_summary") or narrative_executive_summary(results)):
        add_para(doc, para)

    # Footer
    add_heading(doc, "Appendix: Raw verdict from the test panel", level=2)
    add_para(doc, results["verdict"], italic=True)
    if analyst:
        add_para(doc, f"Analyst: {analyst}", italic=True)

    os.makedirs(os.path.dirname(os.path.abspath(output_docx)) or ".", exist_ok=True)
    doc.save(output_docx)
    return output_docx


def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        description="Build a .docx validation report. Two modes: build from "
                    "scratch (default), or insert sections into an existing "
                    "template under matching headings (--template).",
    )
    p.add_argument("--results_json", required=True)
    p.add_argument("--distributions", default=None)
    p.add_argument("--ecdf", default=None)
    p.add_argument("--output_docx", required=True)
    p.add_argument("--analyst", default=None)
    p.add_argument("--context", default=None)

    # Template-insertion mode (Pattern 3).
    p.add_argument(
        "--template", default=None,
        help="Path to a template .docx. When set, the script inserts section "
             "content after matching headings instead of building from scratch.",
    )
    p.add_argument(
        "--sections", default=None,
        help="Comma-separated list of sections to insert (template mode only). "
             "Default: all. Valid keys: " + ", ".join(ALL_SECTIONS) + ".",
    )
    p.add_argument(
        "--section-map", dest="section_map", default=None,
        help='Override heading text per section, e.g. '
             '--section-map \'findings="Key Findings",assessment="Conclusion"\'. '
             "Use when the template's heading names differ from the defaults.",
    )
    p.add_argument(
        "--strict", action="store_true",
        help="Fail (instead of skip) if a requested section's heading is not "
             "found in the template.",
    )
    p.add_argument(
        "--anchor", default=None,
        help='Consolidate ALL requested sections under a single heading, '
             'inserted sequentially in --sections order. Auto-adds sub-headings '
             'one level below the anchor (e.g. anchor=H3 -> sub=H4). Example: '
             '--anchor "3.1.4 Data and Input". Ignores --section-map.',
    )
    p.add_argument(
        "--no-subheadings", action="store_true",
        help="In --anchor mode, do not auto-add sub-headings for each section.",
    )
    p.add_argument(
        "--narrative", default=None,
        help="Path to a narrative-override JSON. Schema: "
             '{ "findings": [...], "assessment": [...], "executive_summary": [...] }, '
             "each value a string or list of strings. Any section present "
             "uses this prose instead of the templated default; missing "
             "sections fall back to the canned text.",
    )
    args = p.parse_args(argv)

    narrative_override = _load_narrative_override(args.narrative)

    if args.template:
        if args.analyst or args.context:
            print("Note: --analyst / --context are ignored in template mode "
                  "(the template controls the cover material).")
        sections = None
        if args.sections:
            sections = [s.strip() for s in args.sections.split(",") if s.strip()]
            unknown = [s for s in sections if s not in DEFAULT_SECTION_HEADINGS]
            if unknown:
                p.error(
                    f"Unknown section(s): {unknown}. Valid keys: "
                    + ", ".join(ALL_SECTIONS)
                )
        section_map = parse_section_map(args.section_map)

        path = build_into_template(
            template_docx=args.template,
            results_json=args.results_json,
            output_docx=args.output_docx,
            distributions_png=args.distributions,
            ecdf_png=args.ecdf,
            sections=sections,
            section_map=section_map,
            strict=args.strict,
            anchor=args.anchor,
            add_subheadings=not args.no_subheadings,
            narrative_override=narrative_override,
        )
    else:
        path = build(
            results_json=args.results_json,
            distributions_png=args.distributions,
            ecdf_png=args.ecdf,
            output_docx=args.output_docx,
            analyst=args.analyst,
            context=args.context,
            narrative_override=narrative_override,
        )
    print(f"Saved: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
