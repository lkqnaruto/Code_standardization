"""
Query Length Hypothesis Testing — CLI tool.

Compares two sets of queries to assess whether they differ in *length*
(characters or words). Runs a battery of complementary hypothesis tests,
computes effect sizes and a Population Stability Index (PSI), and saves:

    <output_dir>/results.json     — machine-readable results
    <output_dir>/summary.txt      — human-readable summary
    <output_dir>/distributions.png — overlaid histogram, KDE, boxplot
    <output_dir>/ecdf.png         — empirical CDFs

Inputs may be provided as plain-text files (one query per line) or JSON
arrays of strings.

Usage
-----
    python query_length_comparison.py \\
        --file_a path/to/queries_a.txt \\
        --file_b path/to/queries_b.txt \\
        --unit word \\
        --output_dir ./out

    python query_length_comparison.py --demo --output_dir ./demo_out
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from dataclasses import dataclass, asdict, field
from typing import Sequence

import numpy as np
import pandas as pd
from scipy import stats

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
)
logger = logging.getLogger("query_length_comparison")


# ---------------------------------------------------------------------------
# Length computation
# ---------------------------------------------------------------------------

def query_lengths(queries: Sequence[str], unit: str = "word") -> np.ndarray:
    if unit == "char":
        return np.array([len(q.strip()) for q in queries], dtype=int)
    if unit == "word":
        return np.array([len(q.strip().split()) for q in queries], dtype=int)
    raise ValueError(f"Unknown unit={unit!r}; choose 'char' or 'word'.")


# ---------------------------------------------------------------------------
# Statistical helpers
# ---------------------------------------------------------------------------

def descriptive_stats(lengths: np.ndarray) -> dict:
    if len(lengths) == 0:
        return {"count": 0, "mean": 0.0, "std": 0.0, "min": 0,
                "p25": 0.0, "median": 0.0, "p75": 0.0, "max": 0}
    return {
        "count": int(len(lengths)),
        "mean": float(np.mean(lengths)),
        "std": float(np.std(lengths, ddof=1)) if len(lengths) > 1 else 0.0,
        "min": int(np.min(lengths)),
        "p25": float(np.percentile(lengths, 25)),
        "median": float(np.median(lengths)),
        "p75": float(np.percentile(lengths, 75)),
        "max": int(np.max(lengths)),
    }


def cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    n_a, n_b = len(a), len(b)
    if n_a < 2 or n_b < 2:
        return 0.0
    var_a = np.var(a, ddof=1)
    var_b = np.var(b, ddof=1)
    pooled = np.sqrt(((n_a - 1) * var_a + (n_b - 1) * var_b) / (n_a + n_b - 2))
    if pooled == 0:
        return 0.0
    return float((np.mean(a) - np.mean(b)) / pooled)


def cliffs_delta(a: np.ndarray, b: np.ndarray) -> float:
    """Cliff's delta — non-parametric effect size in [-1, 1]."""
    if len(a) == 0 or len(b) == 0:
        return 0.0
    gt = (a[:, None] > b[None, :]).sum()
    lt = (a[:, None] < b[None, :]).sum()
    return float((gt - lt) / (len(a) * len(b)))


def chi_squared_test(a: np.ndarray, b: np.ndarray, bins: int = 20):
    combined = np.concatenate([a, b])
    _, edges = np.histogram(combined, bins=bins)
    counts_a, _ = np.histogram(a, bins=edges)
    counts_b, _ = np.histogram(b, bins=edges)
    mask = (counts_a + counts_b) > 0
    counts_a = counts_a[mask]
    counts_b = counts_b[mask]
    if len(counts_a) < 2:
        return 0.0, 1.0
    chi2, p, _, _ = stats.chi2_contingency(np.array([counts_a, counts_b]))
    return float(chi2), float(p)


def permutation_test(
    a: np.ndarray, b: np.ndarray,
    n_permutations: int = 10_000, random_state: int = 42,
):
    rng = np.random.default_rng(random_state)
    observed = float(np.mean(a) - np.mean(b))
    combined = np.concatenate([a, b]).copy()
    n_a = len(a)
    count = 0
    for _ in range(n_permutations):
        rng.shuffle(combined)
        diff = np.mean(combined[:n_a]) - np.mean(combined[n_a:])
        if abs(diff) >= abs(observed):
            count += 1
    return observed, count / n_permutations


def bootstrap_mean_diff_ci(
    a: np.ndarray, b: np.ndarray,
    n_bootstrap: int = 10_000, confidence: float = 0.95, random_state: int = 42,
):
    rng = np.random.default_rng(random_state)
    observed = float(np.mean(a) - np.mean(b))
    diffs = np.empty(n_bootstrap)
    for i in range(n_bootstrap):
        sa = rng.choice(a, size=len(a), replace=True)
        sb = rng.choice(b, size=len(b), replace=True)
        diffs[i] = np.mean(sa) - np.mean(sb)
    alpha = 1 - confidence
    lo = float(np.percentile(diffs, 100 * alpha / 2))
    hi = float(np.percentile(diffs, 100 * (1 - alpha / 2)))
    return observed, lo, hi


def psi(a: np.ndarray, b: np.ndarray, bins: int = 20, eps: float = 1e-6) -> float:
    combined = np.concatenate([a, b])
    _, edges = np.histogram(combined, bins=bins)
    hist_a, _ = np.histogram(a, bins=edges, density=True)
    hist_b, _ = np.histogram(b, bins=edges, density=True)
    hist_a = hist_a / (hist_a.sum() + eps)
    hist_b = hist_b / (hist_b.sum() + eps)
    hist_a = np.clip(hist_a, eps, None)
    hist_b = np.clip(hist_b, eps, None)
    return float(np.sum((hist_b - hist_a) * np.log(hist_b / hist_a)))


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------

@dataclass
class ComparisonResult:
    unit: str
    label_a: str
    label_b: str
    alpha: float

    stats_a: dict = field(default_factory=dict)
    stats_b: dict = field(default_factory=dict)

    welch_t_statistic: float = 0.0
    welch_t_pvalue: float = 1.0
    ks_statistic: float = 0.0
    ks_pvalue: float = 1.0
    mannwhitney_statistic: float = 0.0
    mannwhitney_pvalue: float = 1.0
    chi2_statistic: float = 0.0
    chi2_pvalue: float = 1.0
    permutation_pvalue: float = 1.0
    levene_statistic: float = 0.0
    levene_pvalue: float = 1.0

    cohens_d: float = 0.0
    cliffs_delta: float = 0.0
    mean_diff: float = 0.0
    mean_diff_pct: float = 0.0
    bootstrap_ci_lower: float = 0.0
    bootstrap_ci_upper: float = 0.0

    psi: float = 0.0

    n_sig_tests: int = 0
    verdict: str = ""

    # Stored separately (not serialised by default — large arrays).
    lengths_a: np.ndarray = field(default_factory=lambda: np.array([]), repr=False)
    lengths_b: np.ndarray = field(default_factory=lambda: np.array([]), repr=False)

    def to_serializable(self) -> dict:
        d = asdict(self)
        d.pop("lengths_a", None)
        d.pop("lengths_b", None)
        return d

    def summary(self) -> str:
        lines = [
            "=" * 68,
            f"  Query Length Comparison  (unit: {self.unit}, alpha: {self.alpha})",
            "=" * 68,
            "",
            f"  {'Metric':<10s}  {self.label_a:>14s}  {self.label_b:>14s}",
            f"  {'-'*10}  {'-'*14}  {'-'*14}",
        ]
        for key in ["count", "mean", "std", "min", "p25", "median", "p75", "max"]:
            va = self.stats_a.get(key, 0)
            vb = self.stats_b.get(key, 0)
            fmt = "d" if key in ("count", "min", "max") else ".2f"
            lines.append(f"  {key:<10s}  {va:>14{fmt}}  {vb:>14{fmt}}")

        lines += [
            "",
            "  Hypothesis tests (H0: equal distribution / location / scale)",
            f"  {'-'*60}",
            f"  {'Test':<28s}  {'Statistic':>12s}  {'p-value':>12s}",
            f"  {'-'*28}  {'-'*12}  {'-'*12}",
        ]
        for name, stat, p in [
            ("Welch's t (mean)",          self.welch_t_statistic,     self.welch_t_pvalue),
            ("Mann-Whitney U (location)", self.mannwhitney_statistic, self.mannwhitney_pvalue),
            ("Kolmogorov-Smirnov (dist)", self.ks_statistic,          self.ks_pvalue),
            ("Chi-squared (binned)",      self.chi2_statistic,        self.chi2_pvalue),
            ("Levene (variance)",         self.levene_statistic,      self.levene_pvalue),
            ("Permutation (mean diff)",   self.mean_diff,             self.permutation_pvalue),
        ]:
            sig = "***" if p < 0.001 else ("**" if p < 0.01 else ("*" if p < self.alpha else ""))
            lines.append(f"  {name:<28s}  {stat:>12.4f}  {p:>12.4e}  {sig}")

        lines += [
            "",
            "  Effect size and uncertainty",
            f"  {'-'*60}",
            f"  Mean difference (A - B) : {self.mean_diff:+.3f}  ({self.mean_diff_pct:+.1f}%)",
            f"  Bootstrap 95% CI        : [{self.bootstrap_ci_lower:+.3f}, "
            f"{self.bootstrap_ci_upper:+.3f}]",
            f"  Cohen's d               : {self.cohens_d:+.3f}",
            f"  Cliff's delta           : {self.cliffs_delta:+.3f}",
            f"  PSI                     : {self.psi:.4f}",
            "",
            "  Verdict",
            f"  {'-'*60}",
            f"  {self.verdict}",
            "=" * 68,
        ]
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main comparison
# ---------------------------------------------------------------------------

def compare(
    queries_a: Sequence[str],
    queries_b: Sequence[str],
    *,
    unit: str = "word",
    psi_bins: int = 20,
    n_permutations: int = 10_000,
    n_bootstrap: int = 10_000,
    alpha: float = 0.05,
    label_a: str = "Set A",
    label_b: str = "Set B",
    random_state: int = 42,
) -> ComparisonResult:
    lens_a = query_lengths(queries_a, unit=unit)
    lens_b = query_lengths(queries_b, unit=unit)

    if len(lens_a) < 2 or len(lens_b) < 2:
        raise ValueError("Each set must contain at least two queries.")

    logger.info("Set A: %d queries  |  Set B: %d queries", len(lens_a), len(lens_b))

    sa = descriptive_stats(lens_a)
    sb = descriptive_stats(lens_b)

    t_stat, t_p = stats.ttest_ind(lens_a, lens_b, equal_var=False)
    ks_stat, ks_p = stats.ks_2samp(lens_a, lens_b)
    mw_stat, mw_p = stats.mannwhitneyu(lens_a, lens_b, alternative="two-sided")
    chi2_stat, chi2_p = chi_squared_test(lens_a, lens_b, bins=psi_bins)
    lev_stat, lev_p = stats.levene(lens_a, lens_b, center="median")

    logger.info("Running permutation test (%d iterations)...", n_permutations)
    _, perm_p = permutation_test(
        lens_a, lens_b, n_permutations=n_permutations, random_state=random_state,
    )

    cd = cohens_d(lens_a, lens_b)
    cdelta = cliffs_delta(lens_a, lens_b)

    logger.info("Bootstrapping 95%% CI for mean difference (%d resamples)...", n_bootstrap)
    _, ci_lo, ci_hi = bootstrap_mean_diff_ci(
        lens_a, lens_b, n_bootstrap=n_bootstrap, random_state=random_state,
    )

    psi_val = psi(lens_a, lens_b, bins=psi_bins)

    mean_diff = sa["mean"] - sb["mean"]
    mean_diff_pct = (mean_diff / sb["mean"] * 100) if sb["mean"] != 0 else 0.0

    p_values_dist = [t_p, ks_p, mw_p, chi2_p, perm_p]
    n_sig = sum(1 for p in p_values_dist if p < alpha)

    if n_sig >= 4:
        verdict = (
            f"{n_sig}/5 distribution-comparison tests reject H0 at alpha={alpha}; "
            "consistent with a difference in query-length distribution."
        )
    elif n_sig >= 2:
        verdict = (
            f"{n_sig}/5 distribution-comparison tests reject H0 at alpha={alpha}; "
            "evidence is mixed — interpret with caution."
        )
    else:
        verdict = (
            f"Only {n_sig}/5 distribution-comparison tests reject H0 at alpha={alpha}; "
            "no convincing evidence of a difference in query-length distribution."
        )

    return ComparisonResult(
        unit=unit, label_a=label_a, label_b=label_b, alpha=alpha,
        stats_a=sa, stats_b=sb,
        welch_t_statistic=float(t_stat), welch_t_pvalue=float(t_p),
        ks_statistic=float(ks_stat), ks_pvalue=float(ks_p),
        mannwhitney_statistic=float(mw_stat), mannwhitney_pvalue=float(mw_p),
        chi2_statistic=chi2_stat, chi2_pvalue=chi2_p,
        permutation_pvalue=perm_p,
        levene_statistic=float(lev_stat), levene_pvalue=float(lev_p),
        cohens_d=cd, cliffs_delta=cdelta,
        mean_diff=mean_diff, mean_diff_pct=mean_diff_pct,
        bootstrap_ci_lower=ci_lo, bootstrap_ci_upper=ci_hi,
        psi=psi_val,
        n_sig_tests=n_sig, verdict=verdict,
        lengths_a=lens_a, lengths_b=lens_b,
    )


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

def plot_distributions(result: ComparisonResult, path: str, bins: int = 30) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    label_unit = "characters" if result.unit == "char" else "words"

    combined = np.concatenate([result.lengths_a, result.lengths_b])
    edges = np.histogram_bin_edges(combined, bins=bins)

    ax = axes[0]
    ax.hist(result.lengths_a, bins=edges, alpha=0.55, label=result.label_a,
            color="#1f77b4", edgecolor="white", linewidth=0.5)
    ax.hist(result.lengths_b, bins=edges, alpha=0.55, label=result.label_b,
            color="#ff7f0e", edgecolor="white", linewidth=0.5)
    ax.set_xlabel(f"Query length ({label_unit})")
    ax.set_ylabel("Count")
    ax.set_title("Histogram")
    ax.legend()

    ax = axes[1]
    from scipy.stats import gaussian_kde
    grid = np.linspace(combined.min(), combined.max(), 300)
    if np.std(result.lengths_a) > 0:
        ax.plot(grid, gaussian_kde(result.lengths_a.astype(float))(grid),
                color="#1f77b4", lw=2, label=result.label_a)
    if np.std(result.lengths_b) > 0:
        ax.plot(grid, gaussian_kde(result.lengths_b.astype(float))(grid),
                color="#ff7f0e", lw=2, label=result.label_b)
    ax.set_xlabel(f"Query length ({label_unit})")
    ax.set_ylabel("Density")
    ax.set_title("Kernel density estimate")
    ax.legend()

    ax = axes[2]
    bp = ax.boxplot(
        [result.lengths_a, result.lengths_b],
        labels=[result.label_a, result.label_b],
        patch_artist=True,
        widths=0.5,
    )
    for patch, color in zip(bp["boxes"], ["#1f77b4", "#ff7f0e"]):
        patch.set_facecolor(color)
        patch.set_alpha(0.6)
    ax.set_ylabel(f"Query length ({label_unit})")
    ax.set_title("Box plot")

    fig.suptitle(
        f"Query length distributions — {result.label_a} vs {result.label_b}",
        fontsize=13, fontweight="bold", y=1.02,
    )
    plt.tight_layout()
    fig.savefig(path, dpi=130, bbox_inches="tight")
    plt.close(fig)


def plot_ecdf(result: ComparisonResult, path: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 4.5))
    label_unit = "characters" if result.unit == "char" else "words"

    for arr, label, color in [
        (result.lengths_a, result.label_a, "#1f77b4"),
        (result.lengths_b, result.label_b, "#ff7f0e"),
    ]:
        x = np.sort(arr)
        y = np.arange(1, len(x) + 1) / len(x)
        ax.step(x, y, where="post", label=label, color=color, lw=2)

    ax.set_xlabel(f"Query length ({label_unit})")
    ax.set_ylabel("Empirical CDF")
    ax.set_title("Empirical cumulative distribution")
    ax.grid(True, alpha=0.3)
    ax.legend()
    plt.tight_layout()
    fig.savefig(path, dpi=130, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------------

def load_queries(path: str) -> list[str]:
    if path.lower().endswith(".json"):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list) or not all(isinstance(x, str) for x in data):
            raise ValueError(f"{path}: JSON must be a list of strings.")
        return [s.strip() for s in data if s.strip()]
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]


def make_demo_queries(seed: int = 42) -> tuple[list[str], list[str]]:
    rng = np.random.default_rng(seed)
    short = ["what is {}", "how to {}", "best {}", "define {}",
             "{} meaning", "why {}", "{} tutorial"]
    long = [
        "what is the difference between {} and {} in practice",
        "how do I implement {} using {} in python step by step",
        "explain the concept of {} with examples and code samples",
        "what are the trade-offs of {} versus {} for large datasets",
        "can you provide a beginner tutorial on {} using {} libraries",
    ]
    topics = ["machine learning", "deep learning", "python", "NLP",
              "data science", "clustering", "regression", "transformers"]

    def gen(templates, n):
        out = []
        for _ in range(n):
            t = rng.choice(templates)
            fills = rng.choice(topics, size=t.count("{}"), replace=True).tolist()
            out.append(t.format(*fills))
        return out

    return gen(short, 200), gen(long, 200)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Compare query-length distributions between two sets of queries.",
    )
    p.add_argument("--file_a", type=str, default=None,
                   help="Path to Set A (one query per line, or JSON list).")
    p.add_argument("--file_b", type=str, default=None,
                   help="Path to Set B (one query per line, or JSON list).")
    p.add_argument("--label_a", type=str, default="Set A",
                   help="Display name for Set A (default: 'Set A').")
    p.add_argument("--label_b", type=str, default="Set B",
                   help="Display name for Set B (default: 'Set B').")
    p.add_argument("--unit", type=str, default="word", choices=["char", "word"],
                   help="Length unit (default: word).")
    p.add_argument("--alpha", type=float, default=0.05,
                   help="Significance threshold (default: 0.05).")
    p.add_argument("--psi_bins", type=int, default=20,
                   help="Number of bins for PSI / chi-squared (default: 20).")
    p.add_argument("--n_permutations", type=int, default=10_000,
                   help="Permutation-test iterations (default: 10000).")
    p.add_argument("--n_bootstrap", type=int, default=10_000,
                   help="Bootstrap resamples (default: 10000).")
    p.add_argument("--random_state", type=int, default=42,
                   help="Random seed (default: 42).")
    p.add_argument("--output_dir", type=str, default="./qlc_output",
                   help="Directory for results.json, summary.txt, plots.")
    p.add_argument("--demo", action="store_true",
                   help="Run with synthetic data (overrides --file_a / --file_b).")
    args = p.parse_args(argv)

    if args.demo:
        queries_a, queries_b = make_demo_queries(seed=args.random_state)
    else:
        if not args.file_a or not args.file_b:
            p.error("Provide both --file_a and --file_b (or use --demo).")
        queries_a = load_queries(args.file_a)
        queries_b = load_queries(args.file_b)

    result = compare(
        queries_a, queries_b,
        unit=args.unit, psi_bins=args.psi_bins,
        n_permutations=args.n_permutations, n_bootstrap=args.n_bootstrap,
        alpha=args.alpha, label_a=args.label_a, label_b=args.label_b,
        random_state=args.random_state,
    )

    os.makedirs(args.output_dir, exist_ok=True)

    results_path = os.path.join(args.output_dir, "results.json")
    summary_path = os.path.join(args.output_dir, "summary.txt")
    dist_plot_path = os.path.join(args.output_dir, "distributions.png")
    ecdf_plot_path = os.path.join(args.output_dir, "ecdf.png")

    with open(results_path, "w", encoding="utf-8") as f:
        json.dump(result.to_serializable(), f, indent=2)
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(result.summary())

    plot_distributions(result, dist_plot_path)
    plot_ecdf(result, ecdf_plot_path)

    print(result.summary())
    print(f"\nSaved: {results_path}")
    print(f"Saved: {summary_path}")
    print(f"Saved: {dist_plot_path}")
    print(f"Saved: {ecdf_plot_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
