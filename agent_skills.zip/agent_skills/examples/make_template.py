"""Generate a minimal example template .docx with the headings the
build_report.py script looks for. Open the resulting file in Word and apply
your corporate styling to the heading paragraphs."""

from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH


def main(path: str = "corporate_template.docx") -> None:
    doc = Document()

    title = doc.add_heading("Query Length Validation — Corporate Template", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    intro = doc.add_paragraph(
        "This is a template. The build_report.py script will insert content "
        "immediately after each H1 heading below. Apply your corporate fonts, "
        "colours, headers, and footers to this file in Word — the generated "
        "report will inherit them. Do not put body content under the headings; "
        "the script does not delete existing content, it only inserts after."
    )
    for r in intro.runs:
        r.italic = True
        r.font.size = Pt(10)

    for heading in [
        "1. Purpose and scope",
        "2. Data summary",
        "3. Methods",
        "4. Hypothesis test results",
        "5. Effect size and uncertainty",
        "6. Visualisations",
        "7. Findings",
        "8. Assessment",
    ]:
        doc.add_heading(heading, level=1)

    doc.save(path)
    print(f"Wrote template: {path}")


if __name__ == "__main__":
    import sys
    main(sys.argv[1] if len(sys.argv) > 1 else "corporate_template.docx")
