"""
Semantic Drift Detection Pipeline using BERTopic and PSI.

This module detects semantic drift between two sets of documents by:
1. Fitting a BERTopic model on the combined corpus (shared topic space).
2. Extracting the top-K keywords per topic.
3. Computing the Population Stability Index (PSI) over the topic
   distribution histograms of the two document sets.

Usage
-----
    python semantic_drift.py                       # runs built-in demo
    python semantic_drift.py --file_a a.txt --file_b b.txt
"""

from __future__ import annotations

import argparse
import logging
import warnings
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

import re

import numpy as np
import pandas as pd
from bertopic import BERTopic
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
logger = logging.getLogger(__name__)

KEYWORD_METHODS = ("c-tf-idf", "tf-idf", "keybert", "mmr")

# ──────────────────────────────────────────────
# Text Preprocessing
# ──────────────────────────────────────────────

# Extended stopwords: sklearn's "english" set + common noise tokens
_EXTRA_STOPWORDS = frozenset({
    # Common web / document noise
    "http", "https", "www", "com", "org", "html", "pdf", "url",
    "mailto", "email", "nbsp", "amp",
    # Common formatting / metadata artefacts
    "et", "al", "eg", "ie", "etc", "vs", "fig", "ref", "vol",
    "pp", "ibid", "op", "cit", "doi",
    # Single-letter tokens that slip through
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l",
    "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x",
    "y", "z",
    # Miscellaneous filler
    "also", "however", "therefore", "thus", "hence", "moreover",
    "furthermore", "nevertheless", "meanwhile", "whereas",
    "although", "though", "since", "unless", "whether",
    "really", "actually", "basically", "simply", "just",
    "thing", "things", "stuff", "way", "ways", "lot", "lots",
    "kind", "sort", "type", "like", "get", "got", "gotten",
    "make", "made", "makes", "use", "used", "using",
    "said", "say", "says", "going", "go", "goes", "went",
    "come", "came", "take", "took", "taken",
    "know", "known", "think", "thought",
    "want", "need", "see", "look", "give", "gave",
})

# Regex: tokens must be 2+ alphabetical characters
_TOKEN_PATTERN = r"(?u)\b[a-zA-Z][a-zA-Z]+\b"


def clean_text(text: str) -> str:
    """Clean a raw document string.

    - Lowercases
    - Strips URLs, email addresses, HTML tags
    - Removes special characters and digits
    - Collapses whitespace
    """
    text = text.lower()
    # Remove URLs
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    # Remove email addresses
    text = re.sub(r"\S+@\S+", " ", text)
    # Remove HTML tags
    text = re.sub(r"<[^>]+>", " ", text)
    # Remove special characters, keeping only letters and spaces
    text = re.sub(r"[^a-z\s]", " ", text)
    # Collapse whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _is_noisy_token(token: str) -> bool:
    """Return True if a token/n-gram is noise and should be filtered out."""
    parts = token.split()
    # All parts are single characters
    if all(len(p) <= 1 for p in parts):
        return True
    # All parts are numbers
    if all(p.isdigit() for p in parts):
        return True
    # All parts are in the extended stopword set
    if all(p in _EXTRA_STOPWORDS for p in parts):
        return True
    # Token is purely whitespace or empty
    if not token.strip():
        return True
    return False


def _get_extended_stop_words(extra: set[str] | None = None) -> list[str]:
    """Combine sklearn's English stopwords with our extended set and any user words."""
    from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
    combined = ENGLISH_STOP_WORDS | _EXTRA_STOPWORDS
    if extra:
        combined = combined | extra
    return list(combined)


def _build_clean_vectorizer(
    cls=CountVectorizer,
    ngram_range: tuple[int, int] = (1, 2),
    max_features: int | None = None,
    extra_stopwords: set[str] | None = None,
    **kwargs,
):
    """Build a vectorizer with extended stopwords and clean token pattern."""
    return cls(
        stop_words=_get_extended_stop_words(extra_stopwords),
        token_pattern=_TOKEN_PATTERN,
        ngram_range=ngram_range,
        max_features=max_features,
        **kwargs,
    )


def _filter_keywords(
    keywords: list[str],
    top_k: int,
    extra_stopwords: set[str] | None = None,
) -> list[str]:
    """Post-filter a keyword list, removing noisy entries."""
    extra = extra_stopwords or set()
    filtered = [
        kw for kw in keywords
        if not _is_noisy_token(kw)
        and not all(part in extra for part in kw.split())
    ]
    return filtered[:top_k]

# ──────────────────────────────────────────────
# PSI Computation
# ──────────────────────────────────────────────

def compute_psi(
    expected: np.ndarray,
    actual: np.ndarray,
    eps: float = 1e-6,
) -> float:
    """Compute the Population Stability Index (PSI) between two distributions.

    Parameters
    ----------
    expected : np.ndarray
        Reference (baseline) probability distribution – sums to 1.
    actual : np.ndarray
        Comparison probability distribution – sums to 1.
    eps : float
        Small constant to avoid log(0).

    Returns
    -------
    float
        PSI value.  Typical interpretation:
            < 0.10  → no significant drift
            0.10–0.25 → moderate drift
            > 0.25  → significant drift
    """
    expected = np.clip(expected, eps, None)
    actual = np.clip(actual, eps, None)
    psi = np.sum((actual - expected) * np.log(actual / expected))
    return float(psi)


def _topic_distribution(
    topics: np.ndarray,
    all_topic_ids: np.ndarray,
) -> np.ndarray:
    """Convert a list of topic assignments into a normalised histogram.

    Parameters
    ----------
    topics : np.ndarray
        Array of topic IDs assigned to each document (may include -1 for outliers).
    all_topic_ids : np.ndarray
        Sorted array of *all* unique topic IDs across both sets so that both
        histograms share the same bins.

    Returns
    -------
    np.ndarray
        Probability vector of shape ``(len(all_topic_ids),)`` summing to 1.
    """
    counts = np.zeros(len(all_topic_ids), dtype=np.float64)
    id_to_idx = {tid: idx for idx, tid in enumerate(all_topic_ids)}
    for t in topics:
        counts[id_to_idx[t]] += 1
    total = counts.sum()
    if total == 0:
        return counts
    return counts / total


# ──────────────────────────────────────────────
# Keyword Extraction Methods
# ──────────────────────────────────────────────

def _extract_keywords_ctfidf(
    topic_model: BERTopic,
    combined_docs: list[str],
    topics: np.ndarray,
    top_k: int,
    embeddings: np.ndarray | None = None,
    extra_stopwords: set[str] | None = None,
) -> dict[int, list[str]]:
    """Extract keywords using BERTopic's built-in c-TF-IDF scores."""
    topic_info = topic_model.get_topics()
    kw_map: dict[int, list[str]] = {}
    for tid, word_score_list in topic_info.items():
        raw = [w for w, _ in word_score_list]
        kw_map[int(tid)] = _filter_keywords(raw, top_k, extra_stopwords)
    return kw_map


def _extract_keywords_tfidf(
    topic_model: BERTopic,
    combined_docs: list[str],
    topics: np.ndarray,
    top_k: int,
    embeddings: np.ndarray | None = None,
    extra_stopwords: set[str] | None = None,
) -> dict[int, list[str]]:
    """Extract keywords per cluster using standard TF-IDF.

    All documents in a cluster are concatenated into a single
    mega-document, then sklearn's TfidfVectorizer is fitted across
    these mega-documents.  Words are ranked by their TF-IDF weight
    within each cluster.
    """
    unique_topics = sorted(set(topics.tolist()))
    # Build one mega-document per topic
    mega_docs = []
    for tid in unique_topics:
        cluster_texts = [combined_docs[i] for i in range(len(combined_docs)) if topics[i] == tid]
        mega_docs.append(" ".join(cluster_texts))

    vectorizer = _build_clean_vectorizer(
        cls=TfidfVectorizer,
        ngram_range=(1, 2),
        max_features=10_000,
        extra_stopwords=extra_stopwords,
    )
    tfidf_matrix = vectorizer.fit_transform(mega_docs)
    feature_names = vectorizer.get_feature_names_out()

    kw_map: dict[int, list[str]] = {}
    for idx, tid in enumerate(unique_topics):
        row = tfidf_matrix[idx].toarray().flatten()
        # Over-fetch so we can filter noise and still get top_k
        top_indices = row.argsort()[::-1][:top_k * 3]
        raw = [str(feature_names[i]) for i in top_indices if row[i] > 0]
        kw_map[int(tid)] = _filter_keywords(raw, top_k, extra_stopwords)
    return kw_map


def _extract_keywords_keybert(
    topic_model: BERTopic,
    combined_docs: list[str],
    topics: np.ndarray,
    top_k: int,
    embeddings: np.ndarray | None = None,
    extra_stopwords: set[str] | None = None,
) -> dict[int, list[str]]:
    """Extract keywords per cluster using embedding-based cosine similarity.

    For each cluster, compute the centroid of the document embeddings,
    then rank candidate n-grams by their cosine similarity to the centroid
    (KeyBERT-style approach without an external dependency).
    """
    from sklearn.metrics.pairwise import cosine_similarity

    if embeddings is None:
        raise ValueError(
            "keyword_method='keybert' requires document embeddings. "
            "These are extracted automatically inside detect_semantic_drift()."
        )

    unique_topics = sorted(set(topics.tolist()))

    # Build n-gram candidates per cluster using CountVectorizer
    kw_map: dict[int, list[str]] = {}
    embedding_model = topic_model.embedding_model

    for tid in unique_topics:
        mask = topics == tid
        cluster_docs = [combined_docs[i] for i in range(len(combined_docs)) if mask[i]]
        cluster_embs = embeddings[mask]

        # Centroid of cluster embeddings
        centroid = cluster_embs.mean(axis=0, keepdims=True)

        # Extract candidate n-grams
        cv = _build_clean_vectorizer(cls=CountVectorizer, ngram_range=(1, 2), extra_stopwords=extra_stopwords)
        try:
            cv.fit(cluster_docs)
        except ValueError:
            kw_map[int(tid)] = []
            continue
        candidates = [c for c in cv.get_feature_names_out().tolist() if not _is_noisy_token(c)]

        # Embed candidates
        cand_embeddings = embedding_model.embed_words(candidates) if hasattr(embedding_model, 'embed_words') else None
        if cand_embeddings is None:
            # Fall back: embed candidates as short documents
            cand_embeddings = embedding_model.embed_documents(candidates) if hasattr(embedding_model, 'embed_documents') else None
        if cand_embeddings is None:
            # Last resort: use the underlying sentence-transformer
            try:
                from sentence_transformers import SentenceTransformer
                st_model = embedding_model.embedding_model if hasattr(embedding_model, 'embedding_model') else None
                if isinstance(st_model, SentenceTransformer):
                    cand_embeddings = st_model.encode(candidates, show_progress_bar=False)
                else:
                    # If we truly can't embed, fall back to c-TF-IDF for this topic
                    topic_info = topic_model.get_topics()
                    kw_map[int(tid)] = [w for w, _ in topic_info.get(tid, [])[:top_k]]
                    continue
            except Exception:
                topic_info = topic_model.get_topics()
                kw_map[int(tid)] = [w for w, _ in topic_info.get(tid, [])[:top_k]]
                continue

        cand_embeddings = np.array(cand_embeddings)
        # Cosine similarity between centroid and each candidate
        sims = cosine_similarity(centroid, cand_embeddings).flatten()
        top_indices = sims.argsort()[::-1][:top_k]
        kw_map[int(tid)] = _filter_keywords([candidates[i] for i in top_indices], top_k, extra_stopwords)

    return kw_map


def _extract_keywords_mmr(
    topic_model: BERTopic,
    combined_docs: list[str],
    topics: np.ndarray,
    top_k: int,
    embeddings: np.ndarray | None = None,
    diversity: float = 0.5,
    extra_stopwords: set[str] | None = None,
) -> dict[int, list[str]]:
    """Extract keywords per cluster using Maximal Marginal Relevance (MMR).

    Like KeyBERT but with a diversity penalty: iteratively selects the
    candidate most similar to the cluster centroid while being most
    dissimilar to already-selected keywords.

    ``diversity`` ∈ [0, 1]: 0 = pure relevance, 1 = pure diversity.
    """
    from sklearn.metrics.pairwise import cosine_similarity

    if embeddings is None:
        raise ValueError(
            "keyword_method='mmr' requires document embeddings. "
            "These are extracted automatically inside detect_semantic_drift()."
        )

    unique_topics = sorted(set(topics.tolist()))
    kw_map: dict[int, list[str]] = {}
    embedding_model = topic_model.embedding_model

    for tid in unique_topics:
        mask = topics == tid
        cluster_docs = [combined_docs[i] for i in range(len(combined_docs)) if mask[i]]
        cluster_embs = embeddings[mask]
        centroid = cluster_embs.mean(axis=0, keepdims=True)

        cv = _build_clean_vectorizer(cls=CountVectorizer, ngram_range=(1, 2), extra_stopwords=extra_stopwords)
        try:
            cv.fit(cluster_docs)
        except ValueError:
            kw_map[int(tid)] = []
            continue
        candidates = [c for c in cv.get_feature_names_out().tolist() if not _is_noisy_token(c)]

        # Embed candidates
        cand_embeddings = None
        try:
            from sentence_transformers import SentenceTransformer
            st_model = embedding_model.embedding_model if hasattr(embedding_model, 'embedding_model') else None
            if isinstance(st_model, SentenceTransformer):
                cand_embeddings = st_model.encode(candidates, show_progress_bar=False)
        except Exception:
            pass

        if cand_embeddings is None:
            # Fall back to c-TF-IDF
            topic_info = topic_model.get_topics()
            kw_map[int(tid)] = _filter_keywords([w for w, _ in topic_info.get(tid, [])], top_k, extra_stopwords)
            continue

        cand_embeddings = np.array(cand_embeddings)
        # Relevance: similarity of each candidate to the centroid
        sim_to_centroid = cosine_similarity(centroid, cand_embeddings).flatten()
        # Inter-candidate similarity matrix
        sim_between = cosine_similarity(cand_embeddings)

        # MMR iterative selection
        selected_indices: list[int] = []
        remaining = list(range(len(candidates)))

        for _ in range(min(top_k, len(candidates))):
            if not remaining:
                break
            if not selected_indices:
                # Pick the most relevant candidate first
                best = max(remaining, key=lambda i: sim_to_centroid[i])
            else:
                mmr_scores = {}
                for i in remaining:
                    max_sim_to_selected = max(sim_between[i][j] for j in selected_indices)
                    mmr_scores[i] = (
                        (1 - diversity) * sim_to_centroid[i]
                        - diversity * max_sim_to_selected
                    )
                best = max(remaining, key=lambda i: mmr_scores[i])
            selected_indices.append(best)
            remaining.remove(best)

        kw_map[int(tid)] = _filter_keywords([candidates[i] for i in selected_indices], top_k, extra_stopwords)

    return kw_map


# Map method names to functions
_KEYWORD_EXTRACTORS = {
    "c-tf-idf": _extract_keywords_ctfidf,
    "tf-idf": _extract_keywords_tfidf,
    "keybert": _extract_keywords_keybert,
    "mmr": _extract_keywords_mmr,
}


# ──────────────────────────────────────────────
# Result Container
# ──────────────────────────────────────────────

@dataclass
class DriftResult:
    """Container for the semantic drift detection result."""

    psi: float
    drift_detected: bool
    psi_threshold: float
    topic_keywords_a: dict[int, list[str]] = field(default_factory=dict)
    topic_keywords_b: dict[int, list[str]] = field(default_factory=dict)
    distribution_a: np.ndarray = field(default_factory=lambda: np.array([]))
    distribution_b: np.ndarray = field(default_factory=lambda: np.array([]))
    topic_ids: np.ndarray = field(default_factory=lambda: np.array([]))
    topics_a: np.ndarray = field(default_factory=lambda: np.array([]))
    topics_b: np.ndarray = field(default_factory=lambda: np.array([]))

    def summary(self) -> str:
        """Return a human-readable summary."""
        status = "DRIFT DETECTED" if self.drift_detected else "No significant drift"
        lines = [
            "=" * 60,
            f"  Semantic Drift Report",
            "=" * 60,
            f"  PSI              : {self.psi:.6f}",
            f"  Threshold        : {self.psi_threshold}",
            f"  Status           : {status}",
            f"  Unique topics    : {len(self.topic_ids)}",
            "-" * 60,
            "  Topic distributions (Set A | Set B):",
        ]
        for i, tid in enumerate(self.topic_ids):
            kw_a = ", ".join(self.topic_keywords_a.get(int(tid), []))
            lines.append(
                f"    Topic {tid:>3d}:  {self.distribution_a[i]:.4f}  |  "
                f"{self.distribution_b[i]:.4f}   [{kw_a}]"
            )
        lines.append("=" * 60)
        return "\n".join(lines)


# ──────────────────────────────────────────────
# Main Pipeline
# ──────────────────────────────────────────────

def detect_semantic_drift(
    docs_a: Sequence[str],
    docs_b: Sequence[str],
    *,
    top_n_keywords: int = 10,
    psi_threshold: float = 0.20,
    min_topic_size: int = 10,
    nr_topics: Optional[int | str] = None,
    embedding_model: str = "all-MiniLM-L6-v2",
    clustering_method: str = "hdbscan",
    n_clusters: int = 10,
    keyword_method: str = "c-tf-idf",
    mmr_diversity: float = 0.5,
    extra_stopwords: Sequence[str] | None = None,
    random_state: int = 42,
    verbose: bool = True,
) -> DriftResult:
    """Detect semantic drift between two document sets using BERTopic + PSI.

    **Strategy** – A single BERTopic model is fitted on the *union* of both
    document sets so that both sets share the same topic space.  The per-set
    topic distributions are then compared via PSI.

    Parameters
    ----------
    docs_a : sequence of str
        First (reference / baseline) set of documents.
    docs_b : sequence of str
        Second (comparison) set of documents.
    top_n_keywords : int
        Number of top keywords to extract per topic (default 10).
    psi_threshold : float
        PSI value above which drift is flagged (default 0.20).
    min_topic_size : int
        ``min_topic_size`` passed to BERTopic (default 10).  Used only
        when ``clustering_method="hdbscan"``.
    nr_topics : int | str | None
        If set, reduce topics to this number (e.g. ``"auto"`` or an int).
    embedding_model : str
        Sentence-transformer model name for embeddings.
    clustering_method : str
        Clustering algorithm: ``"hdbscan"`` (default) or ``"kmeans"``.
    n_clusters : int
        Number of clusters for KMeans (default 10).  Only used when
        ``clustering_method="kmeans"``.
    keyword_method : str
        Method for extracting top-K keywords per cluster:

        - ``"c-tf-idf"`` (default): BERTopic's built-in class-based TF-IDF.
          Treats each cluster as a mega-document and applies a modified
          TF-IDF that penalises words common across topics.
        - ``"tf-idf"``: Standard sklearn TF-IDF computed per cluster.
          Each cluster's documents are concatenated into a mega-document
          and TfidfVectorizer is fitted across all mega-documents.
        - ``"keybert"``: Embedding-based extraction.  Candidate n-grams are
          embedded with the same sentence-transformer model and ranked by
          cosine similarity to the cluster centroid embedding.
        - ``"mmr"``: Maximal Marginal Relevance.  Like KeyBERT but iteratively
          selects candidates that are relevant to the centroid *and*
          diverse from already-selected keywords.  Controlled by
          ``mmr_diversity``.
    mmr_diversity : float
        Trade-off between relevance and diversity for MMR keyword
        extraction (0 = pure relevance, 1 = pure diversity).  Default 0.5.
        Only used when ``keyword_method="mmr"``.
    extra_stopwords : sequence of str, optional
        Additional domain-specific stopwords to suppress during keyword
        extraction (e.g. ``["model", "data", "result"]``).  These are
        merged with the built-in extended stopword list and applied to
        ALL keyword extraction methods and the BERTopic vectorizer.
    random_state : int
        Seed for reproducibility in UMAP / HDBSCAN / KMeans.
    verbose : bool
        If True, log progress messages.

    Returns
    -------
    DriftResult
        Dataclass containing PSI value, per-topic distributions, keywords,
        and a convenience ``summary()`` method.
    """
    docs_a = list(docs_a)
    docs_b = list(docs_b)
    n_a, n_b = len(docs_a), len(docs_b)
    if verbose:
        logger.info("Set A: %d docs  |  Set B: %d docs", n_a, n_b)

    # Normalise extra_stopwords into a set (lowercased)
    stop_set: set[str] | None = (
        {w.lower().strip() for w in extra_stopwords} if extra_stopwords else None
    )

    # ---- 1. Combine documents and fit BERTopic ----
    combined_docs = docs_a + docs_b

    # Clean text for vectorizer / keyword extraction (removes noise)
    cleaned_docs = [clean_text(d) for d in combined_docs]

    # Pre-compute embeddings on ORIGINAL text so the sentence-transformer
    # sees natural language with full semantic context (casing, punctuation, etc.).
    from sentence_transformers import SentenceTransformer
    if verbose:
        logger.info("Encoding %d documents with '%s' on original text …",
                     len(combined_docs), embedding_model)
    st_model = SentenceTransformer(embedding_model)
    doc_embeddings = st_model.encode(combined_docs, show_progress_bar=verbose)

    if verbose:
        logger.info("Fitting BERTopic on cleaned text (embeddings from original) …")

    from umap import UMAP

    umap_model = UMAP(
        n_neighbors=15,
        n_components=5,
        min_dist=0.0,
        metric="cosine",
        random_state=random_state,
    )

    # ---- Select clustering model ----
    clustering_method = clustering_method.lower()
    if clustering_method == "kmeans":
        if verbose:
            logger.info("Using KMeans clustering (n_clusters=%d)", n_clusters)
        cluster_model = KMeans(
            n_clusters=n_clusters,
            random_state=random_state,
            n_init=10,
        )
    elif clustering_method == "hdbscan":
        from hdbscan import HDBSCAN
        if verbose:
            logger.info("Using HDBSCAN clustering (min_cluster_size=%d)", min_topic_size)
        cluster_model = HDBSCAN(
            min_cluster_size=min_topic_size,
            metric="euclidean",
            prediction_data=True,
        )
    else:
        raise ValueError(
            f"Unknown clustering_method={clustering_method!r}. "
            f"Choose 'hdbscan' or 'kmeans'."
        )

    vectorizer_model = _build_clean_vectorizer(
        cls=CountVectorizer,
        ngram_range=(1, 2),
        extra_stopwords=stop_set,
    )

    topic_model = BERTopic(
        embedding_model=st_model,
        umap_model=umap_model,
        hdbscan_model=cluster_model,
        vectorizer_model=vectorizer_model,
        top_n_words=top_n_keywords,
        nr_topics=nr_topics,
        verbose=verbose,
    )

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        # Pass pre-computed embeddings so BERTopic skips re-encoding;
        # cleaned_docs feed only the vectorizer (c-TF-IDF / keywords).
        topics, _probs = topic_model.fit_transform(cleaned_docs, embeddings=doc_embeddings)

    topics = np.asarray(topics)
    topics_a = topics[:n_a]
    topics_b = topics[n_a:]

    if verbose:
        unique_topics = set(topics.tolist())
        logger.info("BERTopic found %d topics (including outlier -1).", len(unique_topics))

    # ---- 2. Extract top-K keywords per topic ----
    keyword_method = keyword_method.lower()
    if keyword_method not in _KEYWORD_EXTRACTORS:
        raise ValueError(
            f"Unknown keyword_method={keyword_method!r}. "
            f"Choose from {KEYWORD_METHODS}."
        )
    if verbose:
        logger.info("Extracting keywords using method: %s", keyword_method)

    extractor = _KEYWORD_EXTRACTORS[keyword_method]
    if keyword_method == "mmr":
        keywords = extractor(
            topic_model, cleaned_docs, topics, top_n_keywords,
            embeddings=doc_embeddings, diversity=mmr_diversity,
            extra_stopwords=stop_set,
        )
    else:
        keywords = extractor(
            topic_model, cleaned_docs, topics, top_n_keywords,
            embeddings=doc_embeddings, extra_stopwords=stop_set,
        )

    if verbose:
        for tid in sorted(keywords):
            logger.info("  Topic %3d: %s", tid, ", ".join(keywords[tid]))

    # ---- 3. Build topic distributions for each set ----
    all_topic_ids = np.array(sorted(set(topics.tolist())))
    dist_a = _topic_distribution(topics_a, all_topic_ids)
    dist_b = _topic_distribution(topics_b, all_topic_ids)

    # ---- 4. Compute PSI ----
    psi_value = compute_psi(dist_a, dist_b)
    drift_detected = psi_value > psi_threshold

    if verbose:
        logger.info("PSI = %.6f  (threshold %.2f) → %s",
                     psi_value, psi_threshold,
                     "DRIFT" if drift_detected else "NO DRIFT")

    return DriftResult(
        psi=psi_value,
        drift_detected=drift_detected,
        psi_threshold=psi_threshold,
        topic_keywords_a=keywords,   # same topic space
        topic_keywords_b=keywords,
        distribution_a=dist_a,
        distribution_b=dist_b,
        topic_ids=all_topic_ids,
        topics_a=topics_a,
        topics_b=topics_b,
    )


# ──────────────────────────────────────────────
# Convenience: per-topic PSI breakdown
# ──────────────────────────────────────────────

def per_topic_psi(result: DriftResult, eps: float = 1e-6) -> pd.DataFrame:
    """Return a DataFrame with per-topic PSI contributions.

    Parameters
    ----------
    result : DriftResult
        Output of :func:`detect_semantic_drift`.
    eps : float
        Smoothing constant.

    Returns
    -------
    pd.DataFrame
        Columns: topic_id, keywords, dist_a, dist_b, psi_contribution.
    """
    rows = []
    for i, tid in enumerate(result.topic_ids):
        p = max(result.distribution_a[i], eps)
        q = max(result.distribution_b[i], eps)
        contrib = (q - p) * np.log(q / p)
        keywords = ", ".join(result.topic_keywords_a.get(int(tid), []))
        rows.append({
            "topic_id": int(tid),
            "keywords": keywords,
            "dist_a": result.distribution_a[i],
            "dist_b": result.distribution_b[i],
            "psi_contribution": contrib,
        })
    df = pd.DataFrame(rows).sort_values("psi_contribution", ascending=False)
    return df.reset_index(drop=True)


# ──────────────────────────────────────────────
# CLI / Demo
# ──────────────────────────────────────────────

def _demo():
    """Run a small synthetic demo to verify the pipeline works."""
    logger.info("Running synthetic demo …")

    rng = np.random.default_rng(42)

    # Set A: mostly tech + some sports
    tech_docs = [
        "Deep learning models are revolutionising computer vision tasks",
        "Transformer architectures have improved natural language processing",
        "GPU acceleration speeds up neural network training significantly",
        "Convolutional neural networks excel at image classification",
        "Recurrent networks handle sequential data effectively",
        "Reinforcement learning agents learn through trial and error",
        "Transfer learning reduces the need for large labeled datasets",
        "Attention mechanisms allow models to focus on relevant input parts",
        "Generative adversarial networks create realistic synthetic images",
        "Federated learning enables training on decentralised data",
        "Large language models can generate human-like text",
        "Self-supervised learning leverages unlabeled data for pre-training",
        "Neural architecture search automates model design",
        "Knowledge distillation compresses large models for deployment",
        "Batch normalisation stabilises and accelerates training",
    ]
    sport_docs = [
        "The football match ended in a dramatic penalty shootout",
        "Marathon runners train for months to build endurance",
        "Basketball teams rely on teamwork and strategy to win games",
        "Tennis players must master both power and finesse on the court",
        "Olympic swimmers break records with advanced training techniques",
    ]
    set_a = tech_docs + sport_docs  # 15 tech + 5 sport

    # Set B: mostly sports + some tech (reversed proportions → drift)
    set_b_tech = rng.choice(tech_docs, size=5, replace=False).tolist()
    extra_sport = [
        "Cricket is popular in many countries around the world",
        "Ice hockey players need excellent skating and stick handling skills",
        "Golf requires precision and patience over long courses",
        "Rugby matches are intense and physically demanding",
        "Cycling races test endurance across varied terrain",
        "Volleyball teams communicate constantly during fast rallies",
        "Boxing combines speed power and defensive skill in the ring",
        "Table tennis demands quick reflexes and spin control",
        "Surfing competitions judge wave selection and aerial manoeuvres",
        "Badminton shuttlecocks can travel over 300 kilometres per hour",
        "Skiing athletes navigate steep slopes at high speed",
        "Wrestling requires strength flexibility and technique",
        "Archery competitions test focus and steady aim under pressure",
        "Rowing crews synchronise their strokes for maximum speed",
        "Fencing bouts demand fast reactions and tactical thinking",
    ]
    set_b = set_b_tech + extra_sport  # 5 tech + 15 sport

    # Duplicate to reach minimum cluster size
    set_a = set_a * 3  # 60 docs
    set_b = set_b * 3  # 60 docs

    result = detect_semantic_drift(
        set_a,
        set_b,
        top_n_keywords=10,
        psi_threshold=0.20,
        min_topic_size=5,
        embedding_model="all-MiniLM-L6-v2",
    )

    print(result.summary())

    df = per_topic_psi(result)
    print("\nPer-topic PSI contributions:")
    print(df.to_string(index=False))

    return result


def _load_docs_from_file(path: str) -> list[str]:
    """Load documents from a text file (one document per line)."""
    with open(path, "r", encoding="utf-8") as f:
        docs = [line.strip() for line in f if line.strip()]
    return docs


def main():
    parser = argparse.ArgumentParser(
        description="Detect semantic drift between two document sets using BERTopic + PSI.",
    )
    parser.add_argument("--file_a", type=str, default=None,
                        help="Path to text file for Set A (one doc per line).")
    parser.add_argument("--file_b", type=str, default=None,
                        help="Path to text file for Set B (one doc per line).")
    parser.add_argument("--top_n_keywords", type=int, default=10,
                        help="Number of keywords per topic (default: 10).")
    parser.add_argument("--psi_threshold", type=float, default=0.20,
                        help="PSI threshold for drift detection (default: 0.20).")
    parser.add_argument("--min_topic_size", type=int, default=10,
                        help="Minimum topic cluster size for BERTopic (default: 10).")
    parser.add_argument("--embedding_model", type=str, default="all-MiniLM-L6-v2",
                        help="Sentence-transformer model name (default: all-MiniLM-L6-v2).")
    parser.add_argument("--clustering_method", type=str, default="hdbscan",
                        choices=["hdbscan", "kmeans"],
                        help="Clustering algorithm: 'hdbscan' or 'kmeans' (default: hdbscan).")
    parser.add_argument("--n_clusters", type=int, default=10,
                        help="Number of clusters for KMeans (default: 10).")
    parser.add_argument("--keyword_method", type=str, default="c-tf-idf",
                        choices=["c-tf-idf", "tf-idf", "keybert", "mmr"],
                        help="Keyword extraction method (default: c-tf-idf).")
    parser.add_argument("--mmr_diversity", type=float, default=0.5,
                        help="MMR diversity parameter 0-1 (default: 0.5).")
    parser.add_argument("--extra_stopwords", type=str, nargs="*", default=None,
                        help="Additional stopwords to exclude from keywords.")
    parser.add_argument("--nr_topics", type=str, default=None,
                        help="Number of topics to reduce to (int or 'auto').")
    parser.add_argument("--demo", action="store_true",
                        help="Run the built-in synthetic demo.")
    args = parser.parse_args()

    if args.demo or (args.file_a is None and args.file_b is None):
        _demo()
        return

    if args.file_a is None or args.file_b is None:
        parser.error("Both --file_a and --file_b are required unless --demo is set.")

    docs_a = _load_docs_from_file(args.file_a)
    docs_b = _load_docs_from_file(args.file_b)

    nr_topics: int | str | None = None
    if args.nr_topics is not None:
        try:
            nr_topics = int(args.nr_topics)
        except ValueError:
            nr_topics = args.nr_topics  # e.g. "auto"

    result = detect_semantic_drift(
        docs_a,
        docs_b,
        top_n_keywords=args.top_n_keywords,
        psi_threshold=args.psi_threshold,
        min_topic_size=args.min_topic_size,
        embedding_model=args.embedding_model,
        clustering_method=args.clustering_method,
        n_clusters=args.n_clusters,
        keyword_method=args.keyword_method,
        mmr_diversity=args.mmr_diversity,
        extra_stopwords=args.extra_stopwords,
        nr_topics=nr_topics,
    )

    print(result.summary())

    df = per_topic_psi(result)
    print("\nPer-topic PSI contributions:")
    print(df.to_string(index=False))


if __name__ == "__main__":
    main()
